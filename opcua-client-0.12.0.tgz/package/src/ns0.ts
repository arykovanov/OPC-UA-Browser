import * as t from "./types"
import * as ns from "./nodeset"
const node1 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=1"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Boolean"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Boolean"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node2 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=10"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Float"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Float"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=26", "i=45", false),
    ],
}

const node3 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=100"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EnumDefinition"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EnumDefinition"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=97", "i=45", false),
      new ns.Reference("i=123", "i=38", true),
      new ns.Reference("i=14799", "i=38", true),
      new ns.Reference("i=15067", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Fields", "i=102", "i=22", 1, null),
    ],
    BinaryId: "i=123",
    JsonId: "i=15067",
}

const node25 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=101"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StructureField"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StructureField"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=14844", "i=38", true),
      new ns.Reference("i=14800", "i=38", true),
      new ns.Reference("i=15065", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("DataType", "i=17", "i=17", -1, null),
      new ns.StructField("ValueRank", "i=6", "i=6", -1, null),
      new ns.StructField("ArrayDimensions", "i=7", "i=7", 1, null),
      new ns.StructField("MaxStringLength", "i=7", "i=7", -1, null),
      new ns.StructField("IsOptional", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=14844",
    JsonId: "i=15065",
}

const node26 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=102"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EnumField"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EnumField"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7594", "i=45", false),
      new ns.Reference("i=14845", "i=38", true),
      new ns.Reference("i=14801", "i=38", true),
      new ns.Reference("i=15083", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Value", "i=8", "i=8", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("Name", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=14845",
    JsonId: "i=15083",
}

const node37 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Double"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Double"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=26", "i=45", false),
      new ns.Reference("i=290", "i=45", true),
    ],
}

const node80 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11216"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ModificationInfo"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ModificationInfo"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=11226", "i=38", true),
      new ns.Reference("i=11218", "i=38", true),
      new ns.Reference("i=15271", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ModificationTime", "i=294", "i=13", -1, null),
      new ns.StructField("UpdateType", "i=11234", "i=29", -1, null),
      new ns.StructField("UserName", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=11226",
    JsonId: "i=15271",
}

const node81 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11217"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryModifiedData"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryModifiedData"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=656", "i=45", false),
      new ns.Reference("i=11227", "i=38", true),
      new ns.Reference("i=11219", "i=38", true),
      new ns.Reference("i=15272", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataValues", "i=23", "i=23", 1, null),
      new ns.StructField("ModificationInfos", "i=11216", "i=22", 1, null),
    ],
    BinaryId: "i=11227",
    JsonId: "i=15272",
}

const node86 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11234"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryUpdateType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryUpdateType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11884", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Insert", 1),
      new ns.EnumField("Replace", 2),
      new ns.EnumField("Update", 3),
      new ns.EnumField("Delete", 4),
    ],
}

const node107 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11293"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PerformUpdateType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PerformUpdateType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11885", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Insert", 1),
      new ns.EnumField("Replace", 2),
      new ns.EnumField("Update", 3),
      new ns.EnumField("Remove", 4),
    ],
}

const node108 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11295"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UpdateStructureDataDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UpdateStructureDataDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=677", "i=45", false),
      new ns.Reference("i=11300", "i=38", true),
      new ns.Reference("i=11296", "i=38", true),
      new ns.Reference("i=15281", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("PerformInsertReplace", "i=11293", "i=29", -1, null),
      new ns.StructField("UpdateValues", "i=23", "i=23", 1, null),
    ],
    BinaryId: "i=11300",
    JsonId: "i=15281",
}

const node247 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11737"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BitFieldMaskDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BitFieldMaskDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=9", "i=45", false),
    ],
}

const node258 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11879"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "InstanceNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("InstanceNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=258", "i=45", false),
      new ns.Reference("i=261", "i=45", true),
      new ns.Reference("i=267", "i=45", true),
      new ns.Reference("i=276", "i=45", true),
      new ns.Reference("i=279", "i=45", true),
      new ns.Reference("i=11889", "i=38", true),
      new ns.Reference("i=11887", "i=38", true),
      new ns.Reference("i=15069", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
    ],
    BinaryId: "i=11889",
    JsonId: "i=15069",
}

const node259 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11880"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TypeNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TypeNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=258", "i=45", false),
      new ns.Reference("i=264", "i=45", true),
      new ns.Reference("i=270", "i=45", true),
      new ns.Reference("i=273", "i=45", true),
      new ns.Reference("i=282", "i=45", true),
      new ns.Reference("i=11890", "i=38", true),
      new ns.Reference("i=11888", "i=38", true),
      new ns.Reference("i=15070", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
    ],
    BinaryId: "i=11890",
    JsonId: "i=15070",
}

const node270 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11939"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "OpenFileMode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("OpenFileMode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11940", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Read", 1),
      new ns.EnumField("Write", 2),
      new ns.EnumField("EraseExisting", 4),
      new ns.EnumField("Append", 8),
    ],
}

const node272 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11941"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ModelChangeStructureVerbMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ModelChangeStructureVerbMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11942", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("NodeAdded", 1),
      new ns.EnumField("NodeDeleted", 2),
      new ns.EnumField("ReferenceAdded", 4),
      new ns.EnumField("ReferenceDeleted", 8),
      new ns.EnumField("DataTypeChanged", 16),
    ],
}

const node274 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11943"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EndpointUrlListDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EndpointUrlListDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=11957", "i=38", true),
      new ns.Reference("i=11949", "i=38", true),
      new ns.Reference("i=15363", "i=38", true),
    ],
    Definition: [
      new ns.StructField("EndpointUrlList", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=11957",
    JsonId: "i=15363",
}

const node275 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=11944"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NetworkGroupDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NetworkGroupDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=11958", "i=38", true),
      new ns.Reference("i=11950", "i=38", true),
      new ns.Reference("i=15364", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ServerUri", "i=12", "i=12", -1, null),
      new ns.StructField("NetworkPaths", "i=11943", "i=22", 1, null),
    ],
    BinaryId: "i=11958",
    JsonId: "i=15364",
}

const node286 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "String"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("String"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
      new ns.Reference("i=23751", "i=45", true),
      new ns.Reference("i=24263", "i=45", true),
      new ns.Reference("i=12877", "i=45", true),
      new ns.Reference("i=12878", "i=45", true),
      new ns.Reference("i=12879", "i=45", true),
      new ns.Reference("i=12880", "i=45", true),
      new ns.Reference("i=12881", "i=45", true),
      new ns.Reference("i=295", "i=45", true),
      new ns.Reference("i=291", "i=45", true),
    ],
}

const node287 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=120"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NamingRuleType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NamingRuleType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12169", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Mandatory", 1),
      new ns.EnumField("Optional", 2),
      new ns.EnumField("Constraint", 3),
    ],
}

const node307 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12077"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AxisScaleEnumeration"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AxisScaleEnumeration"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12078", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Linear", 0),
      new ns.EnumField("Log", 1),
      new ns.EnumField("Ln", 2),
    ],
}

const node309 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12079"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AxisInformation"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AxisInformation"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12089", "i=38", true),
      new ns.Reference("i=12081", "i=38", true),
      new ns.Reference("i=15379", "i=38", true),
    ],
    Definition: [
      new ns.StructField("EngineeringUnits", "i=887", "i=22", -1, null),
      new ns.StructField("EURange", "i=884", "i=22", -1, null),
      new ns.StructField("Title", "i=21", "i=21", -1, null),
      new ns.StructField("AxisScaleType", "i=12077", "i=29", -1, null),
      new ns.StructField("AxisSteps", "i=11", "i=11", 1, null),
    ],
    BinaryId: "i=12089",
    JsonId: "i=15379",
}

const node310 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12080"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "XVType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("XVType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12090", "i=38", true),
      new ns.Reference("i=12082", "i=38", true),
      new ns.Reference("i=15380", "i=38", true),
    ],
    Definition: [
      new ns.StructField("X", "i=11", "i=11", -1, null),
      new ns.StructField("Value", "i=10", "i=10", -1, null),
    ],
    BinaryId: "i=12090",
    JsonId: "i=15380",
}

const node386 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12171"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ComplexNumberType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ComplexNumberType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12181", "i=38", true),
      new ns.Reference("i=12173", "i=38", true),
      new ns.Reference("i=15377", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Real", "i=10", "i=10", -1, null),
      new ns.StructField("Imaginary", "i=10", "i=10", -1, null),
    ],
    BinaryId: "i=12181",
    JsonId: "i=15377",
}

const node387 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12172"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DoubleComplexNumberType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DoubleComplexNumberType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12182", "i=38", true),
      new ns.Reference("i=12174", "i=38", true),
      new ns.Reference("i=15378", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Real", "i=11", "i=11", -1, null),
      new ns.StructField("Imaginary", "i=11", "i=11", -1, null),
    ],
    BinaryId: "i=12182",
    JsonId: "i=15378",
}

const node396 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12189"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ServerOnNetwork"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ServerOnNetwork"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12207", "i=38", true),
      new ns.Reference("i=12195", "i=38", true),
      new ns.Reference("i=15095", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RecordId", "i=7", "i=7", -1, null),
      new ns.StructField("ServerName", "i=12", "i=12", -1, null),
      new ns.StructField("DiscoveryUrl", "i=12", "i=12", -1, null),
      new ns.StructField("ServerCapabilities", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=12207",
    JsonId: "i=15095",
}

const node397 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12190"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FindServersOnNetworkRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FindServersOnNetworkRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12208", "i=38", true),
      new ns.Reference("i=12196", "i=38", true),
      new ns.Reference("i=15096", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("StartingRecordId", "i=289", "i=7", -1, null),
      new ns.StructField("MaxRecordsToReturn", "i=7", "i=7", -1, null),
      new ns.StructField("ServerCapabilityFilter", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=12208",
    JsonId: "i=15096",
}

const node398 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12191"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FindServersOnNetworkResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FindServersOnNetworkResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12209", "i=38", true),
      new ns.Reference("i=12197", "i=38", true),
      new ns.Reference("i=15097", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("LastCounterResetTime", "i=294", "i=13", -1, null),
      new ns.StructField("Servers", "i=12189", "i=22", 1, null),
    ],
    BinaryId: "i=12209",
    JsonId: "i=15097",
}

const node399 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12193"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RegisterServer2Request"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RegisterServer2Request"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12211", "i=38", true),
      new ns.Reference("i=12199", "i=38", true),
      new ns.Reference("i=15107", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("Server", "i=432", "i=22", -1, null),
      new ns.StructField("DiscoveryConfiguration", "i=22", "i=22", 1, null),
    ],
    BinaryId: "i=12211",
    JsonId: "i=15107",
}

const node400 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12194"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RegisterServer2Response"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RegisterServer2Response"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12212", "i=38", true),
      new ns.Reference("i=12200", "i=38", true),
      new ns.Reference("i=15130", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("ConfigurationResults", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=12212",
    JsonId: "i=15130",
}

const node430 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12552"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TrustListMasks"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TrustListMasks"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12553", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("None", 0),
      new ns.EnumField("TrustedCertificates", 1),
      new ns.EnumField("TrustedCrls", 2),
      new ns.EnumField("IssuerCertificates", 4),
      new ns.EnumField("IssuerCrls", 8),
      new ns.EnumField("All", 15),
    ],
}

const node432 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12554"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TrustListDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TrustListDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12680", "i=38", true),
      new ns.Reference("i=12676", "i=38", true),
      new ns.Reference("i=15044", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedLists", "i=7", "i=7", -1, null),
      new ns.StructField("TrustedCertificates", "i=15", "i=15", 1, null),
      new ns.StructField("TrustedCrls", "i=15", "i=15", 1, null),
      new ns.StructField("IssuerCertificates", "i=15", "i=15", 1, null),
      new ns.StructField("IssuerCrls", "i=15", "i=15", 1, null),
    ],
    BinaryId: "i=12680",
    JsonId: "i=15044",
}

const node512 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12755"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "OptionSet"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("OptionSet"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12765", "i=38", true),
      new ns.Reference("i=12757", "i=38", true),
      new ns.Reference("i=15084", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Value", "i=15", "i=15", -1, null),
      new ns.StructField("ValidBits", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=12765",
    JsonId: "i=15084",
}

const node513 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12756"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Union"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Union"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12766", "i=38", true),
      new ns.Reference("i=12758", "i=38", true),
      new ns.Reference("i=15085", "i=38", true),
    ],
}

const node622 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12877"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NormalizedString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NormalizedString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node623 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12878"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DecimalString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DecimalString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node624 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12879"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DurationString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DurationString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node625 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12880"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TimeString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TimeString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node626 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12881"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DateString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DateString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node633 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12890"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DiscoveryConfiguration"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DiscoveryConfiguration"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=12891", "i=45", true),
      new ns.Reference("i=12900", "i=38", true),
      new ns.Reference("i=12892", "i=38", true),
      new ns.Reference("i=15105", "i=38", true),
    ],
}

const node634 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=12891"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MdnsDiscoveryConfiguration"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MdnsDiscoveryConfiguration"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12890", "i=45", false),
      new ns.Reference("i=12901", "i=38", true),
      new ns.Reference("i=12893", "i=38", true),
      new ns.Reference("i=15106", "i=38", true),
    ],
    Definition: [
      new ns.StructField("MdnsServerName", "i=12", "i=12", -1, null),
      new ns.StructField("ServerCapabilities", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=12901",
    JsonId: "i=15106",
}

const node649 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=13"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DateTime"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DateTime"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
      new ns.Reference("i=294", "i=45", true),
    ],
}

const node860 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Guid"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Guid"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node938 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14273"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishedVariableDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishedVariableDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=14323", "i=38", true),
      new ns.Reference("i=14319", "i=38", true),
      new ns.Reference("i=15060", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PublishedVariable", "i=17", "i=17", -1, null),
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("SamplingIntervalHint", "i=290", "i=11", -1, null),
      new ns.StructField("DeadbandType", "i=7", "i=7", -1, null),
      new ns.StructField("DeadbandValue", "i=11", "i=11", -1, null),
      new ns.StructField("IndexRange", "i=291", "i=12", -1, null),
      new ns.StructField("SubstituteValue", "nil", "nil", -1, null),
      new ns.StructField("MetaDataProperties", "i=20", "i=20", 1, null),
    ],
    BinaryId: "i=14323",
    JsonId: "i=15060",
}

const node977 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14523"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetMetaDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetMetaDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15534", "i=45", false),
      new ns.Reference("i=124", "i=38", true),
      new ns.Reference("i=14794", "i=38", true),
      new ns.Reference("i=15050", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Namespaces", "i=12", "i=12", 1, null),
      new ns.StructField("StructureDataTypes", "i=15487", "i=22", 1, null),
      new ns.StructField("EnumDataTypes", "i=15488", "i=22", 1, null),
      new ns.StructField("SimpleDataTypes", "i=15005", "i=22", 1, null),
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("Fields", "i=14524", "i=22", 1, null),
      new ns.StructField("DataSetClassId", "i=14", "i=14", -1, null),
      new ns.StructField("ConfigurationVersion", "i=14593", "i=22", -1, null),
    ],
    BinaryId: "i=124",
    JsonId: "i=15050",
}

const node978 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14524"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FieldMetaData"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FieldMetaData"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=14839", "i=38", true),
      new ns.Reference("i=14795", "i=38", true),
      new ns.Reference("i=15051", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("FieldFlags", "i=15904", "i=5", -1, null),
      new ns.StructField("BuiltInType", "i=3", "i=3", -1, null),
      new ns.StructField("DataType", "i=17", "i=17", -1, null),
      new ns.StructField("ValueRank", "i=6", "i=6", -1, null),
      new ns.StructField("ArrayDimensions", "i=7", "i=7", 1, null),
      new ns.StructField("MaxStringLength", "i=7", "i=7", -1, null),
      new ns.StructField("DataSetFieldId", "i=14", "i=14", -1, null),
      new ns.StructField("Properties", "i=14533", "i=22", 1, null),
    ],
    BinaryId: "i=14839",
    JsonId: "i=15051",
}

const node979 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14525"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataTypeDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataTypeDescription"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15487", "i=45", true),
      new ns.Reference("i=15488", "i=45", true),
      new ns.Reference("i=15005", "i=45", true),
      new ns.Reference("i=125", "i=38", true),
      new ns.Reference("i=14796", "i=38", true),
      new ns.Reference("i=15057", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("Name", "i=20", "i=20", -1, null),
    ],
    BinaryId: "i=125",
    JsonId: "i=15057",
}

const node981 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14533"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "KeyValuePair"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("KeyValuePair"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=14846", "i=38", true),
      new ns.Reference("i=14802", "i=38", true),
      new ns.Reference("i=15041", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Key", "i=20", "i=20", -1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
    ],
    BinaryId: "i=14846",
    JsonId: "i=15041",
}

const node994 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14593"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ConfigurationVersionDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ConfigurationVersionDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=14847", "i=38", true),
      new ns.Reference("i=14803", "i=38", true),
      new ns.Reference("i=15049", "i=38", true),
    ],
    Definition: [
      new ns.StructField("MajorVersion", "i=20998", "i=7", -1, null),
      new ns.StructField("MinorVersion", "i=20998", "i=7", -1, null),
    ],
    BinaryId: "i=14847",
    JsonId: "i=15049",
}

const node1002 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14647"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubState"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubState"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=14648", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Disabled", 0),
      new ns.EnumField("Paused", 1),
      new ns.EnumField("Operational", 2),
      new ns.EnumField("Error", 3),
      new ns.EnumField("PreOperational", 4),
    ],
}

const node1004 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=14744"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FieldTargetDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FieldTargetDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=14848", "i=38", true),
      new ns.Reference("i=14804", "i=38", true),
      new ns.Reference("i=15061", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataSetFieldId", "i=14", "i=14", -1, null),
      new ns.StructField("ReceiverIndexRange", "i=291", "i=12", -1, null),
      new ns.StructField("TargetNodeId", "i=17", "i=17", -1, null),
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("WriteIndexRange", "i=291", "i=12", -1, null),
      new ns.StructField("OverrideValueHandling", "i=15874", "i=29", -1, null),
      new ns.StructField("OverrideValue", "nil", "nil", -1, null),
    ],
    BinaryId: "i=14848",
    JsonId: "i=15061",
}

const node1037 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ByteString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ByteString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
      new ns.Reference("i=30", "i=45", true),
      new ns.Reference("i=16307", "i=45", true),
      new ns.Reference("i=311", "i=45", true),
      new ns.Reference("i=521", "i=45", true),
    ],
}

const node1042 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15005"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SimpleTypeDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SimpleTypeDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=14525", "i=45", false),
      new ns.Reference("i=15421", "i=38", true),
      new ns.Reference("i=15529", "i=38", true),
      new ns.Reference("i=15700", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("Name", "i=20", "i=20", -1, null),
      new ns.StructField("BaseDataType", "i=17", "i=17", -1, null),
      new ns.StructField("BuiltInType", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=15421",
    JsonId: "i=15700",
}

const node1043 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15006"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UABinaryFileDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UABinaryFileDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15534", "i=45", false),
      new ns.Reference("i=15422", "i=38", true),
      new ns.Reference("i=15531", "i=38", true),
      new ns.Reference("i=15714", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Namespaces", "i=12", "i=12", 1, null),
      new ns.StructField("StructureDataTypes", "i=15487", "i=22", 1, null),
      new ns.StructField("EnumDataTypes", "i=15488", "i=22", 1, null),
      new ns.StructField("SimpleDataTypes", "i=15005", "i=22", 1, null),
      new ns.StructField("SchemaLocation", "i=12", "i=12", -1, null),
      new ns.StructField("FileHeader", "i=14533", "i=22", 1, null),
      new ns.StructField("Body", "nil", "nil", -1, null),
    ],
    BinaryId: "i=15422",
    JsonId: "i=15714",
}

const node1044 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15007"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrokerConnectionTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrokerConnectionTransportDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15618", "i=45", false),
      new ns.Reference("i=15479", "i=38", true),
      new ns.Reference("i=15579", "i=38", true),
      new ns.Reference("i=15726", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResourceUri", "i=12", "i=12", -1, null),
      new ns.StructField("AuthenticationProfileUri", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=15479",
    JsonId: "i=15726",
}

const node1045 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15008"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrokerTransportQualityOfService"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrokerTransportQualityOfService"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15009", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("NotSpecified", 0),
      new ns.EnumField("BestEffort", 1),
      new ns.EnumField("AtLeastOnce", 2),
      new ns.EnumField("AtMostOnce", 3),
      new ns.EnumField("ExactlyOnce", 4),
    ],
}

const node1052 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15031"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AccessLevelType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AccessLevelType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15032", "i=46", true),
      new ns.Reference("i=3", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("CurrentRead", 0),
      new ns.EnumField("CurrentWrite", 1),
      new ns.EnumField("HistoryRead", 2),
      new ns.EnumField("HistoryWrite", 3),
      new ns.EnumField("SemanticChange", 4),
      new ns.EnumField("StatusWrite", 5),
      new ns.EnumField("TimestampWrite", 6),
    ],
}

const node1054 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15033"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EventNotifierType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EventNotifierType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15034", "i=46", true),
      new ns.Reference("i=3", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("SubscribeToEvents", 0),
      new ns.EnumField("HistoryRead", 2),
      new ns.EnumField("HistoryWrite", 3),
    ],
}

const node1377 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15406"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AccessLevelExType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AccessLevelExType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15407", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("CurrentRead", 0),
      new ns.EnumField("CurrentWrite", 1),
      new ns.EnumField("HistoryRead", 2),
      new ns.EnumField("HistoryWrite", 3),
      new ns.EnumField("SemanticChange", 4),
      new ns.EnumField("StatusWrite", 5),
      new ns.EnumField("TimestampWrite", 6),
      new ns.EnumField("NonatomicRead", 8),
      new ns.EnumField("NonatomicWrite", 9),
      new ns.EnumField("WriteFullArrayOnly", 10),
      new ns.EnumField("NoSubDataTypes", 11),
      new ns.EnumField("NonVolatile", 12),
      new ns.EnumField("Constant", 13),
    ],
}

const node1426 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15480"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "WriterGroupDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("WriterGroupDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15609", "i=45", false),
      new ns.Reference("i=21150", "i=38", true),
      new ns.Reference("i=21174", "i=38", true),
      new ns.Reference("i=21198", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("SecurityGroupId", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityKeyServices", "i=312", "i=22", 1, null),
      new ns.StructField("MaxNetworkMessageSize", "i=7", "i=7", -1, null),
      new ns.StructField("GroupProperties", "i=14533", "i=22", 1, null),
      new ns.StructField("WriterGroupId", "i=5", "i=5", -1, null),
      new ns.StructField("PublishingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("KeepAliveTime", "i=290", "i=11", -1, null),
      new ns.StructField("Priority", "i=3", "i=3", -1, null),
      new ns.StructField("LocaleIds", "i=295", "i=12", 1, null),
      new ns.StructField("HeaderLayoutUri", "i=12", "i=12", -1, null),
      new ns.StructField("TransportSettings", "i=15611", "i=22", -1, null),
      new ns.StructField("MessageSettings", "i=15616", "i=22", -1, null),
      new ns.StructField("DataSetWriters", "i=15597", "i=22", 1, null),
    ],
    BinaryId: "i=21150",
    JsonId: "i=21198",
}

const node1433 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15487"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StructureDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StructureDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=14525", "i=45", false),
      new ns.Reference("i=126", "i=38", true),
      new ns.Reference("i=15589", "i=38", true),
      new ns.Reference("i=15058", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("Name", "i=20", "i=20", -1, null),
      new ns.StructField("StructureDefinition", "i=99", "i=22", -1, null),
    ],
    BinaryId: "i=126",
    JsonId: "i=15058",
}

const node1434 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15488"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EnumDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EnumDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=14525", "i=45", false),
      new ns.Reference("i=127", "i=38", true),
      new ns.Reference("i=15590", "i=38", true),
      new ns.Reference("i=15059", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("Name", "i=20", "i=20", -1, null),
      new ns.StructField("EnumDefinition", "i=100", "i=22", -1, null),
      new ns.StructField("BuiltInType", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=127",
    JsonId: "i=15059",
}

const node1443 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15502"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NetworkAddressDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NetworkAddressDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15510", "i=45", true),
      new ns.Reference("i=21151", "i=38", true),
      new ns.Reference("i=21175", "i=38", true),
      new ns.Reference("i=21199", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NetworkInterface", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=21151",
    JsonId: "i=21199",
}

const node1444 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15510"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NetworkAddressUrlDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NetworkAddressUrlDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15502", "i=45", false),
      new ns.Reference("i=21152", "i=38", true),
      new ns.Reference("i=21176", "i=38", true),
      new ns.Reference("i=21200", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NetworkInterface", "i=12", "i=12", -1, null),
      new ns.StructField("Url", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=21152",
    JsonId: "i=21200",
}

const node1446 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15520"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReaderGroupDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReaderGroupDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15609", "i=45", false),
      new ns.Reference("i=21153", "i=38", true),
      new ns.Reference("i=21177", "i=38", true),
      new ns.Reference("i=21201", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("SecurityGroupId", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityKeyServices", "i=312", "i=22", 1, null),
      new ns.StructField("MaxNetworkMessageSize", "i=7", "i=7", -1, null),
      new ns.StructField("GroupProperties", "i=14533", "i=22", 1, null),
      new ns.StructField("TransportSettings", "i=15621", "i=22", -1, null),
      new ns.StructField("MessageSettings", "i=15622", "i=22", -1, null),
      new ns.StructField("DataSetReaders", "i=15623", "i=22", 1, null),
    ],
    BinaryId: "i=21153",
    JsonId: "i=21201",
}

const node1450 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15528"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EndpointType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EndpointType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15671", "i=38", true),
      new ns.Reference("i=15949", "i=38", true),
      new ns.Reference("i=16150", "i=38", true),
    ],
    Definition: [
      new ns.StructField("EndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("SecurityPolicyUri", "i=12", "i=12", -1, null),
      new ns.StructField("TransportProfileUri", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=15671",
    JsonId: "i=16150",
}

const node1452 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15530"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubConfigurationDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubConfigurationDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=23602", "i=45", true),
      new ns.Reference("i=21154", "i=38", true),
      new ns.Reference("i=21178", "i=38", true),
      new ns.Reference("i=21202", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PublishedDataSets", "i=15578", "i=22", 1, null),
      new ns.StructField("Connections", "i=15617", "i=22", 1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=21154",
    JsonId: "i=21202",
}

const node1454 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15532"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DatagramWriterGroupTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DatagramWriterGroupTransportDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15611", "i=45", false),
      new ns.Reference("i=23613", "i=45", true),
      new ns.Reference("i=21155", "i=38", true),
      new ns.Reference("i=21179", "i=38", true),
      new ns.Reference("i=21203", "i=38", true),
    ],
    Definition: [
      new ns.StructField("MessageRepeatCount", "i=3", "i=3", -1, null),
      new ns.StructField("MessageRepeatDelay", "i=290", "i=11", -1, null),
    ],
    BinaryId: "i=21155",
    JsonId: "i=21203",
}

const node1456 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15534"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataTypeSchemaHeader"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataTypeSchemaHeader"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15006", "i=45", true),
      new ns.Reference("i=14523", "i=45", true),
      new ns.Reference("i=15676", "i=38", true),
      new ns.Reference("i=15950", "i=38", true),
      new ns.Reference("i=16151", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Namespaces", "i=12", "i=12", 1, null),
      new ns.StructField("StructureDataTypes", "i=15487", "i=22", 1, null),
      new ns.StructField("EnumDataTypes", "i=15488", "i=22", 1, null),
      new ns.StructField("SimpleDataTypes", "i=15005", "i=22", 1, null),
    ],
    BinaryId: "i=15676",
    JsonId: "i=16151",
}

const node1467 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15578"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishedDataSetDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishedDataSetDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15677", "i=38", true),
      new ns.Reference("i=15951", "i=38", true),
      new ns.Reference("i=16152", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("DataSetFolder", "i=12", "i=12", 1, null),
      new ns.StructField("DataSetMetaData", "i=14523", "i=22", -1, null),
      new ns.StructField("ExtensionFields", "i=14533", "i=22", 1, null),
      new ns.StructField("DataSetSource", "i=15580", "i=22", -1, null),
    ],
    BinaryId: "i=15677",
    JsonId: "i=16152",
}

const node1469 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15580"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishedDataSetSourceDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishedDataSetSourceDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15581", "i=45", true),
      new ns.Reference("i=15582", "i=45", true),
      new ns.Reference("i=25269", "i=45", true),
      new ns.Reference("i=15678", "i=38", true),
      new ns.Reference("i=15952", "i=38", true),
      new ns.Reference("i=16153", "i=38", true),
    ],
}

const node1470 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15581"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishedDataItemsDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishedDataItemsDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15580", "i=45", false),
      new ns.Reference("i=15679", "i=38", true),
      new ns.Reference("i=15953", "i=38", true),
      new ns.Reference("i=16154", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PublishedData", "i=14273", "i=22", 1, null),
    ],
    BinaryId: "i=15679",
    JsonId: "i=16154",
}

const node1471 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15582"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishedEventsDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishedEventsDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15580", "i=45", false),
      new ns.Reference("i=15681", "i=38", true),
      new ns.Reference("i=15954", "i=38", true),
      new ns.Reference("i=16155", "i=38", true),
    ],
    Definition: [
      new ns.StructField("EventNotifier", "i=17", "i=17", -1, null),
      new ns.StructField("SelectedFields", "i=601", "i=22", 1, null),
      new ns.StructField("Filter", "i=586", "i=22", -1, null),
    ],
    BinaryId: "i=15681",
    JsonId: "i=16155",
}

const node1472 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15583"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetFieldContentMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetFieldContentMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15584", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("StatusCode", 0),
      new ns.EnumField("SourceTimestamp", 1),
      new ns.EnumField("ServerTimestamp", 2),
      new ns.EnumField("SourcePicoSeconds", 3),
      new ns.EnumField("ServerPicoSeconds", 4),
      new ns.EnumField("RawData", 5),
    ],
}

const node1480 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15597"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetWriterDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetWriterDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15682", "i=38", true),
      new ns.Reference("i=15955", "i=38", true),
      new ns.Reference("i=16156", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
      new ns.StructField("DataSetWriterId", "i=5", "i=5", -1, null),
      new ns.StructField("DataSetFieldContentMask", "i=15583", "i=7", -1, null),
      new ns.StructField("KeyFrameCount", "i=7", "i=7", -1, null),
      new ns.StructField("DataSetName", "i=12", "i=12", -1, null),
      new ns.StructField("DataSetWriterProperties", "i=14533", "i=22", 1, null),
      new ns.StructField("TransportSettings", "i=15598", "i=22", -1, null),
      new ns.StructField("MessageSettings", "i=15605", "i=22", -1, null),
    ],
    BinaryId: "i=15682",
    JsonId: "i=16156",
}

const node1481 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15598"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetWriterTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetWriterTransportDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15669", "i=45", true),
      new ns.Reference("i=15683", "i=38", true),
      new ns.Reference("i=15956", "i=38", true),
      new ns.Reference("i=16157", "i=38", true),
    ],
}

const node1484 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15605"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetWriterMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetWriterMessageDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15652", "i=45", true),
      new ns.Reference("i=15664", "i=45", true),
      new ns.Reference("i=15688", "i=38", true),
      new ns.Reference("i=15987", "i=38", true),
      new ns.Reference("i=16158", "i=38", true),
    ],
}

const node1488 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15609"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubGroupDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubGroupDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15480", "i=45", true),
      new ns.Reference("i=15520", "i=45", true),
      new ns.Reference("i=15689", "i=38", true),
      new ns.Reference("i=15988", "i=38", true),
      new ns.Reference("i=16159", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("SecurityGroupId", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityKeyServices", "i=312", "i=22", 1, null),
      new ns.StructField("MaxNetworkMessageSize", "i=7", "i=7", -1, null),
      new ns.StructField("GroupProperties", "i=14533", "i=22", 1, null),
    ],
    BinaryId: "i=15689",
    JsonId: "i=16159",
}

const node1489 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15611"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "WriterGroupTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("WriterGroupTransportDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15532", "i=45", true),
      new ns.Reference("i=15667", "i=45", true),
      new ns.Reference("i=15691", "i=38", true),
      new ns.Reference("i=15990", "i=38", true),
      new ns.Reference("i=16161", "i=38", true),
    ],
}

const node1490 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15616"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "WriterGroupMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("WriterGroupMessageDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15645", "i=45", true),
      new ns.Reference("i=15657", "i=45", true),
      new ns.Reference("i=15693", "i=38", true),
      new ns.Reference("i=15991", "i=38", true),
      new ns.Reference("i=16280", "i=38", true),
    ],
}

const node1491 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15617"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubConnectionDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubConnectionDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15694", "i=38", true),
      new ns.Reference("i=15992", "i=38", true),
      new ns.Reference("i=16281", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
      new ns.StructField("PublisherId", "nil", "nil", -1, null),
      new ns.StructField("TransportProfileUri", "i=12", "i=12", -1, null),
      new ns.StructField("Address", "i=15502", "i=22", -1, null),
      new ns.StructField("ConnectionProperties", "i=14533", "i=22", 1, null),
      new ns.StructField("TransportSettings", "i=15618", "i=22", -1, null),
      new ns.StructField("WriterGroups", "i=15480", "i=22", 1, null),
      new ns.StructField("ReaderGroups", "i=15520", "i=22", 1, null),
    ],
    BinaryId: "i=15694",
    JsonId: "i=16281",
}

const node1492 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15618"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ConnectionTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ConnectionTransportDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=17467", "i=45", true),
      new ns.Reference("i=15007", "i=45", true),
      new ns.Reference("i=15695", "i=38", true),
      new ns.Reference("i=15993", "i=38", true),
      new ns.Reference("i=16282", "i=38", true),
    ],
}

const node1494 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15621"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReaderGroupTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReaderGroupTransportDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15701", "i=38", true),
      new ns.Reference("i=15995", "i=38", true),
      new ns.Reference("i=16284", "i=38", true),
    ],
}

const node1495 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15622"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReaderGroupMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReaderGroupMessageDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15702", "i=38", true),
      new ns.Reference("i=15996", "i=38", true),
      new ns.Reference("i=16285", "i=38", true),
    ],
}

const node1496 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15623"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetReaderDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetReaderDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15703", "i=38", true),
      new ns.Reference("i=16007", "i=38", true),
      new ns.Reference("i=16286", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
      new ns.StructField("PublisherId", "nil", "nil", -1, null),
      new ns.StructField("WriterGroupId", "i=5", "i=5", -1, null),
      new ns.StructField("DataSetWriterId", "i=5", "i=5", -1, null),
      new ns.StructField("DataSetMetaData", "i=14523", "i=22", -1, null),
      new ns.StructField("DataSetFieldContentMask", "i=15583", "i=7", -1, null),
      new ns.StructField("MessageReceiveTimeout", "i=290", "i=11", -1, null),
      new ns.StructField("KeyFrameCount", "i=7", "i=7", -1, null),
      new ns.StructField("HeaderLayoutUri", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("SecurityGroupId", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityKeyServices", "i=312", "i=22", 1, null),
      new ns.StructField("DataSetReaderProperties", "i=14533", "i=22", 1, null),
      new ns.StructField("TransportSettings", "i=15628", "i=22", -1, null),
      new ns.StructField("MessageSettings", "i=15629", "i=22", -1, null),
      new ns.StructField("SubscribedDataSet", "i=15630", "i=22", -1, null),
    ],
    BinaryId: "i=15703",
    JsonId: "i=16286",
}

const node1501 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15628"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetReaderTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetReaderTransportDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=23614", "i=45", true),
      new ns.Reference("i=15670", "i=45", true),
      new ns.Reference("i=15705", "i=38", true),
      new ns.Reference("i=16008", "i=38", true),
      new ns.Reference("i=16287", "i=38", true),
    ],
}

const node1502 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15629"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetReaderMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetReaderMessageDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15653", "i=45", true),
      new ns.Reference("i=15665", "i=45", true),
      new ns.Reference("i=15706", "i=38", true),
      new ns.Reference("i=16009", "i=38", true),
      new ns.Reference("i=16288", "i=38", true),
    ],
}

const node1503 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15630"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SubscribedDataSetDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SubscribedDataSetDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15631", "i=45", true),
      new ns.Reference("i=15635", "i=45", true),
      new ns.Reference("i=23599", "i=45", true),
      new ns.Reference("i=23600", "i=45", true),
      new ns.Reference("i=15707", "i=38", true),
      new ns.Reference("i=16010", "i=38", true),
      new ns.Reference("i=16308", "i=38", true),
    ],
}

const node1504 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15631"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TargetVariablesDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TargetVariablesDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15630", "i=45", false),
      new ns.Reference("i=15712", "i=38", true),
      new ns.Reference("i=16011", "i=38", true),
      new ns.Reference("i=16310", "i=38", true),
    ],
    Definition: [
      new ns.StructField("TargetVariables", "i=14744", "i=22", 1, null),
    ],
    BinaryId: "i=15712",
    JsonId: "i=16310",
}

const node1505 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15632"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "IdentityCriteriaType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("IdentityCriteriaType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15633", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("UserName", 1),
      new ns.EnumField("Thumbprint", 2),
      new ns.EnumField("Role", 3),
      new ns.EnumField("GroupId", 4),
      new ns.EnumField("Anonymous", 5),
      new ns.EnumField("AuthenticatedUser", 6),
      new ns.EnumField("Application", 7),
      new ns.EnumField("X509Subject", 8),
    ],
}

const node1507 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15634"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "IdentityMappingRuleType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("IdentityMappingRuleType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15736", "i=38", true),
      new ns.Reference("i=15728", "i=38", true),
      new ns.Reference("i=15042", "i=38", true),
    ],
    Definition: [
      new ns.StructField("CriteriaType", "i=15632", "i=29", -1, null),
      new ns.StructField("Criteria", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=15736",
    JsonId: "i=15042",
}

const node1508 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15635"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SubscribedDataSetMirrorDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SubscribedDataSetMirrorDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15630", "i=45", false),
      new ns.Reference("i=15713", "i=38", true),
      new ns.Reference("i=16012", "i=38", true),
      new ns.Reference("i=16311", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ParentNodeName", "i=12", "i=12", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
    ],
    BinaryId: "i=15713",
    JsonId: "i=16311",
}

const node1511 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15642"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UadpNetworkMessageContentMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UadpNetworkMessageContentMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15643", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("PublisherId", 0),
      new ns.EnumField("GroupHeader", 1),
      new ns.EnumField("WriterGroupId", 2),
      new ns.EnumField("GroupVersion", 3),
      new ns.EnumField("NetworkMessageNumber", 4),
      new ns.EnumField("SequenceNumber", 5),
      new ns.EnumField("PayloadHeader", 6),
      new ns.EnumField("Timestamp", 7),
      new ns.EnumField("PicoSeconds", 8),
      new ns.EnumField("DataSetClassId", 9),
      new ns.EnumField("PromotedFields", 10),
    ],
}

const node1514 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15645"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UadpWriterGroupMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UadpWriterGroupMessageDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15616", "i=45", false),
      new ns.Reference("i=15715", "i=38", true),
      new ns.Reference("i=16014", "i=38", true),
      new ns.Reference("i=16323", "i=38", true),
    ],
    Definition: [
      new ns.StructField("GroupVersion", "i=20998", "i=7", -1, null),
      new ns.StructField("DataSetOrdering", "i=20408", "i=29", -1, null),
      new ns.StructField("NetworkMessageContentMask", "i=15642", "i=7", -1, null),
      new ns.StructField("SamplingOffset", "i=290", "i=11", -1, null),
      new ns.StructField("PublishingOffset", "i=290", "i=11", 1, null),
    ],
    BinaryId: "i=15715",
    JsonId: "i=16323",
}

const node1515 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15646"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UadpDataSetMessageContentMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UadpDataSetMessageContentMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15647", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Timestamp", 0),
      new ns.EnumField("PicoSeconds", 1),
      new ns.EnumField("Status", 2),
      new ns.EnumField("MajorVersion", 3),
      new ns.EnumField("MinorVersion", 4),
      new ns.EnumField("SequenceNumber", 5),
    ],
}

const node1521 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15652"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UadpDataSetWriterMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UadpDataSetWriterMessageDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15605", "i=45", false),
      new ns.Reference("i=15717", "i=38", true),
      new ns.Reference("i=16015", "i=38", true),
      new ns.Reference("i=16391", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataSetMessageContentMask", "i=15646", "i=7", -1, null),
      new ns.StructField("ConfiguredSize", "i=5", "i=5", -1, null),
      new ns.StructField("NetworkMessageNumber", "i=5", "i=5", -1, null),
      new ns.StructField("DataSetOffset", "i=5", "i=5", -1, null),
    ],
    BinaryId: "i=15717",
    JsonId: "i=16391",
}

const node1522 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15653"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UadpDataSetReaderMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UadpDataSetReaderMessageDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15629", "i=45", false),
      new ns.Reference("i=15718", "i=38", true),
      new ns.Reference("i=16016", "i=38", true),
      new ns.Reference("i=16392", "i=38", true),
    ],
    Definition: [
      new ns.StructField("GroupVersion", "i=20998", "i=7", -1, null),
      new ns.StructField("NetworkMessageNumber", "i=5", "i=5", -1, null),
      new ns.StructField("DataSetOffset", "i=5", "i=5", -1, null),
      new ns.StructField("DataSetClassId", "i=14", "i=14", -1, null),
      new ns.StructField("NetworkMessageContentMask", "i=15642", "i=7", -1, null),
      new ns.StructField("DataSetMessageContentMask", "i=15646", "i=7", -1, null),
      new ns.StructField("PublishingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("ReceiveOffset", "i=290", "i=11", -1, null),
      new ns.StructField("ProcessingOffset", "i=290", "i=11", -1, null),
    ],
    BinaryId: "i=15718",
    JsonId: "i=16392",
}

const node1523 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15654"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "JsonNetworkMessageContentMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("JsonNetworkMessageContentMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15655", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("NetworkMessageHeader", 0),
      new ns.EnumField("DataSetMessageHeader", 1),
      new ns.EnumField("SingleDataSetMessage", 2),
      new ns.EnumField("PublisherId", 3),
      new ns.EnumField("DataSetClassId", 4),
      new ns.EnumField("ReplyTo", 5),
    ],
}

const node1526 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15657"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "JsonWriterGroupMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("JsonWriterGroupMessageDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15616", "i=45", false),
      new ns.Reference("i=15719", "i=38", true),
      new ns.Reference("i=16017", "i=38", true),
      new ns.Reference("i=16393", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NetworkMessageContentMask", "i=15654", "i=7", -1, null),
    ],
    BinaryId: "i=15719",
    JsonId: "i=16393",
}

const node1527 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15658"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "JsonDataSetMessageContentMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("JsonDataSetMessageContentMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15659", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("DataSetWriterId", 0),
      new ns.EnumField("MetaDataVersion", 1),
      new ns.EnumField("SequenceNumber", 2),
      new ns.EnumField("Timestamp", 3),
      new ns.EnumField("Status", 4),
      new ns.EnumField("MessageType", 5),
      new ns.EnumField("DataSetWriterName", 6),
      new ns.EnumField("ReversibleFieldEncoding", 7),
    ],
}

const node1533 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15664"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "JsonDataSetWriterMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("JsonDataSetWriterMessageDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15605", "i=45", false),
      new ns.Reference("i=15724", "i=38", true),
      new ns.Reference("i=16018", "i=38", true),
      new ns.Reference("i=16394", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataSetMessageContentMask", "i=15658", "i=7", -1, null),
    ],
    BinaryId: "i=15724",
    JsonId: "i=16394",
}

const node1534 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15665"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "JsonDataSetReaderMessageDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("JsonDataSetReaderMessageDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15629", "i=45", false),
      new ns.Reference("i=15725", "i=38", true),
      new ns.Reference("i=16019", "i=38", true),
      new ns.Reference("i=16404", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NetworkMessageContentMask", "i=15654", "i=7", -1, null),
      new ns.StructField("DataSetMessageContentMask", "i=15658", "i=7", -1, null),
    ],
    BinaryId: "i=15725",
    JsonId: "i=16404",
}

const node1535 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15667"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrokerWriterGroupTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrokerWriterGroupTransportDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15611", "i=45", false),
      new ns.Reference("i=15727", "i=38", true),
      new ns.Reference("i=16021", "i=38", true),
      new ns.Reference("i=16524", "i=38", true),
    ],
    Definition: [
      new ns.StructField("QueueName", "i=12", "i=12", -1, null),
      new ns.StructField("ResourceUri", "i=12", "i=12", -1, null),
      new ns.StructField("AuthenticationProfileUri", "i=12", "i=12", -1, null),
      new ns.StructField("RequestedDeliveryGuarantee", "i=15008", "i=29", -1, null),
    ],
    BinaryId: "i=15727",
    JsonId: "i=16524",
}

const node1537 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15669"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrokerDataSetWriterTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrokerDataSetWriterTransportDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15598", "i=45", false),
      new ns.Reference("i=15729", "i=38", true),
      new ns.Reference("i=16022", "i=38", true),
      new ns.Reference("i=16525", "i=38", true),
    ],
    Definition: [
      new ns.StructField("QueueName", "i=12", "i=12", -1, null),
      new ns.StructField("ResourceUri", "i=12", "i=12", -1, null),
      new ns.StructField("AuthenticationProfileUri", "i=12", "i=12", -1, null),
      new ns.StructField("RequestedDeliveryGuarantee", "i=15008", "i=29", -1, null),
      new ns.StructField("MetaDataQueueName", "i=12", "i=12", -1, null),
      new ns.StructField("MetaDataUpdateTime", "i=290", "i=11", -1, null),
    ],
    BinaryId: "i=15729",
    JsonId: "i=16525",
}

const node1538 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15670"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrokerDataSetReaderTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrokerDataSetReaderTransportDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15628", "i=45", false),
      new ns.Reference("i=15733", "i=38", true),
      new ns.Reference("i=16023", "i=38", true),
      new ns.Reference("i=16526", "i=38", true),
    ],
    Definition: [
      new ns.StructField("QueueName", "i=12", "i=12", -1, null),
      new ns.StructField("ResourceUri", "i=12", "i=12", -1, null),
      new ns.StructField("AuthenticationProfileUri", "i=12", "i=12", -1, null),
      new ns.StructField("RequestedDeliveryGuarantee", "i=15008", "i=29", -1, null),
      new ns.StructField("MetaDataQueueName", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=15733",
    JsonId: "i=16526",
}

const node1664 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15874"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "OverrideValueHandling"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("OverrideValueHandling"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15875", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Disabled", 0),
      new ns.EnumField("LastUsableValue", 1),
      new ns.EnumField("OverrideValue", 2),
    ],
}

const node1673 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15901"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SessionlessInvokeRequestType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SessionlessInvokeRequestType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=15903", "i=38", true),
      new ns.Reference("i=15902", "i=38", true),
      new ns.Reference("i=15091", "i=38", true),
    ],
    Definition: [
      new ns.StructField("UrisVersion", "i=20998", "i=7", -1, null),
      new ns.StructField("NamespaceUris", "i=12", "i=12", 1, null),
      new ns.StructField("ServerUris", "i=12", "i=12", 1, null),
      new ns.StructField("LocaleIds", "i=295", "i=12", 1, null),
      new ns.StructField("ServiceId", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=15903",
    JsonId: "i=15091",
}

const node1676 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=15904"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetFieldFlags"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetFieldFlags"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15577", "i=46", true),
      new ns.Reference("i=5", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("PromotedField", 0),
    ],
}

const node1730 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=16"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "XmlElement"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("XmlElement"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node1923 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=16307"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AudioDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AudioDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15", "i=45", false),
    ],
}

const node1929 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=16313"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AdditionalParametersType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AdditionalParametersType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=17537", "i=38", true),
      new ns.Reference("i=17541", "i=38", true),
      new ns.Reference("i=17547", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Parameters", "i=14533", "i=22", 1, null),
    ],
    BinaryId: "i=17537",
    JsonId: "i=17547",
}

const node2048 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NodeId"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NodeId"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
      new ns.Reference("i=388", "i=45", true),
    ],
}

const node2165 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17467"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DatagramConnectionTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DatagramConnectionTransportDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15618", "i=45", false),
      new ns.Reference("i=23612", "i=45", true),
      new ns.Reference("i=17468", "i=38", true),
      new ns.Reference("i=17472", "i=38", true),
      new ns.Reference("i=17476", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DiscoveryAddress", "i=15502", "i=22", -1, null),
    ],
    BinaryId: "i=17468",
    JsonId: "i=17476",
}

const node2203 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17545"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RsaEncryptedSecret"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RsaEncryptedSecret"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node2204 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17546"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EccEncryptedSecret"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EccEncryptedSecret"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node2206 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17548"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EphemeralKeyType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EphemeralKeyType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=17549", "i=38", true),
      new ns.Reference("i=17553", "i=38", true),
      new ns.Reference("i=17557", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PublicKey", "i=15", "i=15", -1, null),
      new ns.StructField("Signature", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=17549",
    JsonId: "i=17557",
}

const node2226 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17588"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Index"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Index"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7", "i=45", false),
    ],
}

const node2240 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17606"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "GenericAttributeValue"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("GenericAttributeValue"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=17610", "i=38", true),
      new ns.Reference("i=17608", "i=38", true),
      new ns.Reference("i=15163", "i=38", true),
    ],
    Definition: [
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
    ],
    BinaryId: "i=17610",
    JsonId: "i=15163",
}

const node2241 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17607"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "GenericAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("GenericAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=17611", "i=38", true),
      new ns.Reference("i=17609", "i=38", true),
      new ns.Reference("i=15164", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("AttributeValues", "i=17606", "i=22", 1, null),
    ],
    BinaryId: "i=17611",
    JsonId: "i=15164",
}

const node2322 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=17861"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DecimalDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DecimalDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=17863", "i=38", true),
      new ns.Reference("i=17862", "i=38", true),
      new ns.Reference("i=15045", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Scale", "i=4", "i=4", -1, null),
      new ns.StructField("Value", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=17863",
    JsonId: "i=15045",
}

const node2359 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ExpandedNodeId"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ExpandedNodeId"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node2478 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18806"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RationalNumber"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RationalNumber"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=18815", "i=38", true),
      new ns.Reference("i=18851", "i=38", true),
      new ns.Reference("i=19064", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Numerator", "i=6", "i=6", -1, null),
      new ns.StructField("Denominator", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=18815",
    JsonId: "i=19064",
}

const node2479 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18807"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Vector"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Vector"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=18808", "i=45", true),
      new ns.Reference("i=18816", "i=38", true),
      new ns.Reference("i=18852", "i=38", true),
      new ns.Reference("i=19065", "i=38", true),
    ],
}

const node2480 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18808"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "3DVector"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("3DVector"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=18807", "i=45", false),
      new ns.Reference("i=18817", "i=38", true),
      new ns.Reference("i=18853", "i=38", true),
      new ns.Reference("i=19066", "i=38", true),
    ],
    Definition: [
      new ns.StructField("X", "i=11", "i=11", -1, null),
      new ns.StructField("Y", "i=11", "i=11", -1, null),
      new ns.StructField("Z", "i=11", "i=11", -1, null),
    ],
    BinaryId: "i=18817",
    JsonId: "i=19066",
}

const node2481 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18809"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CartesianCoordinates"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CartesianCoordinates"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=18810", "i=45", true),
      new ns.Reference("i=18818", "i=38", true),
      new ns.Reference("i=18854", "i=38", true),
      new ns.Reference("i=19067", "i=38", true),
    ],
}

const node2482 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18810"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "3DCartesianCoordinates"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("3DCartesianCoordinates"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=18809", "i=45", false),
      new ns.Reference("i=18819", "i=38", true),
      new ns.Reference("i=18855", "i=38", true),
      new ns.Reference("i=19068", "i=38", true),
    ],
    Definition: [
      new ns.StructField("X", "i=11", "i=11", -1, null),
      new ns.StructField("Y", "i=11", "i=11", -1, null),
      new ns.StructField("Z", "i=11", "i=11", -1, null),
    ],
    BinaryId: "i=18819",
    JsonId: "i=19068",
}

const node2483 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18811"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Orientation"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Orientation"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=18812", "i=45", true),
      new ns.Reference("i=18820", "i=38", true),
      new ns.Reference("i=18856", "i=38", true),
      new ns.Reference("i=19069", "i=38", true),
    ],
}

const node2484 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18812"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "3DOrientation"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("3DOrientation"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=18811", "i=45", false),
      new ns.Reference("i=18821", "i=38", true),
      new ns.Reference("i=18857", "i=38", true),
      new ns.Reference("i=19070", "i=38", true),
    ],
    Definition: [
      new ns.StructField("A", "i=11", "i=11", -1, null),
      new ns.StructField("B", "i=11", "i=11", -1, null),
      new ns.StructField("C", "i=11", "i=11", -1, null),
    ],
    BinaryId: "i=18821",
    JsonId: "i=19070",
}

const node2485 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18813"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Frame"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Frame"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=18814", "i=45", true),
      new ns.Reference("i=18822", "i=38", true),
      new ns.Reference("i=18858", "i=38", true),
      new ns.Reference("i=19071", "i=38", true),
    ],
}

const node2486 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=18814"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "3DFrame"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("3DFrame"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=18813", "i=45", false),
      new ns.Reference("i=18823", "i=38", true),
      new ns.Reference("i=18859", "i=38", true),
      new ns.Reference("i=19072", "i=38", true),
    ],
    Definition: [
      new ns.StructField("CartesianCoordinates", "i=18810", "i=22", -1, null),
      new ns.StructField("Orientation", "i=18812", "i=22", -1, null),
    ],
    BinaryId: "i=18823",
    JsonId: "i=19072",
}

const node2518 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=19"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StatusCode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StatusCode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node2749 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=19723"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DiagnosticsLevel"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DiagnosticsLevel"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=19724", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Basic", 0),
      new ns.EnumField("Advanced", 1),
      new ns.EnumField("Info", 2),
      new ns.EnumField("Log", 3),
      new ns.EnumField("Debug", 4),
    ],
}

const node2756 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=19730"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubDiagnosticsCounterClassification"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubDiagnosticsCounterClassification"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=19731", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Information", 0),
      new ns.EnumField("Error", 1),
    ],
}

const node2816 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=2"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SByte"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SByte"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=27", "i=45", false),
    ],
}

const node2817 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=20"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QualifiedName"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QualifiedName"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node2818 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=2000"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ImageBMP"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ImageBMP"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=30", "i=45", false),
    ],
}

const node2819 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=2001"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ImageGIF"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ImageGIF"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=30", "i=45", false),
    ],
}

const node2826 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=2002"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ImageJPG"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ImageJPG"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=30", "i=45", false),
    ],
}

const node2835 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=2003"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ImagePNG"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ImagePNG"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=30", "i=45", false),
    ],
}

const node2936 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=20408"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataSetOrderingType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataSetOrderingType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15641", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Undefined", 0),
      new ns.EnumField("AscendingWriterId", 1),
      new ns.EnumField("AscendingWriterIdSingle", 2),
    ],
}

const node2991 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=20998"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "VersionTime"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("VersionTime"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7", "i=45", false),
    ],
}

const node2992 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=20999"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SessionlessInvokeResponseType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SessionlessInvokeResponseType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=21001", "i=38", true),
      new ns.Reference("i=21000", "i=38", true),
      new ns.Reference("i=15092", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NamespaceUris", "i=12", "i=12", 1, null),
      new ns.StructField("ServerUris", "i=12", "i=12", 1, null),
      new ns.StructField("ServiceId", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=21001",
    JsonId: "i=15092",
}

const node2993 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=21"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "LocalizedText"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("LocalizedText"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node3199 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=22"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Structure"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Structure"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
      new ns.Reference("i=12756", "i=45", true),
      new ns.Reference("i=14533", "i=45", true),
      new ns.Reference("i=16313", "i=45", true),
      new ns.Reference("i=17548", "i=45", true),
      new ns.Reference("i=15528", "i=45", true),
      new ns.Reference("i=18806", "i=45", true),
      new ns.Reference("i=18807", "i=45", true),
      new ns.Reference("i=18809", "i=45", true),
      new ns.Reference("i=18811", "i=45", true),
      new ns.Reference("i=18813", "i=45", true),
      new ns.Reference("i=15634", "i=45", true),
      new ns.Reference("i=23498", "i=45", true),
      new ns.Reference("i=12554", "i=45", true),
      new ns.Reference("i=17861", "i=45", true),
      new ns.Reference("i=15534", "i=45", true),
      new ns.Reference("i=14525", "i=45", true),
      new ns.Reference("i=24105", "i=45", true),
      new ns.Reference("i=24106", "i=45", true),
      new ns.Reference("i=24107", "i=45", true),
      new ns.Reference("i=14524", "i=45", true),
      new ns.Reference("i=14593", "i=45", true),
      new ns.Reference("i=15578", "i=45", true),
      new ns.Reference("i=15580", "i=45", true),
      new ns.Reference("i=14273", "i=45", true),
      new ns.Reference("i=15597", "i=45", true),
      new ns.Reference("i=15598", "i=45", true),
      new ns.Reference("i=15605", "i=45", true),
      new ns.Reference("i=15609", "i=45", true),
      new ns.Reference("i=15611", "i=45", true),
      new ns.Reference("i=15616", "i=45", true),
      new ns.Reference("i=15617", "i=45", true),
      new ns.Reference("i=15618", "i=45", true),
      new ns.Reference("i=15502", "i=45", true),
      new ns.Reference("i=15621", "i=45", true),
      new ns.Reference("i=15622", "i=45", true),
      new ns.Reference("i=15623", "i=45", true),
      new ns.Reference("i=15628", "i=45", true),
      new ns.Reference("i=15629", "i=45", true),
      new ns.Reference("i=15630", "i=45", true),
      new ns.Reference("i=14744", "i=45", true),
      new ns.Reference("i=15530", "i=45", true),
      new ns.Reference("i=23601", "i=45", true),
      new ns.Reference("i=25270", "i=45", true),
      new ns.Reference("i=23603", "i=45", true),
      new ns.Reference("i=25519", "i=45", true),
      new ns.Reference("i=25520", "i=45", true),
      new ns.Reference("i=23468", "i=45", true),
      new ns.Reference("i=24281", "i=45", true),
      new ns.Reference("i=25220", "i=45", true),
      new ns.Reference("i=96", "i=45", true),
      new ns.Reference("i=97", "i=45", true),
      new ns.Reference("i=101", "i=45", true),
      new ns.Reference("i=258", "i=45", true),
      new ns.Reference("i=285", "i=45", true),
      new ns.Reference("i=296", "i=45", true),
      new ns.Reference("i=7594", "i=45", true),
      new ns.Reference("i=12755", "i=45", true),
      new ns.Reference("i=8912", "i=45", true),
      new ns.Reference("i=308", "i=45", true),
      new ns.Reference("i=389", "i=45", true),
      new ns.Reference("i=392", "i=45", true),
      new ns.Reference("i=395", "i=45", true),
      new ns.Reference("i=15901", "i=45", true),
      new ns.Reference("i=20999", "i=45", true),
      new ns.Reference("i=420", "i=45", true),
      new ns.Reference("i=423", "i=45", true),
      new ns.Reference("i=12189", "i=45", true),
      new ns.Reference("i=12190", "i=45", true),
      new ns.Reference("i=12191", "i=45", true),
      new ns.Reference("i=304", "i=45", true),
      new ns.Reference("i=312", "i=45", true),
      new ns.Reference("i=426", "i=45", true),
      new ns.Reference("i=429", "i=45", true),
      new ns.Reference("i=432", "i=45", true),
      new ns.Reference("i=435", "i=45", true),
      new ns.Reference("i=438", "i=45", true),
      new ns.Reference("i=12890", "i=45", true),
      new ns.Reference("i=12193", "i=45", true),
      new ns.Reference("i=12194", "i=45", true),
      new ns.Reference("i=441", "i=45", true),
      new ns.Reference("i=444", "i=45", true),
      new ns.Reference("i=447", "i=45", true),
      new ns.Reference("i=450", "i=45", true),
      new ns.Reference("i=453", "i=45", true),
      new ns.Reference("i=344", "i=45", true),
      new ns.Reference("i=456", "i=45", true),
      new ns.Reference("i=459", "i=45", true),
      new ns.Reference("i=462", "i=45", true),
      new ns.Reference("i=316", "i=45", true),
      new ns.Reference("i=465", "i=45", true),
      new ns.Reference("i=468", "i=45", true),
      new ns.Reference("i=471", "i=45", true),
      new ns.Reference("i=474", "i=45", true),
      new ns.Reference("i=477", "i=45", true),
      new ns.Reference("i=480", "i=45", true),
      new ns.Reference("i=349", "i=45", true),
      new ns.Reference("i=17606", "i=45", true),
      new ns.Reference("i=376", "i=45", true),
      new ns.Reference("i=483", "i=45", true),
      new ns.Reference("i=486", "i=45", true),
      new ns.Reference("i=489", "i=45", true),
      new ns.Reference("i=379", "i=45", true),
      new ns.Reference("i=492", "i=45", true),
      new ns.Reference("i=495", "i=45", true),
      new ns.Reference("i=382", "i=45", true),
      new ns.Reference("i=498", "i=45", true),
      new ns.Reference("i=501", "i=45", true),
      new ns.Reference("i=385", "i=45", true),
      new ns.Reference("i=504", "i=45", true),
      new ns.Reference("i=507", "i=45", true),
      new ns.Reference("i=511", "i=45", true),
      new ns.Reference("i=514", "i=45", true),
      new ns.Reference("i=518", "i=45", true),
      new ns.Reference("i=522", "i=45", true),
      new ns.Reference("i=525", "i=45", true),
      new ns.Reference("i=528", "i=45", true),
      new ns.Reference("i=531", "i=45", true),
      new ns.Reference("i=534", "i=45", true),
      new ns.Reference("i=537", "i=45", true),
      new ns.Reference("i=540", "i=45", true),
      new ns.Reference("i=543", "i=45", true),
      new ns.Reference("i=546", "i=45", true),
      new ns.Reference("i=549", "i=45", true),
      new ns.Reference("i=552", "i=45", true),
      new ns.Reference("i=555", "i=45", true),
      new ns.Reference("i=558", "i=45", true),
      new ns.Reference("i=561", "i=45", true),
      new ns.Reference("i=564", "i=45", true),
      new ns.Reference("i=567", "i=45", true),
      new ns.Reference("i=331", "i=45", true),
      new ns.Reference("i=570", "i=45", true),
      new ns.Reference("i=573", "i=45", true),
      new ns.Reference("i=577", "i=45", true),
      new ns.Reference("i=580", "i=45", true),
      new ns.Reference("i=583", "i=45", true),
      new ns.Reference("i=586", "i=45", true),
      new ns.Reference("i=589", "i=45", true),
      new ns.Reference("i=604", "i=45", true),
      new ns.Reference("i=607", "i=45", true),
      new ns.Reference("i=610", "i=45", true),
      new ns.Reference("i=613", "i=45", true),
      new ns.Reference("i=616", "i=45", true),
      new ns.Reference("i=619", "i=45", true),
      new ns.Reference("i=622", "i=45", true),
      new ns.Reference("i=626", "i=45", true),
      new ns.Reference("i=629", "i=45", true),
      new ns.Reference("i=632", "i=45", true),
      new ns.Reference("i=635", "i=45", true),
      new ns.Reference("i=638", "i=45", true),
      new ns.Reference("i=641", "i=45", true),
      new ns.Reference("i=656", "i=45", true),
      new ns.Reference("i=11216", "i=45", true),
      new ns.Reference("i=659", "i=45", true),
      new ns.Reference("i=662", "i=45", true),
      new ns.Reference("i=665", "i=45", true),
      new ns.Reference("i=668", "i=45", true),
      new ns.Reference("i=671", "i=45", true),
      new ns.Reference("i=674", "i=45", true),
      new ns.Reference("i=677", "i=45", true),
      new ns.Reference("i=695", "i=45", true),
      new ns.Reference("i=698", "i=45", true),
      new ns.Reference("i=701", "i=45", true),
      new ns.Reference("i=704", "i=45", true),
      new ns.Reference("i=707", "i=45", true),
      new ns.Reference("i=710", "i=45", true),
      new ns.Reference("i=713", "i=45", true),
      new ns.Reference("i=719", "i=45", true),
      new ns.Reference("i=948", "i=45", true),
      new ns.Reference("i=731", "i=45", true),
      new ns.Reference("i=740", "i=45", true),
      new ns.Reference("i=743", "i=45", true),
      new ns.Reference("i=746", "i=45", true),
      new ns.Reference("i=749", "i=45", true),
      new ns.Reference("i=752", "i=45", true),
      new ns.Reference("i=755", "i=45", true),
      new ns.Reference("i=758", "i=45", true),
      new ns.Reference("i=761", "i=45", true),
      new ns.Reference("i=764", "i=45", true),
      new ns.Reference("i=767", "i=45", true),
      new ns.Reference("i=770", "i=45", true),
      new ns.Reference("i=773", "i=45", true),
      new ns.Reference("i=776", "i=45", true),
      new ns.Reference("i=779", "i=45", true),
      new ns.Reference("i=782", "i=45", true),
      new ns.Reference("i=785", "i=45", true),
      new ns.Reference("i=788", "i=45", true),
      new ns.Reference("i=791", "i=45", true),
      new ns.Reference("i=794", "i=45", true),
      new ns.Reference("i=797", "i=45", true),
      new ns.Reference("i=800", "i=45", true),
      new ns.Reference("i=803", "i=45", true),
      new ns.Reference("i=945", "i=45", true),
      new ns.Reference("i=806", "i=45", true),
      new ns.Reference("i=917", "i=45", true),
      new ns.Reference("i=920", "i=45", true),
      new ns.Reference("i=821", "i=45", true),
      new ns.Reference("i=824", "i=45", true),
      new ns.Reference("i=827", "i=45", true),
      new ns.Reference("i=830", "i=45", true),
      new ns.Reference("i=833", "i=45", true),
      new ns.Reference("i=836", "i=45", true),
      new ns.Reference("i=839", "i=45", true),
      new ns.Reference("i=842", "i=45", true),
      new ns.Reference("i=845", "i=45", true),
      new ns.Reference("i=848", "i=45", true),
      new ns.Reference("i=338", "i=45", true),
      new ns.Reference("i=853", "i=45", true),
      new ns.Reference("i=11943", "i=45", true),
      new ns.Reference("i=11944", "i=45", true),
      new ns.Reference("i=856", "i=45", true),
      new ns.Reference("i=859", "i=45", true),
      new ns.Reference("i=862", "i=45", true),
      new ns.Reference("i=865", "i=45", true),
      new ns.Reference("i=868", "i=45", true),
      new ns.Reference("i=871", "i=45", true),
      new ns.Reference("i=299", "i=45", true),
      new ns.Reference("i=874", "i=45", true),
      new ns.Reference("i=877", "i=45", true),
      new ns.Reference("i=897", "i=45", true),
      new ns.Reference("i=884", "i=45", true),
      new ns.Reference("i=887", "i=45", true),
      new ns.Reference("i=12171", "i=45", true),
      new ns.Reference("i=12172", "i=45", true),
      new ns.Reference("i=12079", "i=45", true),
      new ns.Reference("i=12080", "i=45", true),
      new ns.Reference("i=894", "i=45", true),
      new ns.Reference("i=24033", "i=45", true),
      new ns.Reference("i=891", "i=45", true),
    ],
}

const node3284 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataValue"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataValue"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node3323 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23468"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AliasNameDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AliasNameDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=23499", "i=38", true),
      new ns.Reference("i=23505", "i=38", true),
      new ns.Reference("i=23511", "i=38", true),
    ],
    Definition: [
      new ns.StructField("AliasName", "i=20", "i=20", -1, null),
      new ns.StructField("ReferencedNodes", "i=18", "i=18", 1, null),
    ],
    BinaryId: "i=23499",
    JsonId: "i=23511",
}

const node3340 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23497"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadAnnotationDataDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadAnnotationDataDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=641", "i=45", false),
      new ns.Reference("i=23500", "i=38", true),
      new ns.Reference("i=23506", "i=38", true),
      new ns.Reference("i=23512", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ReqTimes", "i=294", "i=13", 1, null),
    ],
    BinaryId: "i=23500",
    JsonId: "i=23512",
}

const node3341 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23498"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CurrencyUnitType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CurrencyUnitType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=23507", "i=38", true),
      new ns.Reference("i=23520", "i=38", true),
      new ns.Reference("i=23528", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NumericCode", "i=4", "i=4", -1, null),
      new ns.StructField("Exponent", "i=2", "i=2", -1, null),
      new ns.StructField("AlphabeticCode", "i=12", "i=12", -1, null),
      new ns.StructField("Currency", "i=21", "i=21", -1, null),
    ],
    BinaryId: "i=23507",
    JsonId: "i=23528",
}

const node3384 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23599"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StandaloneSubscribedDataSetRefDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StandaloneSubscribedDataSetRefDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15630", "i=45", false),
      new ns.Reference("i=23851", "i=38", true),
      new ns.Reference("i=23919", "i=38", true),
      new ns.Reference("i=23987", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataSetName", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=23851",
    JsonId: "i=23987",
}

const node3386 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23600"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StandaloneSubscribedDataSetDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StandaloneSubscribedDataSetDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15630", "i=45", false),
      new ns.Reference("i=23852", "i=38", true),
      new ns.Reference("i=23920", "i=38", true),
      new ns.Reference("i=23988", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("DataSetFolder", "i=12", "i=12", 1, null),
      new ns.StructField("DataSetMetaData", "i=14523", "i=22", -1, null),
      new ns.StructField("SubscribedDataSet", "i=15630", "i=22", -1, null),
    ],
    BinaryId: "i=23852",
    JsonId: "i=23988",
}

const node3387 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23601"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SecurityGroupDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SecurityGroupDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=23853", "i=38", true),
      new ns.Reference("i=23921", "i=38", true),
      new ns.Reference("i=23989", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityGroupFolder", "i=12", "i=12", 1, null),
      new ns.StructField("KeyLifetime", "i=290", "i=11", -1, null),
      new ns.StructField("SecurityPolicyUri", "i=12", "i=12", -1, null),
      new ns.StructField("MaxFutureKeyCount", "i=7", "i=7", -1, null),
      new ns.StructField("MaxPastKeyCount", "i=7", "i=7", -1, null),
      new ns.StructField("SecurityGroupId", "i=12", "i=12", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("GroupProperties", "i=14533", "i=22", 1, null),
    ],
    BinaryId: "i=23853",
    JsonId: "i=23989",
}

const node3388 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23602"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubConfiguration2DataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubConfiguration2DataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15530", "i=45", false),
      new ns.Reference("i=23854", "i=38", true),
      new ns.Reference("i=23922", "i=38", true),
      new ns.Reference("i=23990", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PublishedDataSets", "i=15578", "i=22", 1, null),
      new ns.StructField("Connections", "i=15617", "i=22", 1, null),
      new ns.StructField("Enabled", "i=1", "i=1", -1, null),
      new ns.StructField("SubscribedDataSets", "i=23600", "i=22", 1, null),
      new ns.StructField("DataSetClasses", "i=14523", "i=22", 1, null),
      new ns.StructField("DefaultSecurityKeyServices", "i=312", "i=22", 1, null),
      new ns.StructField("SecurityGroups", "i=23601", "i=22", 1, null),
      new ns.StructField("PubSubKeyPushTargets", "i=25270", "i=22", 1, null),
      new ns.StructField("ConfigurationVersion", "i=20998", "i=7", -1, null),
      new ns.StructField("ConfigurationProperties", "i=14533", "i=22", 1, null),
    ],
    BinaryId: "i=23854",
    JsonId: "i=23990",
}

const node3389 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23603"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QosDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QosDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=23604", "i=45", true),
      new ns.Reference("i=23608", "i=45", true),
      new ns.Reference("i=23855", "i=38", true),
      new ns.Reference("i=23923", "i=38", true),
      new ns.Reference("i=23991", "i=38", true),
    ],
}

const node3390 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23604"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TransmitQosDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TransmitQosDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=23603", "i=45", false),
      new ns.Reference("i=23605", "i=45", true),
      new ns.Reference("i=23856", "i=38", true),
      new ns.Reference("i=23924", "i=38", true),
      new ns.Reference("i=23992", "i=38", true),
    ],
}

const node3391 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23605"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TransmitQosPriorityDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TransmitQosPriorityDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=23604", "i=45", false),
      new ns.Reference("i=23857", "i=38", true),
      new ns.Reference("i=23925", "i=38", true),
      new ns.Reference("i=23993", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PriorityLabel", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=23857",
    JsonId: "i=23993",
}

const node3393 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23608"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReceiveQosDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReceiveQosDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=23603", "i=45", false),
      new ns.Reference("i=23609", "i=45", true),
      new ns.Reference("i=23860", "i=38", true),
      new ns.Reference("i=23928", "i=38", true),
      new ns.Reference("i=23996", "i=38", true),
    ],
}

const node3394 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23609"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReceiveQosPriorityDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReceiveQosPriorityDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=23608", "i=45", false),
      new ns.Reference("i=23861", "i=38", true),
      new ns.Reference("i=23929", "i=38", true),
      new ns.Reference("i=23997", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PriorityLabel", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=23861",
    JsonId: "i=23997",
}

const node3396 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23612"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DatagramConnectionTransport2DataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DatagramConnectionTransport2DataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=17467", "i=45", false),
      new ns.Reference("i=23864", "i=38", true),
      new ns.Reference("i=23932", "i=38", true),
      new ns.Reference("i=24000", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DiscoveryAddress", "i=15502", "i=22", -1, null),
      new ns.StructField("DiscoveryAnnounceRate", "i=7", "i=7", -1, null),
      new ns.StructField("DiscoveryMaxMessageSize", "i=7", "i=7", -1, null),
      new ns.StructField("QosCategory", "i=12", "i=12", -1, null),
      new ns.StructField("DatagramQos", "i=23603", "i=22", 1, null),
    ],
    BinaryId: "i=23864",
    JsonId: "i=24000",
}

const node3397 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23613"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DatagramWriterGroupTransport2DataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DatagramWriterGroupTransport2DataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15532", "i=45", false),
      new ns.Reference("i=23865", "i=38", true),
      new ns.Reference("i=23933", "i=38", true),
      new ns.Reference("i=24001", "i=38", true),
    ],
    Definition: [
      new ns.StructField("MessageRepeatCount", "i=3", "i=3", -1, null),
      new ns.StructField("MessageRepeatDelay", "i=290", "i=11", -1, null),
      new ns.StructField("Address", "i=15502", "i=22", -1, null),
      new ns.StructField("QosCategory", "i=12", "i=12", -1, null),
      new ns.StructField("DatagramQos", "i=23604", "i=22", 1, null),
      new ns.StructField("DiscoveryAnnounceRate", "i=7", "i=7", -1, null),
      new ns.StructField("Topic", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=23865",
    JsonId: "i=24001",
}

const node3398 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23614"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DatagramDataSetReaderTransportDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DatagramDataSetReaderTransportDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15628", "i=45", false),
      new ns.Reference("i=23866", "i=38", true),
      new ns.Reference("i=23934", "i=38", true),
      new ns.Reference("i=24002", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Address", "i=15502", "i=22", -1, null),
      new ns.StructField("QosCategory", "i=12", "i=12", -1, null),
      new ns.StructField("DatagramQos", "i=23608", "i=22", 1, null),
      new ns.StructField("Topic", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=23866",
    JsonId: "i=24002",
}

const node3429 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=23751"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UriString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UriString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node3562 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BaseDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BaseDataType"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=26", "i=45", true),
      new ns.Reference("i=29", "i=45", true),
      new ns.Reference("i=1", "i=45", true),
      new ns.Reference("i=12", "i=45", true),
      new ns.Reference("i=13", "i=45", true),
      new ns.Reference("i=14", "i=45", true),
      new ns.Reference("i=15", "i=45", true),
      new ns.Reference("i=16", "i=45", true),
      new ns.Reference("i=17", "i=45", true),
      new ns.Reference("i=18", "i=45", true),
      new ns.Reference("i=19", "i=45", true),
      new ns.Reference("i=20", "i=45", true),
      new ns.Reference("i=21", "i=45", true),
      new ns.Reference("i=22", "i=45", true),
      new ns.Reference("i=23", "i=45", true),
      new ns.Reference("i=25", "i=45", true),
      new ns.Reference("i=90", "i=35", false),
      new ns.Reference("i=17545", "i=45", true),
      new ns.Reference("i=17546", "i=45", true),
    ],
}

const node3577 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24033"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ProgramDiagnostic2DataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ProgramDiagnostic2DataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=24034", "i=38", true),
      new ns.Reference("i=24038", "i=38", true),
      new ns.Reference("i=24042", "i=38", true),
    ],
    Definition: [
      new ns.StructField("CreateSessionId", "i=17", "i=17", -1, null),
      new ns.StructField("CreateClientName", "i=12", "i=12", -1, null),
      new ns.StructField("InvocationCreationTime", "i=294", "i=13", -1, null),
      new ns.StructField("LastTransitionTime", "i=294", "i=13", -1, null),
      new ns.StructField("LastMethodCall", "i=12", "i=12", -1, null),
      new ns.StructField("LastMethodSessionId", "i=17", "i=17", -1, null),
      new ns.StructField("LastMethodInputArguments", "i=296", "i=22", 1, null),
      new ns.StructField("LastMethodOutputArguments", "i=296", "i=22", 1, null),
      new ns.StructField("LastMethodInputValues", "nil", "nil", 1, null),
      new ns.StructField("LastMethodOutputValues", "nil", "nil", 1, null),
      new ns.StructField("LastMethodCallTime", "i=294", "i=13", -1, null),
      new ns.StructField("LastMethodReturnStatus", "i=19", "i=19", -1, null),
    ],
    BinaryId: "i=24034",
    JsonId: "i=24042",
}

const node3606 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24105"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PortableQualifiedName"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PortableQualifiedName"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=24108", "i=38", true),
      new ns.Reference("i=24120", "i=38", true),
      new ns.Reference("i=24132", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NamespaceUri", "i=12", "i=12", -1, null),
      new ns.StructField("Name", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=24108",
    JsonId: "i=24132",
}

const node3607 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24106"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PortableNodeId"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PortableNodeId"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=24109", "i=38", true),
      new ns.Reference("i=24121", "i=38", true),
      new ns.Reference("i=24133", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NamespaceUri", "i=12", "i=12", -1, null),
      new ns.StructField("Identifier", "i=17", "i=17", -1, null),
    ],
    BinaryId: "i=24109",
    JsonId: "i=24133",
}

const node3608 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24107"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UnsignedRationalNumber"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UnsignedRationalNumber"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=24110", "i=38", true),
      new ns.Reference("i=24122", "i=38", true),
      new ns.Reference("i=24134", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Numerator", "i=7", "i=7", -1, null),
      new ns.StructField("Denominator", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=24110",
    JsonId: "i=24134",
}

const node3696 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24210"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Duplex"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Duplex"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24235", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Full", 0),
      new ns.EnumField("Half", 1),
      new ns.EnumField("Unknown", 2),
    ],
}

const node3697 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24212"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "InterfaceAdminStatus"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("InterfaceAdminStatus"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24236", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Up", 0),
      new ns.EnumField("Down", 1),
      new ns.EnumField("Testing", 2),
    ],
}

const node3698 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24214"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "InterfaceOperStatus"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("InterfaceOperStatus"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24237", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Up", 0),
      new ns.EnumField("Down", 1),
      new ns.EnumField("Testing", 2),
      new ns.EnumField("Unknown", 3),
      new ns.EnumField("Dormant", 4),
      new ns.EnumField("NotPresent", 5),
      new ns.EnumField("LowerLayerDown", 6),
    ],
}

const node3699 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24216"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NegotiationStatus"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NegotiationStatus"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24238", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("InProgress", 0),
      new ns.EnumField("Complete", 1),
      new ns.EnumField("Failed", 2),
      new ns.EnumField("Unknown", 3),
      new ns.EnumField("NoNegotiation", 4),
    ],
}

const node3700 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24218"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TsnFailureCode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TsnFailureCode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24239", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("NoFailure", 0),
      new ns.EnumField("InsufficientBandwidth", 1),
      new ns.EnumField("InsufficientResources", 2),
      new ns.EnumField("InsufficientTrafficClassBandwidth", 3),
      new ns.EnumField("StreamIdInUse", 4),
      new ns.EnumField("StreamDestinationAddressInUse", 5),
      new ns.EnumField("StreamPreemptedByHigherRank", 6),
      new ns.EnumField("LatencyHasChanged", 7),
      new ns.EnumField("EgressPortNotAvbCapable", 8),
      new ns.EnumField("UseDifferentDestinationAddress", 9),
      new ns.EnumField("OutOfMsrpResources", 10),
      new ns.EnumField("OutOfMmrpResources", 11),
      new ns.EnumField("CannotStoreDestinationAddress", 12),
      new ns.EnumField("PriorityIsNotAnSrcClass", 13),
      new ns.EnumField("MaxFrameSizeTooLarge", 14),
      new ns.EnumField("MaxFanInPortsLimitReached", 15),
      new ns.EnumField("FirstValueChangedForStreamId", 16),
      new ns.EnumField("VlanBlockedOnEgress", 17),
      new ns.EnumField("VlanTaggingDisabledOnEgress", 18),
      new ns.EnumField("SrClassPriorityMismatch", 19),
      new ns.EnumField("FeatureNotPropagated", 20),
      new ns.EnumField("MaxLatencyExceeded", 21),
      new ns.EnumField("BridgeDoesNotProvideNetworkId", 22),
      new ns.EnumField("StreamTransformNotSupported", 23),
      new ns.EnumField("StreamIdTypeNotSupported", 24),
      new ns.EnumField("FeatureNotSupported", 25),
    ],
}

const node3702 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24220"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TsnStreamState"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TsnStreamState"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24240", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Disabled", 0),
      new ns.EnumField("Configuring", 1),
      new ns.EnumField("Ready", 2),
      new ns.EnumField("Operational", 3),
      new ns.EnumField("Error", 4),
    ],
}

const node3703 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24222"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TsnTalkerStatus"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TsnTalkerStatus"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24241", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("None", 0),
      new ns.EnumField("Ready", 1),
      new ns.EnumField("Failed", 2),
    ],
}

const node3704 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24224"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TsnListenerStatus"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TsnListenerStatus"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24242", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("None", 0),
      new ns.EnumField("Ready", 1),
      new ns.EnumField("PartialFailed", 2),
      new ns.EnumField("Failed", 3),
    ],
}

const node3727 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24263"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SemanticVersionString"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SemanticVersionString"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node3742 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24277"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PasswordOptionsMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PasswordOptionsMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24278", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("SupportInitialPasswordChange", 0),
      new ns.EnumField("SupportDisableUser", 1),
      new ns.EnumField("SupportDisableDeleteForUser", 2),
      new ns.EnumField("SupportNoChangeForUser", 3),
      new ns.EnumField("SupportDescriptionForUser", 4),
      new ns.EnumField("RequiresUpperCaseCharacters", 5),
      new ns.EnumField("RequiresLowerCaseCharacters", 6),
      new ns.EnumField("RequiresDigitCharacters", 7),
      new ns.EnumField("RequiresSpecialCharacters", 8),
    ],
}

const node3744 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24279"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UserConfigurationMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UserConfigurationMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24280", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("NoDelete", 0),
      new ns.EnumField("Disabled", 1),
      new ns.EnumField("NoChangeByUser", 2),
      new ns.EnumField("MustChangePassword", 3),
    ],
}

const node3747 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=24281"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UserManagementDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UserManagementDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=24292", "i=38", true),
      new ns.Reference("i=24296", "i=38", true),
      new ns.Reference("i=24300", "i=38", true),
    ],
    Definition: [
      new ns.StructField("UserName", "i=12", "i=12", -1, null),
      new ns.StructField("UserConfiguration", "i=24279", "i=7", -1, null),
      new ns.StructField("Description", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=24292",
    JsonId: "i=24300",
}

const node3795 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=25"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DiagnosticInfo"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DiagnosticInfo"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
    ],
}

const node3800 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=25220"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PriorityMappingEntryType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PriorityMappingEntryType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=25239", "i=38", true),
      new ns.Reference("i=25243", "i=38", true),
      new ns.Reference("i=25247", "i=38", true),
    ],
    Definition: [
      new ns.StructField("MappingUri", "i=12", "i=12", -1, null),
      new ns.StructField("PriorityLabel", "i=12", "i=12", -1, null),
      new ns.StructField("PriorityValue_PCP", "i=3", "i=3", -1, null),
      new ns.StructField("PriorityValue_DSCP", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=25239",
    JsonId: "i=25247",
}

const node3835 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=25269"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishedDataSetCustomSourceDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishedDataSetCustomSourceDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15580", "i=45", false),
      new ns.Reference("i=25529", "i=38", true),
      new ns.Reference("i=25545", "i=38", true),
      new ns.Reference("i=25561", "i=38", true),
    ],
    Definition: [
      new ns.StructField("CyclicDataSet", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=25529",
    JsonId: "i=25561",
}

const node3836 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=25270"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubKeyPushTargetDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubKeyPushTargetDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=25530", "i=38", true),
      new ns.Reference("i=25546", "i=38", true),
      new ns.Reference("i=25562", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ApplicationUri", "i=12", "i=12", -1, null),
      new ns.StructField("PushTargetFolder", "i=12", "i=12", 1, null),
      new ns.StructField("EndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityPolicyUri", "i=12", "i=12", -1, null),
      new ns.StructField("UserTokenType", "i=304", "i=22", -1, null),
      new ns.StructField("RequestedKeyCount", "i=5", "i=5", -1, null),
      new ns.StructField("RetryInterval", "i=290", "i=11", -1, null),
      new ns.StructField("PushTargetProperties", "i=14533", "i=22", 1, null),
      new ns.StructField("SecurityGroups", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=25530",
    JsonId: "i=25562",
}

const node3951 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=25517"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubConfigurationRefMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubConfigurationRefMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=25518", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("ElementAdd", 0),
      new ns.EnumField("ElementMatch", 1),
      new ns.EnumField("ElementModify", 2),
      new ns.EnumField("ElementRemove", 3),
      new ns.EnumField("ReferenceWriter", 4),
      new ns.EnumField("ReferenceReader", 5),
      new ns.EnumField("ReferenceWriterGroup", 6),
      new ns.EnumField("ReferenceReaderGroup", 7),
      new ns.EnumField("ReferenceConnection", 8),
      new ns.EnumField("ReferencePubDataset", 9),
      new ns.EnumField("ReferenceSubDataset", 10),
      new ns.EnumField("ReferenceSecurityGroup", 11),
      new ns.EnumField("ReferencePushTarget", 12),
    ],
}

const node3953 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=25519"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubConfigurationRefDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubConfigurationRefDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=25531", "i=38", true),
      new ns.Reference("i=25547", "i=38", true),
      new ns.Reference("i=25563", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ConfigurationMask", "i=25517", "i=7", -1, null),
      new ns.StructField("ElementIndex", "i=5", "i=5", -1, null),
      new ns.StructField("ConnectionIndex", "i=5", "i=5", -1, null),
      new ns.StructField("GroupIndex", "i=5", "i=5", -1, null),
    ],
    BinaryId: "i=25531",
    JsonId: "i=25563",
}

const node3954 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=25520"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PubSubConfigurationValueDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PubSubConfigurationValueDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=25532", "i=38", true),
      new ns.Reference("i=25548", "i=38", true),
      new ns.Reference("i=25564", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ConfigurationElement", "i=25519", "i=22", -1, null),
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("Identifier", "nil", "nil", -1, null),
    ],
    BinaryId: "i=25532",
    JsonId: "i=25564",
}

const node4015 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=256"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "IdType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("IdType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7591", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Numeric", 0),
      new ns.EnumField("String", 1),
      new ns.EnumField("Guid", 2),
      new ns.EnumField("Opaque", 3),
    ],
}

const node4075 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=257"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NodeClass"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NodeClass"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11878", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Unspecified", 0),
      new ns.EnumField("Object", 1),
      new ns.EnumField("Variable", 2),
      new ns.EnumField("Method", 4),
      new ns.EnumField("ObjectType", 8),
      new ns.EnumField("VariableType", 16),
      new ns.EnumField("ReferenceType", 32),
      new ns.EnumField("DataType", 64),
      new ns.EnumField("View", 128),
    ],
}

const node4076 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=258"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Node"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Node"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=11879", "i=45", true),
      new ns.Reference("i=11880", "i=45", true),
      new ns.Reference("i=260", "i=38", true),
      new ns.Reference("i=259", "i=38", true),
      new ns.Reference("i=15068", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
    ],
    BinaryId: "i=260",
    JsonId: "i=15068",
}

const node4078 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=26"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Number"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Number"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
      new ns.Reference("i=27", "i=45", true),
      new ns.Reference("i=28", "i=45", true),
      new ns.Reference("i=10", "i=45", true),
      new ns.Reference("i=11", "i=45", true),
      new ns.Reference("i=50", "i=45", true),
    ],
}

const node4080 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=261"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ObjectNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ObjectNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11879", "i=45", false),
      new ns.Reference("i=263", "i=38", true),
      new ns.Reference("i=262", "i=38", true),
      new ns.Reference("i=15071", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("EventNotifier", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=263",
    JsonId: "i=15071",
}

const node4083 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=264"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ObjectTypeNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ObjectTypeNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11880", "i=45", false),
      new ns.Reference("i=266", "i=38", true),
      new ns.Reference("i=265", "i=38", true),
      new ns.Reference("i=15073", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=266",
    JsonId: "i=15073",
}

const node4086 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=267"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "VariableNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("VariableNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11879", "i=45", false),
      new ns.Reference("i=269", "i=38", true),
      new ns.Reference("i=268", "i=38", true),
      new ns.Reference("i=15074", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
      new ns.StructField("DataType", "i=17", "i=17", -1, null),
      new ns.StructField("ValueRank", "i=6", "i=6", -1, null),
      new ns.StructField("ArrayDimensions", "i=7", "i=7", 1, null),
      new ns.StructField("AccessLevel", "i=3", "i=3", -1, null),
      new ns.StructField("UserAccessLevel", "i=3", "i=3", -1, null),
      new ns.StructField("MinimumSamplingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("Historizing", "i=1", "i=1", -1, null),
      new ns.StructField("AccessLevelEx", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=269",
    JsonId: "i=15074",
}

const node4089 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=27"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Integer"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Integer"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=26", "i=45", false),
      new ns.Reference("i=2", "i=45", true),
      new ns.Reference("i=4", "i=45", true),
      new ns.Reference("i=6", "i=45", true),
      new ns.Reference("i=8", "i=45", true),
    ],
}

const node4090 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=270"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "VariableTypeNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("VariableTypeNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11880", "i=45", false),
      new ns.Reference("i=272", "i=38", true),
      new ns.Reference("i=271", "i=38", true),
      new ns.Reference("i=15075", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
      new ns.StructField("DataType", "i=17", "i=17", -1, null),
      new ns.StructField("ValueRank", "i=6", "i=6", -1, null),
      new ns.StructField("ArrayDimensions", "i=7", "i=7", 1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=272",
    JsonId: "i=15075",
}

const node4093 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=273"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReferenceTypeNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReferenceTypeNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11880", "i=45", false),
      new ns.Reference("i=275", "i=38", true),
      new ns.Reference("i=274", "i=38", true),
      new ns.Reference("i=15076", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
      new ns.StructField("Symmetric", "i=1", "i=1", -1, null),
      new ns.StructField("InverseName", "i=21", "i=21", -1, null),
    ],
    BinaryId: "i=275",
    JsonId: "i=15076",
}

const node4123 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=276"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MethodNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MethodNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11879", "i=45", false),
      new ns.Reference("i=278", "i=38", true),
      new ns.Reference("i=277", "i=38", true),
      new ns.Reference("i=15077", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("Executable", "i=1", "i=1", -1, null),
      new ns.StructField("UserExecutable", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=278",
    JsonId: "i=15077",
}

const node4149 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=279"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ViewNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ViewNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11879", "i=45", false),
      new ns.Reference("i=281", "i=38", true),
      new ns.Reference("i=280", "i=38", true),
      new ns.Reference("i=15078", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("ContainsNoLoops", "i=1", "i=1", -1, null),
      new ns.StructField("EventNotifier", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=281",
    JsonId: "i=15078",
}

const node4151 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=28"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UInteger"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UInteger"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=26", "i=45", false),
      new ns.Reference("i=3", "i=45", true),
      new ns.Reference("i=5", "i=45", true),
      new ns.Reference("i=7", "i=45", true),
      new ns.Reference("i=9", "i=45", true),
    ],
}

const node4155 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=282"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataTypeNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataTypeNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11880", "i=45", false),
      new ns.Reference("i=284", "i=38", true),
      new ns.Reference("i=283", "i=38", true),
      new ns.Reference("i=15079", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("RolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("UserRolePermissions", "i=96", "i=22", 1, null),
      new ns.StructField("AccessRestrictions", "i=5", "i=5", -1, null),
      new ns.StructField("References", "i=285", "i=22", 1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
      new ns.StructField("DataTypeDefinition", "i=22", "i=22", -1, null),
    ],
    BinaryId: "i=284",
    JsonId: "i=15079",
}

const node4161 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=285"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReferenceNode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReferenceNode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=287", "i=38", true),
      new ns.Reference("i=286", "i=38", true),
      new ns.Reference("i=15080", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("IsInverse", "i=1", "i=1", -1, null),
      new ns.StructField("TargetId", "i=18", "i=18", -1, null),
    ],
    BinaryId: "i=287",
    JsonId: "i=15080",
}

const node4164 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=288"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "IntegerId"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("IntegerId"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7", "i=45", false),
    ],
}

const node4166 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=289"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Counter"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Counter"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7", "i=45", false),
    ],
}

const node4167 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=29"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Enumeration"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Enumeration"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=24", "i=45", false),
      new ns.Reference("i=120", "i=45", true),
      new ns.Reference("i=11939", "i=45", true),
      new ns.Reference("i=15632", "i=45", true),
      new ns.Reference("i=12552", "i=45", true),
      new ns.Reference("i=14647", "i=45", true),
      new ns.Reference("i=15874", "i=45", true),
      new ns.Reference("i=20408", "i=45", true),
      new ns.Reference("i=15008", "i=45", true),
      new ns.Reference("i=19723", "i=45", true),
      new ns.Reference("i=19730", "i=45", true),
      new ns.Reference("i=24210", "i=45", true),
      new ns.Reference("i=24212", "i=45", true),
      new ns.Reference("i=24214", "i=45", true),
      new ns.Reference("i=24216", "i=45", true),
      new ns.Reference("i=24218", "i=45", true),
      new ns.Reference("i=24220", "i=45", true),
      new ns.Reference("i=24222", "i=45", true),
      new ns.Reference("i=24224", "i=45", true),
      new ns.Reference("i=256", "i=45", true),
      new ns.Reference("i=257", "i=45", true),
      new ns.Reference("i=98", "i=45", true),
      new ns.Reference("i=307", "i=45", true),
      new ns.Reference("i=302", "i=45", true),
      new ns.Reference("i=303", "i=45", true),
      new ns.Reference("i=315", "i=45", true),
      new ns.Reference("i=348", "i=45", true),
      new ns.Reference("i=510", "i=45", true),
      new ns.Reference("i=517", "i=45", true),
      new ns.Reference("i=576", "i=45", true),
      new ns.Reference("i=625", "i=45", true),
      new ns.Reference("i=11234", "i=45", true),
      new ns.Reference("i=11293", "i=45", true),
      new ns.Reference("i=716", "i=45", true),
      new ns.Reference("i=717", "i=45", true),
      new ns.Reference("i=718", "i=45", true),
      new ns.Reference("i=851", "i=45", true),
      new ns.Reference("i=852", "i=45", true),
      new ns.Reference("i=11941", "i=45", true),
      new ns.Reference("i=12077", "i=45", true),
      new ns.Reference("i=890", "i=45", true),
    ],
}

const node4168 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=290"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Duration"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Duration"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11", "i=45", false),
    ],
}

const node4169 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=291"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NumericRange"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NumericRange"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node4177 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=294"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UtcTime"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UtcTime"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=13", "i=45", false),
    ],
}

const node4185 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=295"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "LocaleId"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("LocaleId"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=12", "i=45", false),
    ],
}

const node4187 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=296"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Argument"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Argument"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=298", "i=38", true),
      new ns.Reference("i=297", "i=38", true),
      new ns.Reference("i=15081", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Name", "i=12", "i=12", -1, null),
      new ns.StructField("DataType", "i=17", "i=17", -1, null),
      new ns.StructField("ValueRank", "i=6", "i=6", -1, null),
      new ns.StructField("ArrayDimensions", "i=7", "i=7", 1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
    ],
    BinaryId: "i=298",
    JsonId: "i=15081",
}

const node4190 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=299"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StatusResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StatusResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=301", "i=38", true),
      new ns.Reference("i=300", "i=38", true),
      new ns.Reference("i=15371", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("DiagnosticInfo", "i=25", "i=25", -1, null),
    ],
    BinaryId: "i=301",
    JsonId: "i=15371",
}

const node4199 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=3"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Byte"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Byte"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=28", "i=45", false),
      new ns.Reference("i=15031", "i=45", true),
      new ns.Reference("i=15033", "i=45", true),
    ],
}

const node4200 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=30"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Image"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Image"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15", "i=45", false),
      new ns.Reference("i=2000", "i=45", true),
      new ns.Reference("i=2001", "i=45", true),
      new ns.Reference("i=2002", "i=45", true),
      new ns.Reference("i=2003", "i=45", true),
    ],
}

const node4211 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=302"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MessageSecurityMode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MessageSecurityMode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7595", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Invalid", 0),
      new ns.EnumField("None", 1),
      new ns.EnumField("Sign", 2),
      new ns.EnumField("SignAndEncrypt", 3),
    ],
}

const node4222 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=303"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UserTokenType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UserTokenType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7596", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Anonymous", 0),
      new ns.EnumField("UserName", 1),
      new ns.EnumField("Certificate", 2),
      new ns.EnumField("IssuedToken", 3),
    ],
}

const node4229 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=304"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UserTokenPolicy"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UserTokenPolicy"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=306", "i=38", true),
      new ns.Reference("i=305", "i=38", true),
      new ns.Reference("i=15098", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PolicyId", "i=12", "i=12", -1, null),
      new ns.StructField("TokenType", "i=303", "i=29", -1, null),
      new ns.StructField("IssuedTokenType", "i=12", "i=12", -1, null),
      new ns.StructField("IssuerEndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityPolicyUri", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=306",
    JsonId: "i=15098",
}

const node4250 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=307"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ApplicationType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ApplicationType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7597", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Server", 0),
      new ns.EnumField("Client", 1),
      new ns.EnumField("ClientAndServer", 2),
      new ns.EnumField("DiscoveryServer", 3),
    ],
}

const node4261 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=308"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ApplicationDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ApplicationDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=310", "i=38", true),
      new ns.Reference("i=309", "i=38", true),
      new ns.Reference("i=15087", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ApplicationUri", "i=12", "i=12", -1, null),
      new ns.StructField("ProductUri", "i=12", "i=12", -1, null),
      new ns.StructField("ApplicationName", "i=21", "i=21", -1, null),
      new ns.StructField("ApplicationType", "i=307", "i=29", -1, null),
      new ns.StructField("GatewayServerUri", "i=12", "i=12", -1, null),
      new ns.StructField("DiscoveryProfileUri", "i=12", "i=12", -1, null),
      new ns.StructField("DiscoveryUrls", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=310",
    JsonId: "i=15087",
}

const node4293 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=311"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ApplicationInstanceCertificate"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ApplicationInstanceCertificate"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15", "i=45", false),
    ],
}

const node4304 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=312"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EndpointDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EndpointDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=314", "i=38", true),
      new ns.Reference("i=313", "i=38", true),
      new ns.Reference("i=15099", "i=38", true),
    ],
    Definition: [
      new ns.StructField("EndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("Server", "i=308", "i=22", -1, null),
      new ns.StructField("ServerCertificate", "i=311", "i=15", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("SecurityPolicyUri", "i=12", "i=12", -1, null),
      new ns.StructField("UserIdentityTokens", "i=304", "i=22", 1, null),
      new ns.StructField("TransportProfileUri", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityLevel", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=314",
    JsonId: "i=15099",
}

const node4330 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=315"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SecurityTokenRequestType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SecurityTokenRequestType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7598", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Issue", 0),
      new ns.EnumField("Renew", 1),
    ],
}

const node4340 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=316"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UserIdentityToken"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UserIdentityToken"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=319", "i=45", true),
      new ns.Reference("i=322", "i=45", true),
      new ns.Reference("i=325", "i=45", true),
      new ns.Reference("i=938", "i=45", true),
      new ns.Reference("i=318", "i=38", true),
      new ns.Reference("i=317", "i=38", true),
      new ns.Reference("i=15140", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PolicyId", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=318",
    JsonId: "i=15140",
}

const node4371 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=319"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AnonymousIdentityToken"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AnonymousIdentityToken"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=316", "i=45", false),
      new ns.Reference("i=321", "i=38", true),
      new ns.Reference("i=320", "i=38", true),
      new ns.Reference("i=15141", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PolicyId", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=321",
    JsonId: "i=15141",
}

const node4376 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=322"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UserNameIdentityToken"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UserNameIdentityToken"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=316", "i=45", false),
      new ns.Reference("i=324", "i=38", true),
      new ns.Reference("i=323", "i=38", true),
      new ns.Reference("i=15142", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PolicyId", "i=12", "i=12", -1, null),
      new ns.StructField("UserName", "i=12", "i=12", -1, null),
      new ns.StructField("Password", "i=15", "i=15", -1, null),
      new ns.StructField("EncryptionAlgorithm", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=324",
    JsonId: "i=15142",
}

const node4379 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=325"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "X509IdentityToken"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("X509IdentityToken"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=316", "i=45", false),
      new ns.Reference("i=327", "i=38", true),
      new ns.Reference("i=326", "i=38", true),
      new ns.Reference("i=15143", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PolicyId", "i=12", "i=12", -1, null),
      new ns.StructField("CertificateData", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=327",
    JsonId: "i=15143",
}

const node4383 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=331"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EndpointConfiguration"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EndpointConfiguration"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=333", "i=38", true),
      new ns.Reference("i=332", "i=38", true),
      new ns.Reference("i=15199", "i=38", true),
    ],
    Definition: [
      new ns.StructField("OperationTimeout", "i=6", "i=6", -1, null),
      new ns.StructField("UseBinaryEncoding", "i=1", "i=1", -1, null),
      new ns.StructField("MaxStringLength", "i=6", "i=6", -1, null),
      new ns.StructField("MaxByteStringLength", "i=6", "i=6", -1, null),
      new ns.StructField("MaxArrayLength", "i=6", "i=6", -1, null),
      new ns.StructField("MaxMessageSize", "i=6", "i=6", -1, null),
      new ns.StructField("MaxBufferSize", "i=6", "i=6", -1, null),
      new ns.StructField("ChannelLifetime", "i=6", "i=6", -1, null),
      new ns.StructField("SecurityTokenLifetime", "i=6", "i=6", -1, null),
    ],
    BinaryId: "i=333",
    JsonId: "i=15199",
}

const node4386 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=338"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BuildInfo"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BuildInfo"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=340", "i=38", true),
      new ns.Reference("i=339", "i=38", true),
      new ns.Reference("i=15361", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ProductUri", "i=12", "i=12", -1, null),
      new ns.StructField("ManufacturerName", "i=12", "i=12", -1, null),
      new ns.StructField("ProductName", "i=12", "i=12", -1, null),
      new ns.StructField("SoftwareVersion", "i=12", "i=12", -1, null),
      new ns.StructField("BuildNumber", "i=12", "i=12", -1, null),
      new ns.StructField("BuildDate", "i=294", "i=13", -1, null),
    ],
    BinaryId: "i=340",
    JsonId: "i=15361",
}

const node4390 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=344"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SignedSoftwareCertificate"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SignedSoftwareCertificate"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=346", "i=38", true),
      new ns.Reference("i=345", "i=38", true),
      new ns.Reference("i=15136", "i=38", true),
    ],
    Definition: [
      new ns.StructField("CertificateData", "i=15", "i=15", -1, null),
      new ns.StructField("Signature", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=346",
    JsonId: "i=15136",
}

const node4393 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=347"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AttributeWriteMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AttributeWriteMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15036", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("AccessLevel", 0),
      new ns.EnumField("ArrayDimensions", 1),
      new ns.EnumField("BrowseName", 2),
      new ns.EnumField("ContainsNoLoops", 3),
      new ns.EnumField("DataType", 4),
      new ns.EnumField("Description", 5),
      new ns.EnumField("DisplayName", 6),
      new ns.EnumField("EventNotifier", 7),
      new ns.EnumField("Executable", 8),
      new ns.EnumField("Historizing", 9),
      new ns.EnumField("InverseName", 10),
      new ns.EnumField("IsAbstract", 11),
      new ns.EnumField("MinimumSamplingInterval", 12),
      new ns.EnumField("NodeClass", 13),
      new ns.EnumField("NodeId", 14),
      new ns.EnumField("Symmetric", 15),
      new ns.EnumField("UserAccessLevel", 16),
      new ns.EnumField("UserExecutable", 17),
      new ns.EnumField("UserWriteMask", 18),
      new ns.EnumField("ValueRank", 19),
      new ns.EnumField("WriteMask", 20),
      new ns.EnumField("ValueForVariableType", 21),
      new ns.EnumField("DataTypeDefinition", 22),
      new ns.EnumField("RolePermissions", 23),
      new ns.EnumField("AccessRestrictions", 24),
      new ns.EnumField("AccessLevelEx", 25),
    ],
}

const node4394 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=348"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NodeAttributesMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NodeAttributesMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11881", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("None", 0),
      new ns.EnumField("AccessLevel", 1),
      new ns.EnumField("ArrayDimensions", 2),
      new ns.EnumField("BrowseName", 4),
      new ns.EnumField("ContainsNoLoops", 8),
      new ns.EnumField("DataType", 16),
      new ns.EnumField("Description", 32),
      new ns.EnumField("DisplayName", 64),
      new ns.EnumField("EventNotifier", 128),
      new ns.EnumField("Executable", 256),
      new ns.EnumField("Historizing", 512),
      new ns.EnumField("InverseName", 1024),
      new ns.EnumField("IsAbstract", 2048),
      new ns.EnumField("MinimumSamplingInterval", 4096),
      new ns.EnumField("NodeClass", 8192),
      new ns.EnumField("NodeId", 16384),
      new ns.EnumField("Symmetric", 32768),
      new ns.EnumField("UserAccessLevel", 65536),
      new ns.EnumField("UserExecutable", 131072),
      new ns.EnumField("UserWriteMask", 262144),
      new ns.EnumField("ValueRank", 524288),
      new ns.EnumField("WriteMask", 1048576),
      new ns.EnumField("Value", 2097152),
      new ns.EnumField("DataTypeDefinition", 4194304),
      new ns.EnumField("RolePermissions", 8388608),
      new ns.EnumField("AccessRestrictions", 16777216),
      new ns.EnumField("All", 33554431),
      new ns.EnumField("BaseNode", 26501220),
      new ns.EnumField("Object", 26501348),
      new ns.EnumField("ObjectType", 26503268),
      new ns.EnumField("Variable", 26571383),
      new ns.EnumField("VariableType", 28600438),
      new ns.EnumField("Method", 26632548),
      new ns.EnumField("ReferenceType", 26537060),
      new ns.EnumField("View", 26501356),
    ],
}

const node4395 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=349"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NodeAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NodeAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=352", "i=45", true),
      new ns.Reference("i=355", "i=45", true),
      new ns.Reference("i=358", "i=45", true),
      new ns.Reference("i=361", "i=45", true),
      new ns.Reference("i=364", "i=45", true),
      new ns.Reference("i=367", "i=45", true),
      new ns.Reference("i=370", "i=45", true),
      new ns.Reference("i=373", "i=45", true),
      new ns.Reference("i=17607", "i=45", true),
      new ns.Reference("i=351", "i=38", true),
      new ns.Reference("i=350", "i=38", true),
      new ns.Reference("i=15151", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=351",
    JsonId: "i=15151",
}

const node4399 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=352"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ObjectAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ObjectAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=354", "i=38", true),
      new ns.Reference("i=353", "i=38", true),
      new ns.Reference("i=15152", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("EventNotifier", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=354",
    JsonId: "i=15152",
}

const node4402 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=355"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "VariableAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("VariableAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=357", "i=38", true),
      new ns.Reference("i=356", "i=38", true),
      new ns.Reference("i=15153", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
      new ns.StructField("DataType", "i=17", "i=17", -1, null),
      new ns.StructField("ValueRank", "i=6", "i=6", -1, null),
      new ns.StructField("ArrayDimensions", "i=7", "i=7", 1, null),
      new ns.StructField("AccessLevel", "i=3", "i=3", -1, null),
      new ns.StructField("UserAccessLevel", "i=3", "i=3", -1, null),
      new ns.StructField("MinimumSamplingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("Historizing", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=357",
    JsonId: "i=15153",
}

const node4405 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=358"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MethodAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MethodAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=360", "i=38", true),
      new ns.Reference("i=359", "i=38", true),
      new ns.Reference("i=15157", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("Executable", "i=1", "i=1", -1, null),
      new ns.StructField("UserExecutable", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=360",
    JsonId: "i=15157",
}

const node4409 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=361"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ObjectTypeAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ObjectTypeAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=363", "i=38", true),
      new ns.Reference("i=362", "i=38", true),
      new ns.Reference("i=15158", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=363",
    JsonId: "i=15158",
}

const node4412 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=364"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "VariableTypeAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("VariableTypeAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=366", "i=38", true),
      new ns.Reference("i=365", "i=38", true),
      new ns.Reference("i=15159", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
      new ns.StructField("DataType", "i=17", "i=17", -1, null),
      new ns.StructField("ValueRank", "i=6", "i=6", -1, null),
      new ns.StructField("ArrayDimensions", "i=7", "i=7", 1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=366",
    JsonId: "i=15159",
}

const node4415 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=367"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReferenceTypeAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReferenceTypeAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=369", "i=38", true),
      new ns.Reference("i=368", "i=38", true),
      new ns.Reference("i=15160", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
      new ns.StructField("Symmetric", "i=1", "i=1", -1, null),
      new ns.StructField("InverseName", "i=21", "i=21", -1, null),
    ],
    BinaryId: "i=369",
    JsonId: "i=15160",
}

const node4421 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=370"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataTypeAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataTypeAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=372", "i=38", true),
      new ns.Reference("i=371", "i=38", true),
      new ns.Reference("i=15161", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("IsAbstract", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=372",
    JsonId: "i=15161",
}

const node4437 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=373"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ViewAttributes"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ViewAttributes"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=349", "i=45", false),
      new ns.Reference("i=375", "i=38", true),
      new ns.Reference("i=374", "i=38", true),
      new ns.Reference("i=15162", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SpecifiedAttributes", "i=7", "i=7", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
      new ns.StructField("WriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("UserWriteMask", "i=7", "i=7", -1, null),
      new ns.StructField("ContainsNoLoops", "i=1", "i=1", -1, null),
      new ns.StructField("EventNotifier", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=375",
    JsonId: "i=15162",
}

const node4444 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=376"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AddNodesItem"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AddNodesItem"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=378", "i=38", true),
      new ns.Reference("i=377", "i=38", true),
      new ns.Reference("i=15165", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ParentNodeId", "i=18", "i=18", -1, null),
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("RequestedNewNodeId", "i=18", "i=18", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("NodeAttributes", "i=22", "i=22", -1, null),
      new ns.StructField("TypeDefinition", "i=18", "i=18", -1, null),
    ],
    BinaryId: "i=378",
    JsonId: "i=15165",
}

const node4447 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=379"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AddReferencesItem"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AddReferencesItem"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=381", "i=38", true),
      new ns.Reference("i=380", "i=38", true),
      new ns.Reference("i=15169", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SourceNodeId", "i=17", "i=17", -1, null),
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("IsForward", "i=1", "i=1", -1, null),
      new ns.StructField("TargetServerUri", "i=12", "i=12", -1, null),
      new ns.StructField("TargetNodeId", "i=18", "i=18", -1, null),
      new ns.StructField("TargetNodeClass", "i=257", "i=29", -1, null),
    ],
    BinaryId: "i=381",
    JsonId: "i=15169",
}

const node4452 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=382"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteNodesItem"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteNodesItem"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=384", "i=38", true),
      new ns.Reference("i=383", "i=38", true),
      new ns.Reference("i=15172", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("DeleteTargetReferences", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=384",
    JsonId: "i=15172",
}

const node4474 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=385"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteReferencesItem"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteReferencesItem"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=387", "i=38", true),
      new ns.Reference("i=386", "i=38", true),
      new ns.Reference("i=15175", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SourceNodeId", "i=17", "i=17", -1, null),
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("IsForward", "i=1", "i=1", -1, null),
      new ns.StructField("TargetNodeId", "i=18", "i=18", -1, null),
      new ns.StructField("DeleteBidirectional", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=387",
    JsonId: "i=15175",
}

const node4481 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=388"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SessionAuthenticationToken"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SessionAuthenticationToken"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=17", "i=45", false),
    ],
}

const node4482 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=389"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RequestHeader"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RequestHeader"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=391", "i=38", true),
      new ns.Reference("i=390", "i=38", true),
      new ns.Reference("i=15088", "i=38", true),
    ],
    Definition: [
      new ns.StructField("AuthenticationToken", "i=388", "i=17", -1, null),
      new ns.StructField("Timestamp", "i=294", "i=13", -1, null),
      new ns.StructField("RequestHandle", "i=288", "i=7", -1, null),
      new ns.StructField("ReturnDiagnostics", "i=7", "i=7", -1, null),
      new ns.StructField("AuditEntryId", "i=12", "i=12", -1, null),
      new ns.StructField("TimeoutHint", "i=7", "i=7", -1, null),
      new ns.StructField("AdditionalHeader", "i=22", "i=22", -1, null),
    ],
    BinaryId: "i=391",
    JsonId: "i=15088",
}

const node4486 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=392"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ResponseHeader"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ResponseHeader"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=394", "i=38", true),
      new ns.Reference("i=393", "i=38", true),
      new ns.Reference("i=15089", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Timestamp", "i=294", "i=13", -1, null),
      new ns.StructField("RequestHandle", "i=288", "i=7", -1, null),
      new ns.StructField("ServiceResult", "i=19", "i=19", -1, null),
      new ns.StructField("ServiceDiagnostics", "i=25", "i=25", -1, null),
      new ns.StructField("StringTable", "i=12", "i=12", 1, null),
      new ns.StructField("AdditionalHeader", "i=22", "i=22", -1, null),
    ],
    BinaryId: "i=394",
    JsonId: "i=15089",
}

const node4489 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=395"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ServiceFault"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ServiceFault"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=397", "i=38", true),
      new ns.Reference("i=396", "i=38", true),
      new ns.Reference("i=15090", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
    ],
    BinaryId: "i=397",
    JsonId: "i=15090",
}

const node4492 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=4"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Int16"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Int16"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=27", "i=45", false),
    ],
}

const node4495 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=420"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FindServersRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FindServersRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=422", "i=38", true),
      new ns.Reference("i=421", "i=38", true),
      new ns.Reference("i=15093", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("EndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("LocaleIds", "i=295", "i=12", 1, null),
      new ns.StructField("ServerUris", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=422",
    JsonId: "i=15093",
}

const node4498 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=423"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FindServersResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FindServersResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=425", "i=38", true),
      new ns.Reference("i=424", "i=38", true),
      new ns.Reference("i=15094", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Servers", "i=308", "i=22", 1, null),
    ],
    BinaryId: "i=425",
    JsonId: "i=15094",
}

const node4501 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=426"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "GetEndpointsRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("GetEndpointsRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=428", "i=38", true),
      new ns.Reference("i=427", "i=38", true),
      new ns.Reference("i=15100", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("EndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("LocaleIds", "i=295", "i=12", 1, null),
      new ns.StructField("ProfileUris", "i=12", "i=12", 1, null),
    ],
    BinaryId: "i=428",
    JsonId: "i=15100",
}

const node4504 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=429"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "GetEndpointsResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("GetEndpointsResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=431", "i=38", true),
      new ns.Reference("i=430", "i=38", true),
      new ns.Reference("i=15101", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Endpoints", "i=312", "i=22", 1, null),
    ],
    BinaryId: "i=431",
    JsonId: "i=15101",
}

const node4507 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=432"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RegisteredServer"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RegisteredServer"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=434", "i=38", true),
      new ns.Reference("i=433", "i=38", true),
      new ns.Reference("i=15102", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ServerUri", "i=12", "i=12", -1, null),
      new ns.StructField("ProductUri", "i=12", "i=12", -1, null),
      new ns.StructField("ServerNames", "i=21", "i=21", 1, null),
      new ns.StructField("ServerType", "i=307", "i=29", -1, null),
      new ns.StructField("GatewayServerUri", "i=12", "i=12", -1, null),
      new ns.StructField("DiscoveryUrls", "i=12", "i=12", 1, null),
      new ns.StructField("SemaphoreFilePath", "i=12", "i=12", -1, null),
      new ns.StructField("IsOnline", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=434",
    JsonId: "i=15102",
}

const node4510 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=435"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RegisterServerRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RegisterServerRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=437", "i=38", true),
      new ns.Reference("i=436", "i=38", true),
      new ns.Reference("i=15103", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("Server", "i=432", "i=22", -1, null),
    ],
    BinaryId: "i=437",
    JsonId: "i=15103",
}

const node4513 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=438"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RegisterServerResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RegisterServerResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=440", "i=38", true),
      new ns.Reference("i=439", "i=38", true),
      new ns.Reference("i=15104", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
    ],
    BinaryId: "i=440",
    JsonId: "i=15104",
}

const node4517 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=441"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ChannelSecurityToken"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ChannelSecurityToken"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=443", "i=38", true),
      new ns.Reference("i=442", "i=38", true),
      new ns.Reference("i=15131", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ChannelId", "i=7", "i=7", -1, null),
      new ns.StructField("TokenId", "i=7", "i=7", -1, null),
      new ns.StructField("CreatedAt", "i=294", "i=13", -1, null),
      new ns.StructField("RevisedLifetime", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=443",
    JsonId: "i=15131",
}

const node4520 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=444"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "OpenSecureChannelRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("OpenSecureChannelRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=446", "i=38", true),
      new ns.Reference("i=445", "i=38", true),
      new ns.Reference("i=15132", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("ClientProtocolVersion", "i=7", "i=7", -1, null),
      new ns.StructField("RequestType", "i=315", "i=29", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("ClientNonce", "i=15", "i=15", -1, null),
      new ns.StructField("RequestedLifetime", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=446",
    JsonId: "i=15132",
}

const node4523 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=447"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "OpenSecureChannelResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("OpenSecureChannelResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=449", "i=38", true),
      new ns.Reference("i=448", "i=38", true),
      new ns.Reference("i=15133", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("ServerProtocolVersion", "i=7", "i=7", -1, null),
      new ns.StructField("SecurityToken", "i=441", "i=22", -1, null),
      new ns.StructField("ServerNonce", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=449",
    JsonId: "i=15133",
}

const node4527 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=450"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CloseSecureChannelRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CloseSecureChannelRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=452", "i=38", true),
      new ns.Reference("i=451", "i=38", true),
      new ns.Reference("i=15134", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
    ],
    BinaryId: "i=452",
    JsonId: "i=15134",
}

const node4530 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=453"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CloseSecureChannelResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CloseSecureChannelResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=455", "i=38", true),
      new ns.Reference("i=454", "i=38", true),
      new ns.Reference("i=15135", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
    ],
    BinaryId: "i=455",
    JsonId: "i=15135",
}

const node4533 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=456"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SignatureData"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SignatureData"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=458", "i=38", true),
      new ns.Reference("i=457", "i=38", true),
      new ns.Reference("i=15137", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Algorithm", "i=12", "i=12", -1, null),
      new ns.StructField("Signature", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=458",
    JsonId: "i=15137",
}

const node4536 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=459"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CreateSessionRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CreateSessionRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=461", "i=38", true),
      new ns.Reference("i=460", "i=38", true),
      new ns.Reference("i=15138", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("ClientDescription", "i=308", "i=22", -1, null),
      new ns.StructField("ServerUri", "i=12", "i=12", -1, null),
      new ns.StructField("EndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("SessionName", "i=12", "i=12", -1, null),
      new ns.StructField("ClientNonce", "i=15", "i=15", -1, null),
      new ns.StructField("ClientCertificate", "i=311", "i=15", -1, null),
      new ns.StructField("RequestedSessionTimeout", "i=290", "i=11", -1, null),
      new ns.StructField("MaxResponseMessageSize", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=461",
    JsonId: "i=15138",
}

const node4540 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=462"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CreateSessionResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CreateSessionResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=464", "i=38", true),
      new ns.Reference("i=463", "i=38", true),
      new ns.Reference("i=15139", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("SessionId", "i=17", "i=17", -1, null),
      new ns.StructField("AuthenticationToken", "i=388", "i=17", -1, null),
      new ns.StructField("RevisedSessionTimeout", "i=290", "i=11", -1, null),
      new ns.StructField("ServerNonce", "i=15", "i=15", -1, null),
      new ns.StructField("ServerCertificate", "i=311", "i=15", -1, null),
      new ns.StructField("ServerEndpoints", "i=312", "i=22", 1, null),
      new ns.StructField("ServerSoftwareCertificates", "i=344", "i=22", 1, null),
      new ns.StructField("ServerSignature", "i=456", "i=22", -1, null),
      new ns.StructField("MaxRequestMessageSize", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=464",
    JsonId: "i=15139",
}

const node4543 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=465"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ActivateSessionRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ActivateSessionRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=467", "i=38", true),
      new ns.Reference("i=466", "i=38", true),
      new ns.Reference("i=15145", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("ClientSignature", "i=456", "i=22", -1, null),
      new ns.StructField("ClientSoftwareCertificates", "i=344", "i=22", 1, null),
      new ns.StructField("LocaleIds", "i=295", "i=12", 1, null),
      new ns.StructField("UserIdentityToken", "i=22", "i=22", -1, null),
      new ns.StructField("UserTokenSignature", "i=456", "i=22", -1, null),
    ],
    BinaryId: "i=467",
    JsonId: "i=15145",
}

const node4546 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=468"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ActivateSessionResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ActivateSessionResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=470", "i=38", true),
      new ns.Reference("i=469", "i=38", true),
      new ns.Reference("i=15146", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("ServerNonce", "i=15", "i=15", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=470",
    JsonId: "i=15146",
}

const node4550 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=471"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CloseSessionRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CloseSessionRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=473", "i=38", true),
      new ns.Reference("i=472", "i=38", true),
      new ns.Reference("i=15147", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("DeleteSubscriptions", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=473",
    JsonId: "i=15147",
}

const node4553 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=474"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CloseSessionResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CloseSessionResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=476", "i=38", true),
      new ns.Reference("i=475", "i=38", true),
      new ns.Reference("i=15148", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
    ],
    BinaryId: "i=476",
    JsonId: "i=15148",
}

const node4556 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=477"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CancelRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CancelRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=479", "i=38", true),
      new ns.Reference("i=478", "i=38", true),
      new ns.Reference("i=15149", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("RequestHandle", "i=288", "i=7", -1, null),
    ],
    BinaryId: "i=479",
    JsonId: "i=15149",
}

const node4560 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=480"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CancelResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CancelResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=482", "i=38", true),
      new ns.Reference("i=481", "i=38", true),
      new ns.Reference("i=15150", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("CancelCount", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=482",
    JsonId: "i=15150",
}

const node4563 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=483"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AddNodesResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AddNodesResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=485", "i=38", true),
      new ns.Reference("i=484", "i=38", true),
      new ns.Reference("i=15166", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("AddedNodeId", "i=17", "i=17", -1, null),
    ],
    BinaryId: "i=485",
    JsonId: "i=15166",
}

const node4566 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=486"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AddNodesRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AddNodesRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=488", "i=38", true),
      new ns.Reference("i=487", "i=38", true),
      new ns.Reference("i=15167", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("NodesToAdd", "i=376", "i=22", 1, null),
    ],
    BinaryId: "i=488",
    JsonId: "i=15167",
}

const node4569 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=489"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AddNodesResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AddNodesResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=491", "i=38", true),
      new ns.Reference("i=490", "i=38", true),
      new ns.Reference("i=15168", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=483", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=491",
    JsonId: "i=15168",
}

const node4573 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=492"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AddReferencesRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AddReferencesRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=494", "i=38", true),
      new ns.Reference("i=493", "i=38", true),
      new ns.Reference("i=15170", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("ReferencesToAdd", "i=379", "i=22", 1, null),
    ],
    BinaryId: "i=494",
    JsonId: "i=15170",
}

const node4576 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=495"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AddReferencesResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AddReferencesResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=497", "i=38", true),
      new ns.Reference("i=496", "i=38", true),
      new ns.Reference("i=15171", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=497",
    JsonId: "i=15171",
}

const node4579 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=498"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteNodesRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteNodesRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=500", "i=38", true),
      new ns.Reference("i=499", "i=38", true),
      new ns.Reference("i=15173", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("NodesToDelete", "i=382", "i=22", 1, null),
    ],
    BinaryId: "i=500",
    JsonId: "i=15173",
}

const node4581 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=5"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UInt16"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UInt16"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=28", "i=45", false),
      new ns.Reference("i=15904", "i=45", true),
      new ns.Reference("i=95", "i=45", true),
    ],
}

const node4582 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=50"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Decimal"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Decimal"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=26", "i=45", false),
    ],
}

const node4584 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=501"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteNodesResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteNodesResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=503", "i=38", true),
      new ns.Reference("i=502", "i=38", true),
      new ns.Reference("i=15174", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=503",
    JsonId: "i=15174",
}

const node4587 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=504"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteReferencesRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteReferencesRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=506", "i=38", true),
      new ns.Reference("i=505", "i=38", true),
      new ns.Reference("i=15176", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("ReferencesToDelete", "i=385", "i=22", 1, null),
    ],
    BinaryId: "i=506",
    JsonId: "i=15176",
}

const node4590 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=507"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteReferencesResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteReferencesResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=509", "i=38", true),
      new ns.Reference("i=508", "i=38", true),
      new ns.Reference("i=15177", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=509",
    JsonId: "i=15177",
}

const node4594 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=510"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseDirection"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseDirection"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7603", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Forward", 0),
      new ns.EnumField("Inverse", 1),
      new ns.EnumField("Both", 2),
      new ns.EnumField("Invalid", 3),
    ],
}

const node4595 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=511"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ViewDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ViewDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=513", "i=38", true),
      new ns.Reference("i=512", "i=38", true),
      new ns.Reference("i=15179", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ViewId", "i=17", "i=17", -1, null),
      new ns.StructField("Timestamp", "i=294", "i=13", -1, null),
      new ns.StructField("ViewVersion", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=513",
    JsonId: "i=15179",
}

const node4598 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=514"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=516", "i=38", true),
      new ns.Reference("i=515", "i=38", true),
      new ns.Reference("i=15180", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("BrowseDirection", "i=510", "i=29", -1, null),
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("IncludeSubtypes", "i=1", "i=1", -1, null),
      new ns.StructField("NodeClassMask", "i=7", "i=7", -1, null),
      new ns.StructField("ResultMask", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=516",
    JsonId: "i=15180",
}

const node4601 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=517"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseResultMask"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseResultMask"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=11883", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("None", 0),
      new ns.EnumField("ReferenceTypeId", 1),
      new ns.EnumField("IsForward", 2),
      new ns.EnumField("NodeClass", 4),
      new ns.EnumField("BrowseName", 8),
      new ns.EnumField("DisplayName", 16),
      new ns.EnumField("TypeDefinition", 32),
      new ns.EnumField("All", 63),
      new ns.EnumField("ReferenceTypeInfo", 3),
      new ns.EnumField("TargetInfo", 60),
    ],
}

const node4602 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=518"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReferenceDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReferenceDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=520", "i=38", true),
      new ns.Reference("i=519", "i=38", true),
      new ns.Reference("i=15182", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("IsForward", "i=1", "i=1", -1, null),
      new ns.StructField("NodeId", "i=18", "i=18", -1, null),
      new ns.StructField("BrowseName", "i=20", "i=20", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("NodeClass", "i=257", "i=29", -1, null),
      new ns.StructField("TypeDefinition", "i=18", "i=18", -1, null),
    ],
    BinaryId: "i=520",
    JsonId: "i=15182",
}

const node4606 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=521"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ContinuationPoint"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ContinuationPoint"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15", "i=45", false),
    ],
}

const node4607 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=522"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=524", "i=38", true),
      new ns.Reference("i=523", "i=38", true),
      new ns.Reference("i=15183", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("ContinuationPoint", "i=521", "i=15", -1, null),
      new ns.StructField("References", "i=518", "i=22", 1, null),
    ],
    BinaryId: "i=524",
    JsonId: "i=15183",
}

const node4610 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=525"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=527", "i=38", true),
      new ns.Reference("i=526", "i=38", true),
      new ns.Reference("i=15184", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("View", "i=511", "i=22", -1, null),
      new ns.StructField("RequestedMaxReferencesPerNode", "i=289", "i=7", -1, null),
      new ns.StructField("NodesToBrowse", "i=514", "i=22", 1, null),
    ],
    BinaryId: "i=527",
    JsonId: "i=15184",
}

const node4613 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=528"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=530", "i=38", true),
      new ns.Reference("i=529", "i=38", true),
      new ns.Reference("i=15185", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=522", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=530",
    JsonId: "i=15185",
}

const node4617 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=531"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseNextRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseNextRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=533", "i=38", true),
      new ns.Reference("i=532", "i=38", true),
      new ns.Reference("i=15186", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("ReleaseContinuationPoints", "i=1", "i=1", -1, null),
      new ns.StructField("ContinuationPoints", "i=521", "i=15", 1, null),
    ],
    BinaryId: "i=533",
    JsonId: "i=15186",
}

const node4620 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=534"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowseNextResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowseNextResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=536", "i=38", true),
      new ns.Reference("i=535", "i=38", true),
      new ns.Reference("i=15187", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=522", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=536",
    JsonId: "i=15187",
}

const node4623 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=537"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RelativePathElement"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RelativePathElement"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=539", "i=38", true),
      new ns.Reference("i=538", "i=38", true),
      new ns.Reference("i=15188", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("IsInverse", "i=1", "i=1", -1, null),
      new ns.StructField("IncludeSubtypes", "i=1", "i=1", -1, null),
      new ns.StructField("TargetName", "i=20", "i=20", -1, null),
    ],
    BinaryId: "i=539",
    JsonId: "i=15188",
}

const node4627 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=540"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RelativePath"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RelativePath"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=542", "i=38", true),
      new ns.Reference("i=541", "i=38", true),
      new ns.Reference("i=15189", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Elements", "i=537", "i=22", 1, null),
    ],
    BinaryId: "i=542",
    JsonId: "i=15189",
}

const node4630 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=543"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowsePath"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowsePath"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=545", "i=38", true),
      new ns.Reference("i=544", "i=38", true),
      new ns.Reference("i=15190", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StartingNode", "i=17", "i=17", -1, null),
      new ns.StructField("RelativePath", "i=540", "i=22", -1, null),
    ],
    BinaryId: "i=545",
    JsonId: "i=15190",
}

const node4633 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=546"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowsePathTarget"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowsePathTarget"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=548", "i=38", true),
      new ns.Reference("i=547", "i=38", true),
      new ns.Reference("i=15191", "i=38", true),
    ],
    Definition: [
      new ns.StructField("TargetId", "i=18", "i=18", -1, null),
      new ns.StructField("RemainingPathIndex", "i=17588", "i=7", -1, null),
    ],
    BinaryId: "i=548",
    JsonId: "i=15191",
}

const node4636 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=549"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "BrowsePathResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("BrowsePathResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=551", "i=38", true),
      new ns.Reference("i=550", "i=38", true),
      new ns.Reference("i=15192", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("Targets", "i=546", "i=22", 1, null),
    ],
    BinaryId: "i=551",
    JsonId: "i=15192",
}

const node4639 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=552"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TranslateBrowsePathsToNodeIdsRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TranslateBrowsePathsToNodeIdsRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=554", "i=38", true),
      new ns.Reference("i=553", "i=38", true),
      new ns.Reference("i=15193", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("BrowsePaths", "i=543", "i=22", 1, null),
    ],
    BinaryId: "i=554",
    JsonId: "i=15193",
}

const node4642 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=555"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TranslateBrowsePathsToNodeIdsResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TranslateBrowsePathsToNodeIdsResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=557", "i=38", true),
      new ns.Reference("i=556", "i=38", true),
      new ns.Reference("i=15194", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=549", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=557",
    JsonId: "i=15194",
}

const node4645 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=558"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RegisterNodesRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RegisterNodesRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=560", "i=38", true),
      new ns.Reference("i=559", "i=38", true),
      new ns.Reference("i=15195", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("NodesToRegister", "i=17", "i=17", 1, null),
    ],
    BinaryId: "i=560",
    JsonId: "i=15195",
}

const node4649 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=561"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RegisterNodesResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RegisterNodesResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=563", "i=38", true),
      new ns.Reference("i=562", "i=38", true),
      new ns.Reference("i=15196", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("RegisteredNodeIds", "i=17", "i=17", 1, null),
    ],
    BinaryId: "i=563",
    JsonId: "i=15196",
}

const node4652 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=564"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UnregisterNodesRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UnregisterNodesRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=566", "i=38", true),
      new ns.Reference("i=565", "i=38", true),
      new ns.Reference("i=15197", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("NodesToUnregister", "i=17", "i=17", 1, null),
    ],
    BinaryId: "i=566",
    JsonId: "i=15197",
}

const node4655 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=567"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UnregisterNodesResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UnregisterNodesResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=569", "i=38", true),
      new ns.Reference("i=568", "i=38", true),
      new ns.Reference("i=15198", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
    ],
    BinaryId: "i=569",
    JsonId: "i=15198",
}

const node4658 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=570"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QueryDataDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QueryDataDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=572", "i=38", true),
      new ns.Reference("i=571", "i=38", true),
      new ns.Reference("i=15200", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RelativePath", "i=540", "i=22", -1, null),
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("IndexRange", "i=291", "i=12", -1, null),
    ],
    BinaryId: "i=572",
    JsonId: "i=15200",
}

const node4661 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=573"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NodeTypeDescription"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NodeTypeDescription"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=575", "i=38", true),
      new ns.Reference("i=574", "i=38", true),
      new ns.Reference("i=15201", "i=38", true),
    ],
    Definition: [
      new ns.StructField("TypeDefinitionNode", "i=18", "i=18", -1, null),
      new ns.StructField("IncludeSubTypes", "i=1", "i=1", -1, null),
      new ns.StructField("DataToReturn", "i=570", "i=22", 1, null),
    ],
    BinaryId: "i=575",
    JsonId: "i=15201",
}

const node4664 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=576"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FilterOperator"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FilterOperator"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7605", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Equals", 0),
      new ns.EnumField("IsNull", 1),
      new ns.EnumField("GreaterThan", 2),
      new ns.EnumField("LessThan", 3),
      new ns.EnumField("GreaterThanOrEqual", 4),
      new ns.EnumField("LessThanOrEqual", 5),
      new ns.EnumField("Like", 6),
      new ns.EnumField("Not", 7),
      new ns.EnumField("Between", 8),
      new ns.EnumField("InList", 9),
      new ns.EnumField("And", 10),
      new ns.EnumField("Or", 11),
      new ns.EnumField("Cast", 12),
      new ns.EnumField("InView", 13),
      new ns.EnumField("OfType", 14),
      new ns.EnumField("RelatedTo", 15),
      new ns.EnumField("BitwiseAnd", 16),
      new ns.EnumField("BitwiseOr", 17),
    ],
}

const node4665 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=577"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QueryDataSet"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QueryDataSet"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=579", "i=38", true),
      new ns.Reference("i=578", "i=38", true),
      new ns.Reference("i=15202", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=18", "i=18", -1, null),
      new ns.StructField("TypeDefinitionNode", "i=18", "i=18", -1, null),
      new ns.StructField("Values", "nil", "nil", 1, null),
    ],
    BinaryId: "i=579",
    JsonId: "i=15202",
}

const node4669 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=580"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NodeReference"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NodeReference"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=582", "i=38", true),
      new ns.Reference("i=581", "i=38", true),
      new ns.Reference("i=15203", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("ReferenceTypeId", "i=17", "i=17", -1, null),
      new ns.StructField("IsForward", "i=1", "i=1", -1, null),
      new ns.StructField("ReferencedNodeIds", "i=17", "i=17", 1, null),
    ],
    BinaryId: "i=582",
    JsonId: "i=15203",
}

const node4672 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=583"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ContentFilterElement"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ContentFilterElement"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=585", "i=38", true),
      new ns.Reference("i=584", "i=38", true),
      new ns.Reference("i=15204", "i=38", true),
    ],
    Definition: [
      new ns.StructField("FilterOperator", "i=576", "i=29", -1, null),
      new ns.StructField("FilterOperands", "i=22", "i=22", 1, null),
    ],
    BinaryId: "i=585",
    JsonId: "i=15204",
}

const node4675 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=586"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ContentFilter"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ContentFilter"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=588", "i=38", true),
      new ns.Reference("i=587", "i=38", true),
      new ns.Reference("i=15205", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Elements", "i=583", "i=22", 1, null),
    ],
    BinaryId: "i=588",
    JsonId: "i=15205",
}

const node4678 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=589"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "FilterOperand"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("FilterOperand"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=592", "i=45", true),
      new ns.Reference("i=595", "i=45", true),
      new ns.Reference("i=598", "i=45", true),
      new ns.Reference("i=601", "i=45", true),
      new ns.Reference("i=591", "i=38", true),
      new ns.Reference("i=590", "i=38", true),
      new ns.Reference("i=15206", "i=38", true),
    ],
}

const node4681 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=592"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ElementOperand"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ElementOperand"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=589", "i=45", false),
      new ns.Reference("i=594", "i=38", true),
      new ns.Reference("i=593", "i=38", true),
      new ns.Reference("i=15207", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Index", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=594",
    JsonId: "i=15207",
}

const node4684 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=595"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "LiteralOperand"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("LiteralOperand"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=589", "i=45", false),
      new ns.Reference("i=597", "i=38", true),
      new ns.Reference("i=596", "i=38", true),
      new ns.Reference("i=15208", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Value", "i=23", "i=23", -1, null),
    ],
    BinaryId: "i=597",
    JsonId: "i=15208",
}

const node4687 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=598"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AttributeOperand"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AttributeOperand"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=589", "i=45", false),
      new ns.Reference("i=600", "i=38", true),
      new ns.Reference("i=599", "i=38", true),
      new ns.Reference("i=15209", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("Alias", "i=12", "i=12", -1, null),
      new ns.StructField("BrowsePath", "i=540", "i=22", -1, null),
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("IndexRange", "i=291", "i=12", -1, null),
    ],
    BinaryId: "i=600",
    JsonId: "i=15209",
}

const node4689 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=6"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Int32"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Int32"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=27", "i=45", false),
    ],
}

const node4691 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=601"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SimpleAttributeOperand"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SimpleAttributeOperand"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=589", "i=45", false),
      new ns.Reference("i=603", "i=38", true),
      new ns.Reference("i=602", "i=38", true),
      new ns.Reference("i=15210", "i=38", true),
    ],
    Definition: [
      new ns.StructField("TypeDefinitionId", "i=17", "i=17", -1, null),
      new ns.StructField("BrowsePath", "i=20", "i=20", 1, null),
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("IndexRange", "i=291", "i=12", -1, null),
    ],
    BinaryId: "i=603",
    JsonId: "i=15210",
}

const node4694 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=604"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ContentFilterElementResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ContentFilterElementResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=606", "i=38", true),
      new ns.Reference("i=605", "i=38", true),
      new ns.Reference("i=15211", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("OperandStatusCodes", "i=19", "i=19", 1, null),
      new ns.StructField("OperandDiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=606",
    JsonId: "i=15211",
}

const node4697 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=607"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ContentFilterResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ContentFilterResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=609", "i=38", true),
      new ns.Reference("i=608", "i=38", true),
      new ns.Reference("i=15228", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ElementResults", "i=604", "i=22", 1, null),
      new ns.StructField("ElementDiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=609",
    JsonId: "i=15228",
}

const node4702 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=610"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ParsingResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ParsingResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=612", "i=38", true),
      new ns.Reference("i=611", "i=38", true),
      new ns.Reference("i=15236", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("DataStatusCodes", "i=19", "i=19", 1, null),
      new ns.StructField("DataDiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=612",
    JsonId: "i=15236",
}

const node4707 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=613"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QueryFirstRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QueryFirstRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=615", "i=38", true),
      new ns.Reference("i=614", "i=38", true),
      new ns.Reference("i=15244", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("View", "i=511", "i=22", -1, null),
      new ns.StructField("NodeTypes", "i=573", "i=22", 1, null),
      new ns.StructField("Filter", "i=586", "i=22", -1, null),
      new ns.StructField("MaxDataSetsToReturn", "i=289", "i=7", -1, null),
      new ns.StructField("MaxReferencesToReturn", "i=289", "i=7", -1, null),
    ],
    BinaryId: "i=615",
    JsonId: "i=15244",
}

const node4710 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=616"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QueryFirstResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QueryFirstResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=618", "i=38", true),
      new ns.Reference("i=617", "i=38", true),
      new ns.Reference("i=15252", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("QueryDataSets", "i=577", "i=22", 1, null),
      new ns.StructField("ContinuationPoint", "i=521", "i=15", -1, null),
      new ns.StructField("ParsingResults", "i=610", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
      new ns.StructField("FilterResult", "i=607", "i=22", -1, null),
    ],
    BinaryId: "i=618",
    JsonId: "i=15252",
}

const node4713 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=619"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QueryNextRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QueryNextRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=621", "i=38", true),
      new ns.Reference("i=620", "i=38", true),
      new ns.Reference("i=15254", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("ReleaseContinuationPoint", "i=1", "i=1", -1, null),
      new ns.StructField("ContinuationPoint", "i=521", "i=15", -1, null),
    ],
    BinaryId: "i=621",
    JsonId: "i=15254",
}

const node4717 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=622"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "QueryNextResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("QueryNextResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=624", "i=38", true),
      new ns.Reference("i=623", "i=38", true),
      new ns.Reference("i=15255", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("QueryDataSets", "i=577", "i=22", 1, null),
      new ns.StructField("RevisedContinuationPoint", "i=521", "i=15", -1, null),
    ],
    BinaryId: "i=624",
    JsonId: "i=15255",
}

const node4720 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=625"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TimestampsToReturn"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TimestampsToReturn"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7606", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Source", 0),
      new ns.EnumField("Server", 1),
      new ns.EnumField("Both", 2),
      new ns.EnumField("Neither", 3),
      new ns.EnumField("Invalid", 4),
    ],
}

const node4721 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=626"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadValueId"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadValueId"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=628", "i=38", true),
      new ns.Reference("i=627", "i=38", true),
      new ns.Reference("i=15256", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("IndexRange", "i=291", "i=12", -1, null),
      new ns.StructField("DataEncoding", "i=20", "i=20", -1, null),
    ],
    BinaryId: "i=628",
    JsonId: "i=15256",
}

const node4724 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=629"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=631", "i=38", true),
      new ns.Reference("i=630", "i=38", true),
      new ns.Reference("i=15257", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("MaxAge", "i=290", "i=11", -1, null),
      new ns.StructField("TimestampsToReturn", "i=625", "i=29", -1, null),
      new ns.StructField("NodesToRead", "i=626", "i=22", 1, null),
    ],
    BinaryId: "i=631",
    JsonId: "i=15257",
}

const node4728 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=632"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=634", "i=38", true),
      new ns.Reference("i=633", "i=38", true),
      new ns.Reference("i=15258", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=23", "i=23", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=634",
    JsonId: "i=15258",
}

const node4731 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=635"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryReadValueId"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryReadValueId"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=637", "i=38", true),
      new ns.Reference("i=636", "i=38", true),
      new ns.Reference("i=15259", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("IndexRange", "i=291", "i=12", -1, null),
      new ns.StructField("DataEncoding", "i=20", "i=20", -1, null),
      new ns.StructField("ContinuationPoint", "i=521", "i=15", -1, null),
    ],
    BinaryId: "i=637",
    JsonId: "i=15259",
}

const node4734 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=638"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryReadResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryReadResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=640", "i=38", true),
      new ns.Reference("i=639", "i=38", true),
      new ns.Reference("i=15260", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("ContinuationPoint", "i=521", "i=15", -1, null),
      new ns.StructField("HistoryData", "i=22", "i=22", -1, null),
    ],
    BinaryId: "i=640",
    JsonId: "i=15260",
}

const node4737 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=641"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryReadDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryReadDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=644", "i=45", true),
      new ns.Reference("i=647", "i=45", true),
      new ns.Reference("i=650", "i=45", true),
      new ns.Reference("i=653", "i=45", true),
      new ns.Reference("i=23497", "i=45", true),
      new ns.Reference("i=643", "i=38", true),
      new ns.Reference("i=642", "i=38", true),
      new ns.Reference("i=15261", "i=38", true),
    ],
}

const node4740 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=644"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadEventDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadEventDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=641", "i=45", false),
      new ns.Reference("i=646", "i=38", true),
      new ns.Reference("i=645", "i=38", true),
      new ns.Reference("i=15262", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NumValuesPerNode", "i=289", "i=7", -1, null),
      new ns.StructField("StartTime", "i=294", "i=13", -1, null),
      new ns.StructField("EndTime", "i=294", "i=13", -1, null),
      new ns.StructField("Filter", "i=725", "i=22", -1, null),
    ],
    BinaryId: "i=646",
    JsonId: "i=15262",
}

const node4743 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=647"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadRawModifiedDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadRawModifiedDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=641", "i=45", false),
      new ns.Reference("i=649", "i=38", true),
      new ns.Reference("i=648", "i=38", true),
      new ns.Reference("i=15263", "i=38", true),
    ],
    Definition: [
      new ns.StructField("IsReadModified", "i=1", "i=1", -1, null),
      new ns.StructField("StartTime", "i=294", "i=13", -1, null),
      new ns.StructField("EndTime", "i=294", "i=13", -1, null),
      new ns.StructField("NumValuesPerNode", "i=289", "i=7", -1, null),
      new ns.StructField("ReturnBounds", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=649",
    JsonId: "i=15263",
}

const node4746 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=650"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadProcessedDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadProcessedDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=641", "i=45", false),
      new ns.Reference("i=652", "i=38", true),
      new ns.Reference("i=651", "i=38", true),
      new ns.Reference("i=15264", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StartTime", "i=294", "i=13", -1, null),
      new ns.StructField("EndTime", "i=294", "i=13", -1, null),
      new ns.StructField("ProcessingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("AggregateType", "i=17", "i=17", 1, null),
      new ns.StructField("AggregateConfiguration", "i=948", "i=22", -1, null),
    ],
    BinaryId: "i=652",
    JsonId: "i=15264",
}

const node4749 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=653"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ReadAtTimeDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ReadAtTimeDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=641", "i=45", false),
      new ns.Reference("i=655", "i=38", true),
      new ns.Reference("i=654", "i=38", true),
      new ns.Reference("i=15269", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ReqTimes", "i=294", "i=13", 1, null),
      new ns.StructField("UseSimpleBounds", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=655",
    JsonId: "i=15269",
}

const node4752 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=656"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryData"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryData"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=11217", "i=45", true),
      new ns.Reference("i=658", "i=38", true),
      new ns.Reference("i=657", "i=38", true),
      new ns.Reference("i=15270", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DataValues", "i=23", "i=23", 1, null),
    ],
    BinaryId: "i=658",
    JsonId: "i=15270",
}

const node4755 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=659"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryEvent"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryEvent"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=661", "i=38", true),
      new ns.Reference("i=660", "i=38", true),
      new ns.Reference("i=15273", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Events", "i=920", "i=22", 1, null),
    ],
    BinaryId: "i=661",
    JsonId: "i=15273",
}

const node4758 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=662"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryReadRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryReadRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=664", "i=38", true),
      new ns.Reference("i=663", "i=38", true),
      new ns.Reference("i=15274", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("HistoryReadDetails", "i=22", "i=22", -1, null),
      new ns.StructField("TimestampsToReturn", "i=625", "i=29", -1, null),
      new ns.StructField("ReleaseContinuationPoints", "i=1", "i=1", -1, null),
      new ns.StructField("NodesToRead", "i=635", "i=22", 1, null),
    ],
    BinaryId: "i=664",
    JsonId: "i=15274",
}

const node4761 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=665"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryReadResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryReadResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=667", "i=38", true),
      new ns.Reference("i=666", "i=38", true),
      new ns.Reference("i=15275", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=638", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=667",
    JsonId: "i=15275",
}

const node4764 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=668"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "WriteValue"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("WriteValue"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=670", "i=38", true),
      new ns.Reference("i=669", "i=38", true),
      new ns.Reference("i=15276", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("AttributeId", "i=288", "i=7", -1, null),
      new ns.StructField("IndexRange", "i=291", "i=12", -1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
    ],
    BinaryId: "i=670",
    JsonId: "i=15276",
}

const node4767 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=671"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "WriteRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("WriteRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=673", "i=38", true),
      new ns.Reference("i=672", "i=38", true),
      new ns.Reference("i=15277", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("NodesToWrite", "i=668", "i=22", 1, null),
    ],
    BinaryId: "i=673",
    JsonId: "i=15277",
}

const node4770 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=674"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "WriteResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("WriteResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=676", "i=38", true),
      new ns.Reference("i=675", "i=38", true),
      new ns.Reference("i=15278", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=676",
    JsonId: "i=15278",
}

const node4773 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=677"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryUpdateDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryUpdateDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=680", "i=45", true),
      new ns.Reference("i=11295", "i=45", true),
      new ns.Reference("i=683", "i=45", true),
      new ns.Reference("i=686", "i=45", true),
      new ns.Reference("i=689", "i=45", true),
      new ns.Reference("i=692", "i=45", true),
      new ns.Reference("i=679", "i=38", true),
      new ns.Reference("i=678", "i=38", true),
      new ns.Reference("i=15279", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
    ],
    BinaryId: "i=679",
    JsonId: "i=15279",
}

const node4777 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=680"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UpdateDataDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UpdateDataDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=677", "i=45", false),
      new ns.Reference("i=682", "i=38", true),
      new ns.Reference("i=681", "i=38", true),
      new ns.Reference("i=15280", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("PerformInsertReplace", "i=11293", "i=29", -1, null),
      new ns.StructField("UpdateValues", "i=23", "i=23", 1, null),
    ],
    BinaryId: "i=682",
    JsonId: "i=15280",
}

const node4780 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=683"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UpdateEventDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UpdateEventDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=677", "i=45", false),
      new ns.Reference("i=685", "i=38", true),
      new ns.Reference("i=684", "i=38", true),
      new ns.Reference("i=15282", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("PerformInsertReplace", "i=11293", "i=29", -1, null),
      new ns.StructField("Filter", "i=725", "i=22", -1, null),
      new ns.StructField("EventData", "i=920", "i=22", 1, null),
    ],
    BinaryId: "i=685",
    JsonId: "i=15282",
}

const node4783 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=686"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteRawModifiedDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteRawModifiedDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=677", "i=45", false),
      new ns.Reference("i=688", "i=38", true),
      new ns.Reference("i=687", "i=38", true),
      new ns.Reference("i=15283", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("IsDeleteModified", "i=1", "i=1", -1, null),
      new ns.StructField("StartTime", "i=294", "i=13", -1, null),
      new ns.StructField("EndTime", "i=294", "i=13", -1, null),
    ],
    BinaryId: "i=688",
    JsonId: "i=15283",
}

const node4786 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=689"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteAtTimeDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteAtTimeDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=677", "i=45", false),
      new ns.Reference("i=691", "i=38", true),
      new ns.Reference("i=690", "i=38", true),
      new ns.Reference("i=15284", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("ReqTimes", "i=294", "i=13", 1, null),
    ],
    BinaryId: "i=691",
    JsonId: "i=15284",
}

const node4790 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=692"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteEventDetails"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteEventDetails"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=677", "i=45", false),
      new ns.Reference("i=694", "i=38", true),
      new ns.Reference("i=693", "i=38", true),
      new ns.Reference("i=15285", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NodeId", "i=17", "i=17", -1, null),
      new ns.StructField("EventIds", "i=15", "i=15", 1, null),
    ],
    BinaryId: "i=694",
    JsonId: "i=15285",
}

const node4793 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=695"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryUpdateResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryUpdateResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=697", "i=38", true),
      new ns.Reference("i=696", "i=38", true),
      new ns.Reference("i=15286", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("OperationResults", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=697",
    JsonId: "i=15286",
}

const node4796 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=698"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryUpdateRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryUpdateRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=700", "i=38", true),
      new ns.Reference("i=699", "i=38", true),
      new ns.Reference("i=15287", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("HistoryUpdateDetails", "i=22", "i=22", 1, null),
    ],
    BinaryId: "i=700",
    JsonId: "i=15287",
}

const node4798 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=7"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UInt32"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UInt32"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=28", "i=45", false),
      new ns.Reference("i=15583", "i=45", true),
      new ns.Reference("i=15642", "i=45", true),
      new ns.Reference("i=15646", "i=45", true),
      new ns.Reference("i=15654", "i=45", true),
      new ns.Reference("i=15658", "i=45", true),
      new ns.Reference("i=25517", "i=45", true),
      new ns.Reference("i=24277", "i=45", true),
      new ns.Reference("i=24279", "i=45", true),
      new ns.Reference("i=94", "i=45", true),
      new ns.Reference("i=15406", "i=45", true),
      new ns.Reference("i=17588", "i=45", true),
      new ns.Reference("i=288", "i=45", true),
      new ns.Reference("i=20998", "i=45", true),
      new ns.Reference("i=347", "i=45", true),
      new ns.Reference("i=289", "i=45", true),
    ],
}

const node4800 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=701"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryUpdateResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryUpdateResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=703", "i=38", true),
      new ns.Reference("i=702", "i=38", true),
      new ns.Reference("i=15288", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=695", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=703",
    JsonId: "i=15288",
}

const node4803 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=704"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CallMethodRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CallMethodRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=706", "i=38", true),
      new ns.Reference("i=705", "i=38", true),
      new ns.Reference("i=15289", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ObjectId", "i=17", "i=17", -1, null),
      new ns.StructField("MethodId", "i=17", "i=17", -1, null),
      new ns.StructField("InputArguments", "nil", "nil", 1, null),
    ],
    BinaryId: "i=706",
    JsonId: "i=15289",
}

const node4806 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=707"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CallMethodResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CallMethodResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=709", "i=38", true),
      new ns.Reference("i=708", "i=38", true),
      new ns.Reference("i=15290", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("InputArgumentResults", "i=19", "i=19", 1, null),
      new ns.StructField("InputArgumentDiagnosticInfos", "i=25", "i=25", 1, null),
      new ns.StructField("OutputArguments", "nil", "nil", 1, null),
    ],
    BinaryId: "i=709",
    JsonId: "i=15290",
}

const node4809 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=710"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CallRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CallRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=712", "i=38", true),
      new ns.Reference("i=711", "i=38", true),
      new ns.Reference("i=15291", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("MethodsToCall", "i=704", "i=22", 1, null),
    ],
    BinaryId: "i=712",
    JsonId: "i=15291",
}

const node4812 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=713"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CallResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CallResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=715", "i=38", true),
      new ns.Reference("i=714", "i=38", true),
      new ns.Reference("i=15292", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=707", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=715",
    JsonId: "i=15292",
}

const node4815 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=716"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoringMode"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoringMode"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7608", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Disabled", 0),
      new ns.EnumField("Sampling", 1),
      new ns.EnumField("Reporting", 2),
    ],
}

const node4816 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=717"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataChangeTrigger"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataChangeTrigger"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7609", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Status", 0),
      new ns.EnumField("StatusValue", 1),
      new ns.EnumField("StatusValueTimestamp", 2),
    ],
}

const node4817 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=718"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeadbandType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeadbandType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7610", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("None", 0),
      new ns.EnumField("Absolute", 1),
      new ns.EnumField("Percent", 2),
    ],
}

const node4818 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=719"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoringFilter"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoringFilter"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=722", "i=45", true),
      new ns.Reference("i=725", "i=45", true),
      new ns.Reference("i=728", "i=45", true),
      new ns.Reference("i=721", "i=38", true),
      new ns.Reference("i=720", "i=38", true),
      new ns.Reference("i=15293", "i=38", true),
    ],
}

const node4822 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=722"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataChangeFilter"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataChangeFilter"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=719", "i=45", false),
      new ns.Reference("i=724", "i=38", true),
      new ns.Reference("i=723", "i=38", true),
      new ns.Reference("i=15294", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Trigger", "i=717", "i=29", -1, null),
      new ns.StructField("DeadbandType", "i=7", "i=7", -1, null),
      new ns.StructField("DeadbandValue", "i=11", "i=11", -1, null),
    ],
    BinaryId: "i=724",
    JsonId: "i=15294",
}

const node4825 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=725"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EventFilter"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EventFilter"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=719", "i=45", false),
      new ns.Reference("i=727", "i=38", true),
      new ns.Reference("i=726", "i=38", true),
      new ns.Reference("i=15295", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SelectClauses", "i=601", "i=22", 1, null),
      new ns.StructField("WhereClause", "i=586", "i=22", -1, null),
    ],
    BinaryId: "i=727",
    JsonId: "i=15295",
}

const node4828 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=728"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AggregateFilter"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AggregateFilter"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=719", "i=45", false),
      new ns.Reference("i=730", "i=38", true),
      new ns.Reference("i=729", "i=38", true),
      new ns.Reference("i=15312", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StartTime", "i=294", "i=13", -1, null),
      new ns.StructField("AggregateType", "i=17", "i=17", -1, null),
      new ns.StructField("ProcessingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("AggregateConfiguration", "i=948", "i=22", -1, null),
    ],
    BinaryId: "i=730",
    JsonId: "i=15312",
}

const node4831 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=731"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoringFilterResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoringFilterResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=734", "i=45", true),
      new ns.Reference("i=737", "i=45", true),
      new ns.Reference("i=733", "i=38", true),
      new ns.Reference("i=732", "i=38", true),
      new ns.Reference("i=15313", "i=38", true),
    ],
}

const node4834 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=734"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EventFilterResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EventFilterResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=731", "i=45", false),
      new ns.Reference("i=736", "i=38", true),
      new ns.Reference("i=735", "i=38", true),
      new ns.Reference("i=15314", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SelectClauseResults", "i=19", "i=19", 1, null),
      new ns.StructField("SelectClauseDiagnosticInfos", "i=25", "i=25", 1, null),
      new ns.StructField("WhereClauseResult", "i=607", "i=22", -1, null),
    ],
    BinaryId: "i=736",
    JsonId: "i=15314",
}

const node4837 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=737"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AggregateFilterResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AggregateFilterResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=731", "i=45", false),
      new ns.Reference("i=739", "i=38", true),
      new ns.Reference("i=738", "i=38", true),
      new ns.Reference("i=15315", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RevisedStartTime", "i=294", "i=13", -1, null),
      new ns.StructField("RevisedProcessingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("RevisedAggregateConfiguration", "i=948", "i=22", -1, null),
    ],
    BinaryId: "i=739",
    JsonId: "i=15315",
}

const node4840 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=740"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoringParameters"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoringParameters"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=742", "i=38", true),
      new ns.Reference("i=741", "i=38", true),
      new ns.Reference("i=15320", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ClientHandle", "i=288", "i=7", -1, null),
      new ns.StructField("SamplingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("Filter", "i=22", "i=22", -1, null),
      new ns.StructField("QueueSize", "i=289", "i=7", -1, null),
      new ns.StructField("DiscardOldest", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=742",
    JsonId: "i=15320",
}

const node4843 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=743"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoredItemCreateRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoredItemCreateRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=745", "i=38", true),
      new ns.Reference("i=744", "i=38", true),
      new ns.Reference("i=15321", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ItemToMonitor", "i=626", "i=22", -1, null),
      new ns.StructField("MonitoringMode", "i=716", "i=29", -1, null),
      new ns.StructField("RequestedParameters", "i=740", "i=22", -1, null),
    ],
    BinaryId: "i=745",
    JsonId: "i=15321",
}

const node4846 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=746"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoredItemCreateResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoredItemCreateResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=748", "i=38", true),
      new ns.Reference("i=747", "i=38", true),
      new ns.Reference("i=15322", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("MonitoredItemId", "i=288", "i=7", -1, null),
      new ns.StructField("RevisedSamplingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("RevisedQueueSize", "i=289", "i=7", -1, null),
      new ns.StructField("FilterResult", "i=22", "i=22", -1, null),
    ],
    BinaryId: "i=748",
    JsonId: "i=15322",
}

const node4849 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=749"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CreateMonitoredItemsRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CreateMonitoredItemsRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=751", "i=38", true),
      new ns.Reference("i=750", "i=38", true),
      new ns.Reference("i=15323", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("TimestampsToReturn", "i=625", "i=29", -1, null),
      new ns.StructField("ItemsToCreate", "i=743", "i=22", 1, null),
    ],
    BinaryId: "i=751",
    JsonId: "i=15323",
}

const node4853 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=752"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CreateMonitoredItemsResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CreateMonitoredItemsResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=754", "i=38", true),
      new ns.Reference("i=753", "i=38", true),
      new ns.Reference("i=15324", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=746", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=754",
    JsonId: "i=15324",
}

const node4856 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=755"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoredItemModifyRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoredItemModifyRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=757", "i=38", true),
      new ns.Reference("i=756", "i=38", true),
      new ns.Reference("i=15325", "i=38", true),
    ],
    Definition: [
      new ns.StructField("MonitoredItemId", "i=288", "i=7", -1, null),
      new ns.StructField("RequestedParameters", "i=740", "i=22", -1, null),
    ],
    BinaryId: "i=757",
    JsonId: "i=15325",
}

const node4859 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=758"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoredItemModifyResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoredItemModifyResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=760", "i=38", true),
      new ns.Reference("i=759", "i=38", true),
      new ns.Reference("i=15326", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("RevisedSamplingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("RevisedQueueSize", "i=289", "i=7", -1, null),
      new ns.StructField("FilterResult", "i=22", "i=22", -1, null),
    ],
    BinaryId: "i=760",
    JsonId: "i=15326",
}

const node4862 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=7594"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EnumValueType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EnumValueType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=102", "i=45", true),
      new ns.Reference("i=8251", "i=38", true),
      new ns.Reference("i=7616", "i=38", true),
      new ns.Reference("i=15082", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Value", "i=8", "i=8", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
    ],
    BinaryId: "i=8251",
    JsonId: "i=15082",
}

const node4874 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=761"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ModifyMonitoredItemsRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ModifyMonitoredItemsRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=763", "i=38", true),
      new ns.Reference("i=762", "i=38", true),
      new ns.Reference("i=15327", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("TimestampsToReturn", "i=625", "i=29", -1, null),
      new ns.StructField("ItemsToModify", "i=755", "i=22", 1, null),
    ],
    BinaryId: "i=763",
    JsonId: "i=15327",
}

const node4884 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=764"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ModifyMonitoredItemsResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ModifyMonitoredItemsResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=766", "i=38", true),
      new ns.Reference("i=765", "i=38", true),
      new ns.Reference("i=15328", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=758", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=766",
    JsonId: "i=15328",
}

const node4893 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=767"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SetMonitoringModeRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SetMonitoringModeRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=769", "i=38", true),
      new ns.Reference("i=768", "i=38", true),
      new ns.Reference("i=15329", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("MonitoringMode", "i=716", "i=29", -1, null),
      new ns.StructField("MonitoredItemIds", "i=288", "i=7", 1, null),
    ],
    BinaryId: "i=769",
    JsonId: "i=15329",
}

const node4905 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=770"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SetMonitoringModeResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SetMonitoringModeResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=772", "i=38", true),
      new ns.Reference("i=771", "i=38", true),
      new ns.Reference("i=15331", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=772",
    JsonId: "i=15331",
}

const node4909 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=773"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SetTriggeringRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SetTriggeringRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=775", "i=38", true),
      new ns.Reference("i=774", "i=38", true),
      new ns.Reference("i=15332", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("TriggeringItemId", "i=288", "i=7", -1, null),
      new ns.StructField("LinksToAdd", "i=288", "i=7", 1, null),
      new ns.StructField("LinksToRemove", "i=288", "i=7", 1, null),
    ],
    BinaryId: "i=775",
    JsonId: "i=15332",
}

const node4915 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=776"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SetTriggeringResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SetTriggeringResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=778", "i=38", true),
      new ns.Reference("i=777", "i=38", true),
      new ns.Reference("i=15333", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("AddResults", "i=19", "i=19", 1, null),
      new ns.StructField("AddDiagnosticInfos", "i=25", "i=25", 1, null),
      new ns.StructField("RemoveResults", "i=19", "i=19", 1, null),
      new ns.StructField("RemoveDiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=778",
    JsonId: "i=15333",
}

const node4919 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=779"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteMonitoredItemsRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteMonitoredItemsRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=781", "i=38", true),
      new ns.Reference("i=780", "i=38", true),
      new ns.Reference("i=15335", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("MonitoredItemIds", "i=288", "i=7", 1, null),
    ],
    BinaryId: "i=781",
    JsonId: "i=15335",
}

const node4923 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=782"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteMonitoredItemsResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteMonitoredItemsResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=784", "i=38", true),
      new ns.Reference("i=783", "i=38", true),
      new ns.Reference("i=15336", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=784",
    JsonId: "i=15336",
}

const node4926 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=785"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CreateSubscriptionRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CreateSubscriptionRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=787", "i=38", true),
      new ns.Reference("i=786", "i=38", true),
      new ns.Reference("i=15337", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("RequestedPublishingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("RequestedLifetimeCount", "i=289", "i=7", -1, null),
      new ns.StructField("RequestedMaxKeepAliveCount", "i=289", "i=7", -1, null),
      new ns.StructField("MaxNotificationsPerPublish", "i=289", "i=7", -1, null),
      new ns.StructField("PublishingEnabled", "i=1", "i=1", -1, null),
      new ns.StructField("Priority", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=787",
    JsonId: "i=15337",
}

const node4929 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=788"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "CreateSubscriptionResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("CreateSubscriptionResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=790", "i=38", true),
      new ns.Reference("i=789", "i=38", true),
      new ns.Reference("i=15338", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("RevisedPublishingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("RevisedLifetimeCount", "i=289", "i=7", -1, null),
      new ns.StructField("RevisedMaxKeepAliveCount", "i=289", "i=7", -1, null),
    ],
    BinaryId: "i=790",
    JsonId: "i=15338",
}

const node4932 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=791"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ModifySubscriptionRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ModifySubscriptionRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=793", "i=38", true),
      new ns.Reference("i=792", "i=38", true),
      new ns.Reference("i=15339", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("RequestedPublishingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("RequestedLifetimeCount", "i=289", "i=7", -1, null),
      new ns.StructField("RequestedMaxKeepAliveCount", "i=289", "i=7", -1, null),
      new ns.StructField("MaxNotificationsPerPublish", "i=289", "i=7", -1, null),
      new ns.StructField("Priority", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=793",
    JsonId: "i=15339",
}

const node4939 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=794"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ModifySubscriptionResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ModifySubscriptionResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=796", "i=38", true),
      new ns.Reference("i=795", "i=38", true),
      new ns.Reference("i=15340", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("RevisedPublishingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("RevisedLifetimeCount", "i=289", "i=7", -1, null),
      new ns.StructField("RevisedMaxKeepAliveCount", "i=289", "i=7", -1, null),
    ],
    BinaryId: "i=796",
    JsonId: "i=15340",
}

const node4945 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=797"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SetPublishingModeRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SetPublishingModeRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=799", "i=38", true),
      new ns.Reference("i=798", "i=38", true),
      new ns.Reference("i=15341", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("PublishingEnabled", "i=1", "i=1", -1, null),
      new ns.StructField("SubscriptionIds", "i=288", "i=7", 1, null),
    ],
    BinaryId: "i=799",
    JsonId: "i=15341",
}

const node4948 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=8"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Int64"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Int64"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=27", "i=45", false),
    ],
}

const node4950 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=800"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SetPublishingModeResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SetPublishingModeResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=802", "i=38", true),
      new ns.Reference("i=801", "i=38", true),
      new ns.Reference("i=15342", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=802",
    JsonId: "i=15342",
}

const node4954 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=803"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NotificationMessage"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NotificationMessage"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=805", "i=38", true),
      new ns.Reference("i=804", "i=38", true),
      new ns.Reference("i=15343", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SequenceNumber", "i=289", "i=7", -1, null),
      new ns.StructField("PublishTime", "i=294", "i=13", -1, null),
      new ns.StructField("NotificationData", "i=22", "i=22", 1, null),
    ],
    BinaryId: "i=805",
    JsonId: "i=15343",
}

const node4957 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=806"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "MonitoredItemNotification"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("MonitoredItemNotification"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=808", "i=38", true),
      new ns.Reference("i=807", "i=38", true),
      new ns.Reference("i=15346", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ClientHandle", "i=288", "i=7", -1, null),
      new ns.StructField("Value", "i=23", "i=23", -1, null),
    ],
    BinaryId: "i=808",
    JsonId: "i=15346",
}

const node4963 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=809"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataChangeNotification"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataChangeNotification"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=945", "i=45", false),
      new ns.Reference("i=811", "i=38", true),
      new ns.Reference("i=810", "i=38", true),
      new ns.Reference("i=15345", "i=38", true),
    ],
    Definition: [
      new ns.StructField("MonitoredItems", "i=806", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=811",
    JsonId: "i=15345",
}

const node4967 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=818"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StatusChangeNotification"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StatusChangeNotification"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=945", "i=45", false),
      new ns.Reference("i=820", "i=38", true),
      new ns.Reference("i=819", "i=38", true),
      new ns.Reference("i=15350", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Status", "i=19", "i=19", -1, null),
      new ns.StructField("DiagnosticInfo", "i=25", "i=25", -1, null),
    ],
    BinaryId: "i=820",
    JsonId: "i=15350",
}

const node4971 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=821"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SubscriptionAcknowledgement"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SubscriptionAcknowledgement"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=823", "i=38", true),
      new ns.Reference("i=822", "i=38", true),
      new ns.Reference("i=15351", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("SequenceNumber", "i=289", "i=7", -1, null),
    ],
    BinaryId: "i=823",
    JsonId: "i=15351",
}

const node4984 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=824"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=826", "i=38", true),
      new ns.Reference("i=825", "i=38", true),
      new ns.Reference("i=15352", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionAcknowledgements", "i=821", "i=22", 1, null),
    ],
    BinaryId: "i=826",
    JsonId: "i=15352",
}

const node4993 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=827"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PublishResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PublishResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=829", "i=38", true),
      new ns.Reference("i=828", "i=38", true),
      new ns.Reference("i=15353", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("AvailableSequenceNumbers", "i=289", "i=7", 1, null),
      new ns.StructField("MoreNotifications", "i=1", "i=1", -1, null),
      new ns.StructField("NotificationMessage", "i=803", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=829",
    JsonId: "i=15353",
}

const node5001 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=830"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RepublishRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RepublishRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=832", "i=38", true),
      new ns.Reference("i=831", "i=38", true),
      new ns.Reference("i=15354", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionId", "i=288", "i=7", -1, null),
      new ns.StructField("RetransmitSequenceNumber", "i=289", "i=7", -1, null),
    ],
    BinaryId: "i=832",
    JsonId: "i=15354",
}

const node5013 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=833"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RepublishResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RepublishResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=835", "i=38", true),
      new ns.Reference("i=834", "i=38", true),
      new ns.Reference("i=15355", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("NotificationMessage", "i=803", "i=22", -1, null),
    ],
    BinaryId: "i=835",
    JsonId: "i=15355",
}

const node5017 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=836"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TransferResult"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TransferResult"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=838", "i=38", true),
      new ns.Reference("i=837", "i=38", true),
      new ns.Reference("i=15356", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StatusCode", "i=19", "i=19", -1, null),
      new ns.StructField("AvailableSequenceNumbers", "i=289", "i=7", 1, null),
    ],
    BinaryId: "i=838",
    JsonId: "i=15356",
}

const node5024 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=839"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TransferSubscriptionsRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TransferSubscriptionsRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=841", "i=38", true),
      new ns.Reference("i=840", "i=38", true),
      new ns.Reference("i=15357", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionIds", "i=288", "i=7", 1, null),
      new ns.StructField("SendInitialValues", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=841",
    JsonId: "i=15357",
}

const node5029 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=842"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TransferSubscriptionsResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TransferSubscriptionsResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=844", "i=38", true),
      new ns.Reference("i=843", "i=38", true),
      new ns.Reference("i=15358", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=836", "i=22", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=844",
    JsonId: "i=15358",
}

const node5032 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=845"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteSubscriptionsRequest"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteSubscriptionsRequest"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=847", "i=38", true),
      new ns.Reference("i=846", "i=38", true),
      new ns.Reference("i=15359", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RequestHeader", "i=389", "i=22", -1, null),
      new ns.StructField("SubscriptionIds", "i=288", "i=7", 1, null),
    ],
    BinaryId: "i=847",
    JsonId: "i=15359",
}

const node5035 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=848"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DeleteSubscriptionsResponse"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DeleteSubscriptionsResponse"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=850", "i=38", true),
      new ns.Reference("i=849", "i=38", true),
      new ns.Reference("i=15360", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ResponseHeader", "i=392", "i=22", -1, null),
      new ns.StructField("Results", "i=19", "i=19", 1, null),
      new ns.StructField("DiagnosticInfos", "i=25", "i=25", 1, null),
    ],
    BinaryId: "i=850",
    JsonId: "i=15360",
}

const node5039 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=851"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RedundancySupport"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RedundancySupport"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7611", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("None", 0),
      new ns.EnumField("Cold", 1),
      new ns.EnumField("Warm", 2),
      new ns.EnumField("Hot", 3),
      new ns.EnumField("Transparent", 4),
      new ns.EnumField("HotAndMirrored", 5),
    ],
}

const node5040 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=852"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ServerState"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ServerState"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7612", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Running", 0),
      new ns.EnumField("Failed", 1),
      new ns.EnumField("NoConfiguration", 2),
      new ns.EnumField("Suspended", 3),
      new ns.EnumField("Shutdown", 4),
      new ns.EnumField("Test", 5),
      new ns.EnumField("CommunicationFault", 6),
      new ns.EnumField("Unknown", 7),
    ],
}

const node5041 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=853"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RedundantServerDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RedundantServerDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=855", "i=38", true),
      new ns.Reference("i=854", "i=38", true),
      new ns.Reference("i=15362", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ServerId", "i=12", "i=12", -1, null),
      new ns.StructField("ServiceLevel", "i=3", "i=3", -1, null),
      new ns.StructField("ServerState", "i=852", "i=29", -1, null),
    ],
    BinaryId: "i=855",
    JsonId: "i=15362",
}

const node5044 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=856"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SamplingIntervalDiagnosticsDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SamplingIntervalDiagnosticsDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=858", "i=38", true),
      new ns.Reference("i=857", "i=38", true),
      new ns.Reference("i=15365", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SamplingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("MonitoredItemCount", "i=7", "i=7", -1, null),
      new ns.StructField("MaxMonitoredItemCount", "i=7", "i=7", -1, null),
      new ns.StructField("DisabledMonitoredItemCount", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=858",
    JsonId: "i=15365",
}

const node5054 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=859"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ServerDiagnosticsSummaryDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ServerDiagnosticsSummaryDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=861", "i=38", true),
      new ns.Reference("i=860", "i=38", true),
      new ns.Reference("i=15366", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ServerViewCount", "i=7", "i=7", -1, null),
      new ns.StructField("CurrentSessionCount", "i=7", "i=7", -1, null),
      new ns.StructField("CumulatedSessionCount", "i=7", "i=7", -1, null),
      new ns.StructField("SecurityRejectedSessionCount", "i=7", "i=7", -1, null),
      new ns.StructField("RejectedSessionCount", "i=7", "i=7", -1, null),
      new ns.StructField("SessionTimeoutCount", "i=7", "i=7", -1, null),
      new ns.StructField("SessionAbortCount", "i=7", "i=7", -1, null),
      new ns.StructField("CurrentSubscriptionCount", "i=7", "i=7", -1, null),
      new ns.StructField("CumulatedSubscriptionCount", "i=7", "i=7", -1, null),
      new ns.StructField("PublishingIntervalCount", "i=7", "i=7", -1, null),
      new ns.StructField("SecurityRejectedRequestsCount", "i=7", "i=7", -1, null),
      new ns.StructField("RejectedRequestsCount", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=861",
    JsonId: "i=15366",
}

const node5058 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=862"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ServerStatusDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ServerStatusDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=864", "i=38", true),
      new ns.Reference("i=863", "i=38", true),
      new ns.Reference("i=15367", "i=38", true),
    ],
    Definition: [
      new ns.StructField("StartTime", "i=294", "i=13", -1, null),
      new ns.StructField("CurrentTime", "i=294", "i=13", -1, null),
      new ns.StructField("State", "i=852", "i=29", -1, null),
      new ns.StructField("BuildInfo", "i=338", "i=22", -1, null),
      new ns.StructField("SecondsTillShutdown", "i=7", "i=7", -1, null),
      new ns.StructField("ShutdownReason", "i=21", "i=21", -1, null),
    ],
    BinaryId: "i=864",
    JsonId: "i=15367",
}

const node5062 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=865"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SessionDiagnosticsDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SessionDiagnosticsDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=867", "i=38", true),
      new ns.Reference("i=866", "i=38", true),
      new ns.Reference("i=15368", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SessionId", "i=17", "i=17", -1, null),
      new ns.StructField("SessionName", "i=12", "i=12", -1, null),
      new ns.StructField("ClientDescription", "i=308", "i=22", -1, null),
      new ns.StructField("ServerUri", "i=12", "i=12", -1, null),
      new ns.StructField("EndpointUrl", "i=12", "i=12", -1, null),
      new ns.StructField("LocaleIds", "i=295", "i=12", 1, null),
      new ns.StructField("ActualSessionTimeout", "i=290", "i=11", -1, null),
      new ns.StructField("MaxResponseMessageSize", "i=7", "i=7", -1, null),
      new ns.StructField("ClientConnectionTime", "i=294", "i=13", -1, null),
      new ns.StructField("ClientLastContactTime", "i=294", "i=13", -1, null),
      new ns.StructField("CurrentSubscriptionsCount", "i=7", "i=7", -1, null),
      new ns.StructField("CurrentMonitoredItemsCount", "i=7", "i=7", -1, null),
      new ns.StructField("CurrentPublishRequestsInQueue", "i=7", "i=7", -1, null),
      new ns.StructField("TotalRequestCount", "i=871", "i=22", -1, null),
      new ns.StructField("UnauthorizedRequestCount", "i=7", "i=7", -1, null),
      new ns.StructField("ReadCount", "i=871", "i=22", -1, null),
      new ns.StructField("HistoryReadCount", "i=871", "i=22", -1, null),
      new ns.StructField("WriteCount", "i=871", "i=22", -1, null),
      new ns.StructField("HistoryUpdateCount", "i=871", "i=22", -1, null),
      new ns.StructField("CallCount", "i=871", "i=22", -1, null),
      new ns.StructField("CreateMonitoredItemsCount", "i=871", "i=22", -1, null),
      new ns.StructField("ModifyMonitoredItemsCount", "i=871", "i=22", -1, null),
      new ns.StructField("SetMonitoringModeCount", "i=871", "i=22", -1, null),
      new ns.StructField("SetTriggeringCount", "i=871", "i=22", -1, null),
      new ns.StructField("DeleteMonitoredItemsCount", "i=871", "i=22", -1, null),
      new ns.StructField("CreateSubscriptionCount", "i=871", "i=22", -1, null),
      new ns.StructField("ModifySubscriptionCount", "i=871", "i=22", -1, null),
      new ns.StructField("SetPublishingModeCount", "i=871", "i=22", -1, null),
      new ns.StructField("PublishCount", "i=871", "i=22", -1, null),
      new ns.StructField("RepublishCount", "i=871", "i=22", -1, null),
      new ns.StructField("TransferSubscriptionsCount", "i=871", "i=22", -1, null),
      new ns.StructField("DeleteSubscriptionsCount", "i=871", "i=22", -1, null),
      new ns.StructField("AddNodesCount", "i=871", "i=22", -1, null),
      new ns.StructField("AddReferencesCount", "i=871", "i=22", -1, null),
      new ns.StructField("DeleteNodesCount", "i=871", "i=22", -1, null),
      new ns.StructField("DeleteReferencesCount", "i=871", "i=22", -1, null),
      new ns.StructField("BrowseCount", "i=871", "i=22", -1, null),
      new ns.StructField("BrowseNextCount", "i=871", "i=22", -1, null),
      new ns.StructField("TranslateBrowsePathsToNodeIdsCount", "i=871", "i=22", -1, null),
      new ns.StructField("QueryFirstCount", "i=871", "i=22", -1, null),
      new ns.StructField("QueryNextCount", "i=871", "i=22", -1, null),
      new ns.StructField("RegisterNodesCount", "i=871", "i=22", -1, null),
      new ns.StructField("UnregisterNodesCount", "i=871", "i=22", -1, null),
    ],
    BinaryId: "i=867",
    JsonId: "i=15368",
}

const node5065 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=868"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SessionSecurityDiagnosticsDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SessionSecurityDiagnosticsDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=870", "i=38", true),
      new ns.Reference("i=869", "i=38", true),
      new ns.Reference("i=15369", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SessionId", "i=17", "i=17", -1, null),
      new ns.StructField("ClientUserIdOfSession", "i=12", "i=12", -1, null),
      new ns.StructField("ClientUserIdHistory", "i=12", "i=12", 1, null),
      new ns.StructField("AuthenticationMechanism", "i=12", "i=12", -1, null),
      new ns.StructField("Encoding", "i=12", "i=12", -1, null),
      new ns.StructField("TransportProtocol", "i=12", "i=12", -1, null),
      new ns.StructField("SecurityMode", "i=302", "i=29", -1, null),
      new ns.StructField("SecurityPolicyUri", "i=12", "i=12", -1, null),
      new ns.StructField("ClientCertificate", "i=15", "i=15", -1, null),
    ],
    BinaryId: "i=870",
    JsonId: "i=15369",
}

const node5071 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=871"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ServiceCounterDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ServiceCounterDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=873", "i=38", true),
      new ns.Reference("i=872", "i=38", true),
      new ns.Reference("i=15370", "i=38", true),
    ],
    Definition: [
      new ns.StructField("TotalCount", "i=7", "i=7", -1, null),
      new ns.StructField("ErrorCount", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=873",
    JsonId: "i=15370",
}

const node5075 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=874"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SubscriptionDiagnosticsDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SubscriptionDiagnosticsDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=876", "i=38", true),
      new ns.Reference("i=875", "i=38", true),
      new ns.Reference("i=15372", "i=38", true),
    ],
    Definition: [
      new ns.StructField("SessionId", "i=17", "i=17", -1, null),
      new ns.StructField("SubscriptionId", "i=7", "i=7", -1, null),
      new ns.StructField("Priority", "i=3", "i=3", -1, null),
      new ns.StructField("PublishingInterval", "i=290", "i=11", -1, null),
      new ns.StructField("MaxKeepAliveCount", "i=7", "i=7", -1, null),
      new ns.StructField("MaxLifetimeCount", "i=7", "i=7", -1, null),
      new ns.StructField("MaxNotificationsPerPublish", "i=7", "i=7", -1, null),
      new ns.StructField("PublishingEnabled", "i=1", "i=1", -1, null),
      new ns.StructField("ModifyCount", "i=7", "i=7", -1, null),
      new ns.StructField("EnableCount", "i=7", "i=7", -1, null),
      new ns.StructField("DisableCount", "i=7", "i=7", -1, null),
      new ns.StructField("RepublishRequestCount", "i=7", "i=7", -1, null),
      new ns.StructField("RepublishMessageRequestCount", "i=7", "i=7", -1, null),
      new ns.StructField("RepublishMessageCount", "i=7", "i=7", -1, null),
      new ns.StructField("TransferRequestCount", "i=7", "i=7", -1, null),
      new ns.StructField("TransferredToAltClientCount", "i=7", "i=7", -1, null),
      new ns.StructField("TransferredToSameClientCount", "i=7", "i=7", -1, null),
      new ns.StructField("PublishRequestCount", "i=7", "i=7", -1, null),
      new ns.StructField("DataChangeNotificationsCount", "i=7", "i=7", -1, null),
      new ns.StructField("EventNotificationsCount", "i=7", "i=7", -1, null),
      new ns.StructField("NotificationsCount", "i=7", "i=7", -1, null),
      new ns.StructField("LatePublishRequestCount", "i=7", "i=7", -1, null),
      new ns.StructField("CurrentKeepAliveCount", "i=7", "i=7", -1, null),
      new ns.StructField("CurrentLifetimeCount", "i=7", "i=7", -1, null),
      new ns.StructField("UnacknowledgedMessageCount", "i=7", "i=7", -1, null),
      new ns.StructField("DiscardedMessageCount", "i=7", "i=7", -1, null),
      new ns.StructField("MonitoredItemCount", "i=7", "i=7", -1, null),
      new ns.StructField("DisabledMonitoredItemCount", "i=7", "i=7", -1, null),
      new ns.StructField("MonitoringQueueOverflowCount", "i=7", "i=7", -1, null),
      new ns.StructField("NextSequenceNumber", "i=7", "i=7", -1, null),
      new ns.StructField("EventQueueOverFlowCount", "i=7", "i=7", -1, null),
    ],
    BinaryId: "i=876",
    JsonId: "i=15372",
}

const node5078 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=877"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ModelChangeStructureDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ModelChangeStructureDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=879", "i=38", true),
      new ns.Reference("i=878", "i=38", true),
      new ns.Reference("i=15373", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Affected", "i=17", "i=17", -1, null),
      new ns.StructField("AffectedType", "i=17", "i=17", -1, null),
      new ns.StructField("Verb", "i=3", "i=3", -1, null),
    ],
    BinaryId: "i=879",
    JsonId: "i=15373",
}

const node5083 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=884"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Range"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Range"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=886", "i=38", true),
      new ns.Reference("i=885", "i=38", true),
      new ns.Reference("i=15375", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Low", "i=11", "i=11", -1, null),
      new ns.StructField("High", "i=11", "i=11", -1, null),
    ],
    BinaryId: "i=886",
    JsonId: "i=15375",
}

const node5095 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=887"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EUInformation"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EUInformation"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=889", "i=38", true),
      new ns.Reference("i=888", "i=38", true),
      new ns.Reference("i=15376", "i=38", true),
    ],
    Definition: [
      new ns.StructField("NamespaceUri", "i=12", "i=12", -1, null),
      new ns.StructField("UnitId", "i=6", "i=6", -1, null),
      new ns.StructField("DisplayName", "i=21", "i=21", -1, null),
      new ns.StructField("Description", "i=21", "i=21", -1, null),
    ],
    BinaryId: "i=889",
    JsonId: "i=15376",
}

const node5115 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=890"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ExceptionDeviationFormat"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ExceptionDeviationFormat"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=7614", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("AbsoluteValue", 0),
      new ns.EnumField("PercentOfValue", 1),
      new ns.EnumField("PercentOfRange", 2),
      new ns.EnumField("PercentOfEURange", 3),
      new ns.EnumField("Unknown", 4),
    ],
}

const node5118 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=891"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "Annotation"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("Annotation"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=893", "i=38", true),
      new ns.Reference("i=892", "i=38", true),
      new ns.Reference("i=15382", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Message", "i=12", "i=12", -1, null),
      new ns.StructField("UserName", "i=12", "i=12", -1, null),
      new ns.StructField("AnnotationTime", "i=294", "i=13", -1, null),
    ],
    BinaryId: "i=893",
    JsonId: "i=15382",
}

const node5119 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=8912"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "TimeZoneDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("TimeZoneDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=8917", "i=38", true),
      new ns.Reference("i=8913", "i=38", true),
      new ns.Reference("i=15086", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Offset", "i=4", "i=4", -1, null),
      new ns.StructField("DaylightSavingInOffset", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=8917",
    JsonId: "i=15086",
}

const node5127 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=894"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "ProgramDiagnosticDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("ProgramDiagnosticDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=896", "i=38", true),
      new ns.Reference("i=895", "i=38", true),
      new ns.Reference("i=15381", "i=38", true),
    ],
    Definition: [
      new ns.StructField("CreateSessionId", "i=17", "i=17", -1, null),
      new ns.StructField("CreateClientName", "i=12", "i=12", -1, null),
      new ns.StructField("InvocationCreationTime", "i=294", "i=13", -1, null),
      new ns.StructField("LastTransitionTime", "i=294", "i=13", -1, null),
      new ns.StructField("LastMethodCall", "i=12", "i=12", -1, null),
      new ns.StructField("LastMethodSessionId", "i=17", "i=17", -1, null),
      new ns.StructField("LastMethodInputArguments", "i=296", "i=22", 1, null),
      new ns.StructField("LastMethodOutputArguments", "i=296", "i=22", 1, null),
      new ns.StructField("LastMethodCallTime", "i=294", "i=13", -1, null),
      new ns.StructField("LastMethodReturnStatus", "i=299", "i=22", -1, null),
    ],
    BinaryId: "i=896",
    JsonId: "i=15381",
}

const node5132 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=897"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "SemanticChangeStructureDataType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("SemanticChangeStructureDataType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=899", "i=38", true),
      new ns.Reference("i=898", "i=38", true),
      new ns.Reference("i=15374", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Affected", "i=17", "i=17", -1, null),
      new ns.StructField("AffectedType", "i=17", "i=17", -1, null),
    ],
    BinaryId: "i=899",
    JsonId: "i=15374",
}

const node5137 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=9"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "UInt64"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("UInt64"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=28", "i=45", false),
      new ns.Reference("i=11737", "i=45", true),
    ],
}

const node5200 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=914"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EventNotificationList"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EventNotificationList"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=945", "i=45", false),
      new ns.Reference("i=916", "i=38", true),
      new ns.Reference("i=915", "i=38", true),
      new ns.Reference("i=15347", "i=38", true),
    ],
    Definition: [
      new ns.StructField("Events", "i=917", "i=22", 1, null),
    ],
    BinaryId: "i=916",
    JsonId: "i=15347",
}

const node5211 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=917"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "EventFieldList"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("EventFieldList"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=919", "i=38", true),
      new ns.Reference("i=918", "i=38", true),
      new ns.Reference("i=15348", "i=38", true),
    ],
    Definition: [
      new ns.StructField("ClientHandle", "i=288", "i=7", -1, null),
      new ns.StructField("EventFields", "nil", "nil", 1, null),
    ],
    BinaryId: "i=919",
    JsonId: "i=15348",
}

const node5226 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=920"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "HistoryEventFieldList"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("HistoryEventFieldList"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=922", "i=38", true),
      new ns.Reference("i=921", "i=38", true),
      new ns.Reference("i=15349", "i=38", true),
    ],
    Definition: [
      new ns.StructField("EventFields", "nil", "nil", 1, null),
    ],
    BinaryId: "i=922",
    JsonId: "i=15349",
}

const node5250 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=938"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "IssuedIdentityToken"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("IssuedIdentityToken"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=316", "i=45", false),
      new ns.Reference("i=940", "i=38", true),
      new ns.Reference("i=939", "i=38", true),
      new ns.Reference("i=15144", "i=38", true),
    ],
    Definition: [
      new ns.StructField("PolicyId", "i=12", "i=12", -1, null),
      new ns.StructField("TokenData", "i=15", "i=15", -1, null),
      new ns.StructField("EncryptionAlgorithm", "i=12", "i=12", -1, null),
    ],
    BinaryId: "i=940",
    JsonId: "i=15144",
}

const node5254 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=94"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "PermissionType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("PermissionType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15030", "i=46", true),
      new ns.Reference("i=7", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Browse", 0),
      new ns.EnumField("ReadRolePermissions", 1),
      new ns.EnumField("WriteAttribute", 2),
      new ns.EnumField("WriteRolePermissions", 3),
      new ns.EnumField("WriteHistorizing", 4),
      new ns.EnumField("Read", 5),
      new ns.EnumField("Write", 6),
      new ns.EnumField("ReadHistory", 7),
      new ns.EnumField("InsertHistory", 8),
      new ns.EnumField("ModifyHistory", 9),
      new ns.EnumField("DeleteHistory", 10),
      new ns.EnumField("ReceiveEvents", 11),
      new ns.EnumField("Call", 12),
      new ns.EnumField("AddReference", 13),
      new ns.EnumField("RemoveReference", 14),
      new ns.EnumField("DeleteNode", 15),
      new ns.EnumField("AddNode", 16),
    ],
}

const node5256 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=945"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "NotificationData"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("NotificationData"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=809", "i=45", true),
      new ns.Reference("i=914", "i=45", true),
      new ns.Reference("i=818", "i=45", true),
      new ns.Reference("i=947", "i=38", true),
      new ns.Reference("i=946", "i=38", true),
      new ns.Reference("i=15344", "i=38", true),
    ],
}

const node5265 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=948"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AggregateConfiguration"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AggregateConfiguration"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=950", "i=38", true),
      new ns.Reference("i=949", "i=38", true),
      new ns.Reference("i=15304", "i=38", true),
    ],
    Definition: [
      new ns.StructField("UseServerCapabilitiesDefaults", "i=1", "i=1", -1, null),
      new ns.StructField("TreatUncertainAsBad", "i=1", "i=1", -1, null),
      new ns.StructField("PercentDataBad", "i=3", "i=3", -1, null),
      new ns.StructField("PercentDataGood", "i=3", "i=3", -1, null),
      new ns.StructField("UseSlopedExtrapolation", "i=1", "i=1", -1, null),
    ],
    BinaryId: "i=950",
    JsonId: "i=15304",
}

const node5268 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=95"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "AccessRestrictionType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("AccessRestrictionType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=15035", "i=46", true),
      new ns.Reference("i=5", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("SigningRequired", 0),
      new ns.EnumField("EncryptionRequired", 1),
      new ns.EnumField("SessionRequired", 2),
      new ns.EnumField("ApplyRestrictionsToBrowse", 3),
    ],
}

const node5270 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=96"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "RolePermissionType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("RolePermissionType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=128", "i=38", true),
      new ns.Reference("i=16126", "i=38", true),
      new ns.Reference("i=15062", "i=38", true),
    ],
    Definition: [
      new ns.StructField("RoleId", "i=17", "i=17", -1, null),
      new ns.StructField("Permissions", "i=94", "i=7", -1, null),
    ],
    BinaryId: "i=128",
    JsonId: "i=15062",
}

const node5272 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=97"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "DataTypeDefinition"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("DataTypeDefinition"))),
      new ns.Attribute(8, new t.Variant(true, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=22", "i=45", false),
      new ns.Reference("i=99", "i=45", true),
      new ns.Reference("i=100", "i=45", true),
      new ns.Reference("i=121", "i=38", true),
      new ns.Reference("i=14797", "i=38", true),
      new ns.Reference("i=15063", "i=38", true),
    ],
}

const node5274 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=98"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StructureType"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StructureType"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=14528", "i=46", true),
      new ns.Reference("i=29", "i=45", false),
    ],
    Definition: [
      new ns.EnumField("Structure", 0),
      new ns.EnumField("StructureWithOptionalFields", 1),
      new ns.EnumField("Union", 2),
      new ns.EnumField("StructureWithSubtypedValues", 3),
      new ns.EnumField("UnionWithSubtypedValues", 4),
    ],
}

const node5275 = {
    Attributes: [
      new ns.Attribute(1, new t.Variant(new t.NodeId("i=99"))),
      new ns.Attribute(2, new t.Variant(64, t.VariantType.UInt32)),
      new ns.Attribute(3, new t.Variant(new t.QualifiedName(0, "StructureDefinition"))),
      new ns.Attribute(4, new t.Variant(new t.LocalizedText("StructureDefinition"))),
      new ns.Attribute(8, new t.Variant(false, t.VariantType.Boolean)),
    ],
    References: [
      new ns.Reference("i=97", "i=45", false),
      new ns.Reference("i=122", "i=38", true),
      new ns.Reference("i=14798", "i=38", true),
      new ns.Reference("i=15066", "i=38", true),
    ],
    Definition: [
      new ns.StructField("DefaultEncodingId", "i=17", "i=17", -1, null),
      new ns.StructField("BaseDataType", "i=17", "i=17", -1, null),
      new ns.StructField("StructureType", "i=98", "i=29", -1, null),
      new ns.StructField("Fields", "i=101", "i=22", 1, null),
    ],
    BinaryId: "i=122",
    JsonId: "i=15066",
}

const ns0: ns.NodeSet = {
    "i=1": node1,
    "i=10": node2,
    "i=100": node3,
    "i=101": node25,
    "i=102": node26,
    "i=11": node37,
    "i=11216": node80,
    "i=11217": node81,
    "i=11226": node80,
    "i=11227": node81,
    "i=11234": node86,
    "i=11293": node107,
    "i=11295": node108,
    "i=11300": node108,
    "i=11737": node247,
    "i=11879": node258,
    "i=11880": node259,
    "i=11889": node258,
    "i=11890": node259,
    "i=11939": node270,
    "i=11941": node272,
    "i=11943": node274,
    "i=11944": node275,
    "i=11957": node274,
    "i=11958": node275,
    "i=12": node286,
    "i=120": node287,
    "i=12077": node307,
    "i=12079": node309,
    "i=12080": node310,
    "i=12089": node309,
    "i=12090": node310,
    "i=121": node5272,
    "i=12171": node386,
    "i=12172": node387,
    "i=12181": node386,
    "i=12182": node387,
    "i=12189": node396,
    "i=12190": node397,
    "i=12191": node398,
    "i=12193": node399,
    "i=12194": node400,
    "i=122": node5275,
    "i=12207": node396,
    "i=12208": node397,
    "i=12209": node398,
    "i=12211": node399,
    "i=12212": node400,
    "i=123": node3,
    "i=124": node977,
    "i=125": node979,
    "i=12552": node430,
    "i=12554": node432,
    "i=126": node1433,
    "i=12680": node432,
    "i=127": node1434,
    "i=12755": node512,
    "i=12756": node513,
    "i=12765": node512,
    "i=12766": node513,
    "i=128": node5270,
    "i=12877": node622,
    "i=12878": node623,
    "i=12879": node624,
    "i=12880": node625,
    "i=12881": node626,
    "i=12890": node633,
    "i=12891": node634,
    "i=12900": node633,
    "i=12901": node634,
    "i=13": node649,
    "i=14": node860,
    "i=14273": node938,
    "i=14323": node938,
    "i=14523": node977,
    "i=14524": node978,
    "i=14525": node979,
    "i=14533": node981,
    "i=14593": node994,
    "i=14647": node1002,
    "i=14744": node1004,
    "i=14839": node978,
    "i=14844": node25,
    "i=14845": node26,
    "i=14846": node981,
    "i=14847": node994,
    "i=14848": node1004,
    "i=15": node1037,
    "i=15005": node1042,
    "i=15006": node1043,
    "i=15007": node1044,
    "i=15008": node1045,
    "i=15031": node1052,
    "i=15033": node1054,
    "i=15041": node981,
    "i=15042": node1507,
    "i=15044": node432,
    "i=15045": node2322,
    "i=15049": node994,
    "i=15050": node977,
    "i=15051": node978,
    "i=15057": node979,
    "i=15058": node1433,
    "i=15059": node1434,
    "i=15060": node938,
    "i=15061": node1004,
    "i=15062": node5270,
    "i=15063": node5272,
    "i=15065": node25,
    "i=15066": node5275,
    "i=15067": node3,
    "i=15068": node4076,
    "i=15069": node258,
    "i=15070": node259,
    "i=15071": node4080,
    "i=15073": node4083,
    "i=15074": node4086,
    "i=15075": node4090,
    "i=15076": node4093,
    "i=15077": node4123,
    "i=15078": node4149,
    "i=15079": node4155,
    "i=15080": node4161,
    "i=15081": node4187,
    "i=15082": node4862,
    "i=15083": node26,
    "i=15084": node512,
    "i=15085": node513,
    "i=15086": node5119,
    "i=15087": node4261,
    "i=15088": node4482,
    "i=15089": node4486,
    "i=15090": node4489,
    "i=15091": node1673,
    "i=15092": node2992,
    "i=15093": node4495,
    "i=15094": node4498,
    "i=15095": node396,
    "i=15096": node397,
    "i=15097": node398,
    "i=15098": node4229,
    "i=15099": node4304,
    "i=15100": node4501,
    "i=15101": node4504,
    "i=15102": node4507,
    "i=15103": node4510,
    "i=15104": node4513,
    "i=15105": node633,
    "i=15106": node634,
    "i=15107": node399,
    "i=15130": node400,
    "i=15131": node4517,
    "i=15132": node4520,
    "i=15133": node4523,
    "i=15134": node4527,
    "i=15135": node4530,
    "i=15136": node4390,
    "i=15137": node4533,
    "i=15138": node4536,
    "i=15139": node4540,
    "i=15140": node4340,
    "i=15141": node4371,
    "i=15142": node4376,
    "i=15143": node4379,
    "i=15144": node5250,
    "i=15145": node4543,
    "i=15146": node4546,
    "i=15147": node4550,
    "i=15148": node4553,
    "i=15149": node4556,
    "i=15150": node4560,
    "i=15151": node4395,
    "i=15152": node4399,
    "i=15153": node4402,
    "i=15157": node4405,
    "i=15158": node4409,
    "i=15159": node4412,
    "i=15160": node4415,
    "i=15161": node4421,
    "i=15162": node4437,
    "i=15163": node2240,
    "i=15164": node2241,
    "i=15165": node4444,
    "i=15166": node4563,
    "i=15167": node4566,
    "i=15168": node4569,
    "i=15169": node4447,
    "i=15170": node4573,
    "i=15171": node4576,
    "i=15172": node4452,
    "i=15173": node4579,
    "i=15174": node4584,
    "i=15175": node4474,
    "i=15176": node4587,
    "i=15177": node4590,
    "i=15179": node4595,
    "i=15180": node4598,
    "i=15182": node4602,
    "i=15183": node4607,
    "i=15184": node4610,
    "i=15185": node4613,
    "i=15186": node4617,
    "i=15187": node4620,
    "i=15188": node4623,
    "i=15189": node4627,
    "i=15190": node4630,
    "i=15191": node4633,
    "i=15192": node4636,
    "i=15193": node4639,
    "i=15194": node4642,
    "i=15195": node4645,
    "i=15196": node4649,
    "i=15197": node4652,
    "i=15198": node4655,
    "i=15199": node4383,
    "i=15200": node4658,
    "i=15201": node4661,
    "i=15202": node4665,
    "i=15203": node4669,
    "i=15204": node4672,
    "i=15205": node4675,
    "i=15206": node4678,
    "i=15207": node4681,
    "i=15208": node4684,
    "i=15209": node4687,
    "i=15210": node4691,
    "i=15211": node4694,
    "i=15228": node4697,
    "i=15236": node4702,
    "i=15244": node4707,
    "i=15252": node4710,
    "i=15254": node4713,
    "i=15255": node4717,
    "i=15256": node4721,
    "i=15257": node4724,
    "i=15258": node4728,
    "i=15259": node4731,
    "i=15260": node4734,
    "i=15261": node4737,
    "i=15262": node4740,
    "i=15263": node4743,
    "i=15264": node4746,
    "i=15269": node4749,
    "i=15270": node4752,
    "i=15271": node80,
    "i=15272": node81,
    "i=15273": node4755,
    "i=15274": node4758,
    "i=15275": node4761,
    "i=15276": node4764,
    "i=15277": node4767,
    "i=15278": node4770,
    "i=15279": node4773,
    "i=15280": node4777,
    "i=15281": node108,
    "i=15282": node4780,
    "i=15283": node4783,
    "i=15284": node4786,
    "i=15285": node4790,
    "i=15286": node4793,
    "i=15287": node4796,
    "i=15288": node4800,
    "i=15289": node4803,
    "i=15290": node4806,
    "i=15291": node4809,
    "i=15292": node4812,
    "i=15293": node4818,
    "i=15294": node4822,
    "i=15295": node4825,
    "i=15304": node5265,
    "i=15312": node4828,
    "i=15313": node4831,
    "i=15314": node4834,
    "i=15315": node4837,
    "i=15320": node4840,
    "i=15321": node4843,
    "i=15322": node4846,
    "i=15323": node4849,
    "i=15324": node4853,
    "i=15325": node4856,
    "i=15326": node4859,
    "i=15327": node4874,
    "i=15328": node4884,
    "i=15329": node4893,
    "i=15331": node4905,
    "i=15332": node4909,
    "i=15333": node4915,
    "i=15335": node4919,
    "i=15336": node4923,
    "i=15337": node4926,
    "i=15338": node4929,
    "i=15339": node4932,
    "i=15340": node4939,
    "i=15341": node4945,
    "i=15342": node4950,
    "i=15343": node4954,
    "i=15344": node5256,
    "i=15345": node4963,
    "i=15346": node4957,
    "i=15347": node5200,
    "i=15348": node5211,
    "i=15349": node5226,
    "i=15350": node4967,
    "i=15351": node4971,
    "i=15352": node4984,
    "i=15353": node4993,
    "i=15354": node5001,
    "i=15355": node5013,
    "i=15356": node5017,
    "i=15357": node5024,
    "i=15358": node5029,
    "i=15359": node5032,
    "i=15360": node5035,
    "i=15361": node4386,
    "i=15362": node5041,
    "i=15363": node274,
    "i=15364": node275,
    "i=15365": node5044,
    "i=15366": node5054,
    "i=15367": node5058,
    "i=15368": node5062,
    "i=15369": node5065,
    "i=15370": node5071,
    "i=15371": node4190,
    "i=15372": node5075,
    "i=15373": node5078,
    "i=15374": node5132,
    "i=15375": node5083,
    "i=15376": node5095,
    "i=15377": node386,
    "i=15378": node387,
    "i=15379": node309,
    "i=15380": node310,
    "i=15381": node5127,
    "i=15382": node5118,
    "i=15406": node1377,
    "i=15421": node1042,
    "i=15422": node1043,
    "i=15479": node1044,
    "i=15480": node1426,
    "i=15487": node1433,
    "i=15488": node1434,
    "i=15502": node1443,
    "i=15510": node1444,
    "i=15520": node1446,
    "i=15528": node1450,
    "i=15530": node1452,
    "i=15532": node1454,
    "i=15534": node1456,
    "i=15578": node1467,
    "i=15580": node1469,
    "i=15581": node1470,
    "i=15582": node1471,
    "i=15583": node1472,
    "i=15597": node1480,
    "i=15598": node1481,
    "i=15605": node1484,
    "i=15609": node1488,
    "i=15611": node1489,
    "i=15616": node1490,
    "i=15617": node1491,
    "i=15618": node1492,
    "i=15621": node1494,
    "i=15622": node1495,
    "i=15623": node1496,
    "i=15628": node1501,
    "i=15629": node1502,
    "i=15630": node1503,
    "i=15631": node1504,
    "i=15632": node1505,
    "i=15634": node1507,
    "i=15635": node1508,
    "i=15642": node1511,
    "i=15645": node1514,
    "i=15646": node1515,
    "i=15652": node1521,
    "i=15653": node1522,
    "i=15654": node1523,
    "i=15657": node1526,
    "i=15658": node1527,
    "i=15664": node1533,
    "i=15665": node1534,
    "i=15667": node1535,
    "i=15669": node1537,
    "i=15670": node1538,
    "i=15671": node1450,
    "i=15676": node1456,
    "i=15677": node1467,
    "i=15678": node1469,
    "i=15679": node1470,
    "i=15681": node1471,
    "i=15682": node1480,
    "i=15683": node1481,
    "i=15688": node1484,
    "i=15689": node1488,
    "i=15691": node1489,
    "i=15693": node1490,
    "i=15694": node1491,
    "i=15695": node1492,
    "i=15700": node1042,
    "i=15701": node1494,
    "i=15702": node1495,
    "i=15703": node1496,
    "i=15705": node1501,
    "i=15706": node1502,
    "i=15707": node1503,
    "i=15712": node1504,
    "i=15713": node1508,
    "i=15714": node1043,
    "i=15715": node1514,
    "i=15717": node1521,
    "i=15718": node1522,
    "i=15719": node1526,
    "i=15724": node1533,
    "i=15725": node1534,
    "i=15726": node1044,
    "i=15727": node1535,
    "i=15729": node1537,
    "i=15733": node1538,
    "i=15736": node1507,
    "i=15874": node1664,
    "i=15901": node1673,
    "i=15903": node1673,
    "i=15904": node1676,
    "i=16": node1730,
    "i=16150": node1450,
    "i=16151": node1456,
    "i=16152": node1467,
    "i=16153": node1469,
    "i=16154": node1470,
    "i=16155": node1471,
    "i=16156": node1480,
    "i=16157": node1481,
    "i=16158": node1484,
    "i=16159": node1488,
    "i=16161": node1489,
    "i=16280": node1490,
    "i=16281": node1491,
    "i=16282": node1492,
    "i=16284": node1494,
    "i=16285": node1495,
    "i=16286": node1496,
    "i=16287": node1501,
    "i=16288": node1502,
    "i=16307": node1923,
    "i=16308": node1503,
    "i=16310": node1504,
    "i=16311": node1508,
    "i=16313": node1929,
    "i=16323": node1514,
    "i=16391": node1521,
    "i=16392": node1522,
    "i=16393": node1526,
    "i=16394": node1533,
    "i=16404": node1534,
    "i=16524": node1535,
    "i=16525": node1537,
    "i=16526": node1538,
    "i=17": node2048,
    "i=17467": node2165,
    "i=17468": node2165,
    "i=17476": node2165,
    "i=17537": node1929,
    "i=17545": node2203,
    "i=17546": node2204,
    "i=17547": node1929,
    "i=17548": node2206,
    "i=17549": node2206,
    "i=17557": node2206,
    "i=17588": node2226,
    "i=17606": node2240,
    "i=17607": node2241,
    "i=17610": node2240,
    "i=17611": node2241,
    "i=17861": node2322,
    "i=17863": node2322,
    "i=18": node2359,
    "i=18806": node2478,
    "i=18807": node2479,
    "i=18808": node2480,
    "i=18809": node2481,
    "i=18810": node2482,
    "i=18811": node2483,
    "i=18812": node2484,
    "i=18813": node2485,
    "i=18814": node2486,
    "i=18815": node2478,
    "i=18816": node2479,
    "i=18817": node2480,
    "i=18818": node2481,
    "i=18819": node2482,
    "i=18820": node2483,
    "i=18821": node2484,
    "i=18822": node2485,
    "i=18823": node2486,
    "i=19": node2518,
    "i=19064": node2478,
    "i=19065": node2479,
    "i=19066": node2480,
    "i=19067": node2481,
    "i=19068": node2482,
    "i=19069": node2483,
    "i=19070": node2484,
    "i=19071": node2485,
    "i=19072": node2486,
    "i=19723": node2749,
    "i=19730": node2756,
    "i=2": node2816,
    "i=20": node2817,
    "i=2000": node2818,
    "i=2001": node2819,
    "i=2002": node2826,
    "i=2003": node2835,
    "i=20408": node2936,
    "i=20998": node2991,
    "i=20999": node2992,
    "i=21": node2993,
    "i=21001": node2992,
    "i=21150": node1426,
    "i=21151": node1443,
    "i=21152": node1444,
    "i=21153": node1446,
    "i=21154": node1452,
    "i=21155": node1454,
    "i=21198": node1426,
    "i=21199": node1443,
    "i=21200": node1444,
    "i=21201": node1446,
    "i=21202": node1452,
    "i=21203": node1454,
    "i=22": node3199,
    "i=23": node3284,
    "i=23468": node3323,
    "i=23497": node3340,
    "i=23498": node3341,
    "i=23499": node3323,
    "i=23500": node3340,
    "i=23507": node3341,
    "i=23511": node3323,
    "i=23512": node3340,
    "i=23528": node3341,
    "i=23599": node3384,
    "i=23600": node3386,
    "i=23601": node3387,
    "i=23602": node3388,
    "i=23603": node3389,
    "i=23604": node3390,
    "i=23605": node3391,
    "i=23608": node3393,
    "i=23609": node3394,
    "i=23612": node3396,
    "i=23613": node3397,
    "i=23614": node3398,
    "i=23751": node3429,
    "i=23851": node3384,
    "i=23852": node3386,
    "i=23853": node3387,
    "i=23854": node3388,
    "i=23855": node3389,
    "i=23856": node3390,
    "i=23857": node3391,
    "i=23860": node3393,
    "i=23861": node3394,
    "i=23864": node3396,
    "i=23865": node3397,
    "i=23866": node3398,
    "i=23987": node3384,
    "i=23988": node3386,
    "i=23989": node3387,
    "i=23990": node3388,
    "i=23991": node3389,
    "i=23992": node3390,
    "i=23993": node3391,
    "i=23996": node3393,
    "i=23997": node3394,
    "i=24": node3562,
    "i=24000": node3396,
    "i=24001": node3397,
    "i=24002": node3398,
    "i=24033": node3577,
    "i=24034": node3577,
    "i=24042": node3577,
    "i=24105": node3606,
    "i=24106": node3607,
    "i=24107": node3608,
    "i=24108": node3606,
    "i=24109": node3607,
    "i=24110": node3608,
    "i=24132": node3606,
    "i=24133": node3607,
    "i=24134": node3608,
    "i=24210": node3696,
    "i=24212": node3697,
    "i=24214": node3698,
    "i=24216": node3699,
    "i=24218": node3700,
    "i=24220": node3702,
    "i=24222": node3703,
    "i=24224": node3704,
    "i=24263": node3727,
    "i=24277": node3742,
    "i=24279": node3744,
    "i=24281": node3747,
    "i=24292": node3747,
    "i=24300": node3747,
    "i=25": node3795,
    "i=25220": node3800,
    "i=25239": node3800,
    "i=25247": node3800,
    "i=25269": node3835,
    "i=25270": node3836,
    "i=25517": node3951,
    "i=25519": node3953,
    "i=25520": node3954,
    "i=25529": node3835,
    "i=25530": node3836,
    "i=25531": node3953,
    "i=25532": node3954,
    "i=25561": node3835,
    "i=25562": node3836,
    "i=25563": node3953,
    "i=25564": node3954,
    "i=256": node4015,
    "i=257": node4075,
    "i=258": node4076,
    "i=26": node4078,
    "i=260": node4076,
    "i=261": node4080,
    "i=263": node4080,
    "i=264": node4083,
    "i=266": node4083,
    "i=267": node4086,
    "i=269": node4086,
    "i=27": node4089,
    "i=270": node4090,
    "i=272": node4090,
    "i=273": node4093,
    "i=275": node4093,
    "i=276": node4123,
    "i=278": node4123,
    "i=279": node4149,
    "i=28": node4151,
    "i=281": node4149,
    "i=282": node4155,
    "i=284": node4155,
    "i=285": node4161,
    "i=287": node4161,
    "i=288": node4164,
    "i=289": node4166,
    "i=29": node4167,
    "i=290": node4168,
    "i=291": node4169,
    "i=294": node4177,
    "i=295": node4185,
    "i=296": node4187,
    "i=298": node4187,
    "i=299": node4190,
    "i=3": node4199,
    "i=30": node4200,
    "i=301": node4190,
    "i=302": node4211,
    "i=303": node4222,
    "i=304": node4229,
    "i=306": node4229,
    "i=307": node4250,
    "i=308": node4261,
    "i=310": node4261,
    "i=311": node4293,
    "i=312": node4304,
    "i=314": node4304,
    "i=315": node4330,
    "i=316": node4340,
    "i=318": node4340,
    "i=319": node4371,
    "i=321": node4371,
    "i=322": node4376,
    "i=324": node4376,
    "i=325": node4379,
    "i=327": node4379,
    "i=331": node4383,
    "i=333": node4383,
    "i=338": node4386,
    "i=340": node4386,
    "i=344": node4390,
    "i=346": node4390,
    "i=347": node4393,
    "i=348": node4394,
    "i=349": node4395,
    "i=351": node4395,
    "i=352": node4399,
    "i=354": node4399,
    "i=355": node4402,
    "i=357": node4402,
    "i=358": node4405,
    "i=360": node4405,
    "i=361": node4409,
    "i=363": node4409,
    "i=364": node4412,
    "i=366": node4412,
    "i=367": node4415,
    "i=369": node4415,
    "i=370": node4421,
    "i=372": node4421,
    "i=373": node4437,
    "i=375": node4437,
    "i=376": node4444,
    "i=378": node4444,
    "i=379": node4447,
    "i=381": node4447,
    "i=382": node4452,
    "i=384": node4452,
    "i=385": node4474,
    "i=387": node4474,
    "i=388": node4481,
    "i=389": node4482,
    "i=391": node4482,
    "i=392": node4486,
    "i=394": node4486,
    "i=395": node4489,
    "i=397": node4489,
    "i=4": node4492,
    "i=420": node4495,
    "i=422": node4495,
    "i=423": node4498,
    "i=425": node4498,
    "i=426": node4501,
    "i=428": node4501,
    "i=429": node4504,
    "i=431": node4504,
    "i=432": node4507,
    "i=434": node4507,
    "i=435": node4510,
    "i=437": node4510,
    "i=438": node4513,
    "i=440": node4513,
    "i=441": node4517,
    "i=443": node4517,
    "i=444": node4520,
    "i=446": node4520,
    "i=447": node4523,
    "i=449": node4523,
    "i=450": node4527,
    "i=452": node4527,
    "i=453": node4530,
    "i=455": node4530,
    "i=456": node4533,
    "i=458": node4533,
    "i=459": node4536,
    "i=461": node4536,
    "i=462": node4540,
    "i=464": node4540,
    "i=465": node4543,
    "i=467": node4543,
    "i=468": node4546,
    "i=470": node4546,
    "i=471": node4550,
    "i=473": node4550,
    "i=474": node4553,
    "i=476": node4553,
    "i=477": node4556,
    "i=479": node4556,
    "i=480": node4560,
    "i=482": node4560,
    "i=483": node4563,
    "i=485": node4563,
    "i=486": node4566,
    "i=488": node4566,
    "i=489": node4569,
    "i=491": node4569,
    "i=492": node4573,
    "i=494": node4573,
    "i=495": node4576,
    "i=497": node4576,
    "i=498": node4579,
    "i=5": node4581,
    "i=50": node4582,
    "i=500": node4579,
    "i=501": node4584,
    "i=503": node4584,
    "i=504": node4587,
    "i=506": node4587,
    "i=507": node4590,
    "i=509": node4590,
    "i=510": node4594,
    "i=511": node4595,
    "i=513": node4595,
    "i=514": node4598,
    "i=516": node4598,
    "i=517": node4601,
    "i=518": node4602,
    "i=520": node4602,
    "i=521": node4606,
    "i=522": node4607,
    "i=524": node4607,
    "i=525": node4610,
    "i=527": node4610,
    "i=528": node4613,
    "i=530": node4613,
    "i=531": node4617,
    "i=533": node4617,
    "i=534": node4620,
    "i=536": node4620,
    "i=537": node4623,
    "i=539": node4623,
    "i=540": node4627,
    "i=542": node4627,
    "i=543": node4630,
    "i=545": node4630,
    "i=546": node4633,
    "i=548": node4633,
    "i=549": node4636,
    "i=551": node4636,
    "i=552": node4639,
    "i=554": node4639,
    "i=555": node4642,
    "i=557": node4642,
    "i=558": node4645,
    "i=560": node4645,
    "i=561": node4649,
    "i=563": node4649,
    "i=564": node4652,
    "i=566": node4652,
    "i=567": node4655,
    "i=569": node4655,
    "i=570": node4658,
    "i=572": node4658,
    "i=573": node4661,
    "i=575": node4661,
    "i=576": node4664,
    "i=577": node4665,
    "i=579": node4665,
    "i=580": node4669,
    "i=582": node4669,
    "i=583": node4672,
    "i=585": node4672,
    "i=586": node4675,
    "i=588": node4675,
    "i=589": node4678,
    "i=591": node4678,
    "i=592": node4681,
    "i=594": node4681,
    "i=595": node4684,
    "i=597": node4684,
    "i=598": node4687,
    "i=6": node4689,
    "i=600": node4687,
    "i=601": node4691,
    "i=603": node4691,
    "i=604": node4694,
    "i=606": node4694,
    "i=607": node4697,
    "i=609": node4697,
    "i=610": node4702,
    "i=612": node4702,
    "i=613": node4707,
    "i=615": node4707,
    "i=616": node4710,
    "i=618": node4710,
    "i=619": node4713,
    "i=621": node4713,
    "i=622": node4717,
    "i=624": node4717,
    "i=625": node4720,
    "i=626": node4721,
    "i=628": node4721,
    "i=629": node4724,
    "i=631": node4724,
    "i=632": node4728,
    "i=634": node4728,
    "i=635": node4731,
    "i=637": node4731,
    "i=638": node4734,
    "i=640": node4734,
    "i=641": node4737,
    "i=643": node4737,
    "i=644": node4740,
    "i=646": node4740,
    "i=647": node4743,
    "i=649": node4743,
    "i=650": node4746,
    "i=652": node4746,
    "i=653": node4749,
    "i=655": node4749,
    "i=656": node4752,
    "i=658": node4752,
    "i=659": node4755,
    "i=661": node4755,
    "i=662": node4758,
    "i=664": node4758,
    "i=665": node4761,
    "i=667": node4761,
    "i=668": node4764,
    "i=670": node4764,
    "i=671": node4767,
    "i=673": node4767,
    "i=674": node4770,
    "i=676": node4770,
    "i=677": node4773,
    "i=679": node4773,
    "i=680": node4777,
    "i=682": node4777,
    "i=683": node4780,
    "i=685": node4780,
    "i=686": node4783,
    "i=688": node4783,
    "i=689": node4786,
    "i=691": node4786,
    "i=692": node4790,
    "i=694": node4790,
    "i=695": node4793,
    "i=697": node4793,
    "i=698": node4796,
    "i=7": node4798,
    "i=700": node4796,
    "i=701": node4800,
    "i=703": node4800,
    "i=704": node4803,
    "i=706": node4803,
    "i=707": node4806,
    "i=709": node4806,
    "i=710": node4809,
    "i=712": node4809,
    "i=713": node4812,
    "i=715": node4812,
    "i=716": node4815,
    "i=717": node4816,
    "i=718": node4817,
    "i=719": node4818,
    "i=721": node4818,
    "i=722": node4822,
    "i=724": node4822,
    "i=725": node4825,
    "i=727": node4825,
    "i=728": node4828,
    "i=730": node4828,
    "i=731": node4831,
    "i=733": node4831,
    "i=734": node4834,
    "i=736": node4834,
    "i=737": node4837,
    "i=739": node4837,
    "i=740": node4840,
    "i=742": node4840,
    "i=743": node4843,
    "i=745": node4843,
    "i=746": node4846,
    "i=748": node4846,
    "i=749": node4849,
    "i=751": node4849,
    "i=752": node4853,
    "i=754": node4853,
    "i=755": node4856,
    "i=757": node4856,
    "i=758": node4859,
    "i=7594": node4862,
    "i=760": node4859,
    "i=761": node4874,
    "i=763": node4874,
    "i=764": node4884,
    "i=766": node4884,
    "i=767": node4893,
    "i=769": node4893,
    "i=770": node4905,
    "i=772": node4905,
    "i=773": node4909,
    "i=775": node4909,
    "i=776": node4915,
    "i=778": node4915,
    "i=779": node4919,
    "i=781": node4919,
    "i=782": node4923,
    "i=784": node4923,
    "i=785": node4926,
    "i=787": node4926,
    "i=788": node4929,
    "i=790": node4929,
    "i=791": node4932,
    "i=793": node4932,
    "i=794": node4939,
    "i=796": node4939,
    "i=797": node4945,
    "i=799": node4945,
    "i=8": node4948,
    "i=800": node4950,
    "i=802": node4950,
    "i=803": node4954,
    "i=805": node4954,
    "i=806": node4957,
    "i=808": node4957,
    "i=809": node4963,
    "i=811": node4963,
    "i=818": node4967,
    "i=820": node4967,
    "i=821": node4971,
    "i=823": node4971,
    "i=824": node4984,
    "i=8251": node4862,
    "i=826": node4984,
    "i=827": node4993,
    "i=829": node4993,
    "i=830": node5001,
    "i=832": node5001,
    "i=833": node5013,
    "i=835": node5013,
    "i=836": node5017,
    "i=838": node5017,
    "i=839": node5024,
    "i=841": node5024,
    "i=842": node5029,
    "i=844": node5029,
    "i=845": node5032,
    "i=847": node5032,
    "i=848": node5035,
    "i=850": node5035,
    "i=851": node5039,
    "i=852": node5040,
    "i=853": node5041,
    "i=855": node5041,
    "i=856": node5044,
    "i=858": node5044,
    "i=859": node5054,
    "i=861": node5054,
    "i=862": node5058,
    "i=864": node5058,
    "i=865": node5062,
    "i=867": node5062,
    "i=868": node5065,
    "i=870": node5065,
    "i=871": node5071,
    "i=873": node5071,
    "i=874": node5075,
    "i=876": node5075,
    "i=877": node5078,
    "i=879": node5078,
    "i=884": node5083,
    "i=886": node5083,
    "i=887": node5095,
    "i=889": node5095,
    "i=890": node5115,
    "i=891": node5118,
    "i=8912": node5119,
    "i=8917": node5119,
    "i=893": node5118,
    "i=894": node5127,
    "i=896": node5127,
    "i=897": node5132,
    "i=899": node5132,
    "i=9": node5137,
    "i=914": node5200,
    "i=916": node5200,
    "i=917": node5211,
    "i=919": node5211,
    "i=920": node5226,
    "i=922": node5226,
    "i=938": node5250,
    "i=94": node5254,
    "i=940": node5250,
    "i=945": node5256,
    "i=947": node5256,
    "i=948": node5265,
    "i=95": node5268,
    "i=950": node5265,
    "i=96": node5270,
    "i=97": node5272,
    "i=98": node5274,
    "i=99": node5275,
}
export default ns0
