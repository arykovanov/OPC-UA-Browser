import { DataValue, Guid, LocalizedText, OpcuaError, QualifiedName, NodeId, Variant, VariantType, XmlElement, ExtensionObject, DiagnosticInfo, VariantTypes, VariantScalarTypes } from './types'
import { NodeIdType } from './enums'
import { StatusCode } from './status_codes'

import * as ns from "./nodeset"

import ns0 from "./ns0"

const BadEncodingError = StatusCode.BadEncodingError

const NamespaceUriFlag = 0x80
const ServerIndexFlag = 0x40

function timetToFiletime (ms: number): bigint {
  if (ms === 0) {
    return 0n
  }

  if (ms > 0 && ms < 1) {
    ms = 0
  }

  const ns = (BigInt(ms) * 10000n) + 116444736000000000n // windowsEpochMs
  return ns
}

class BinaryEncoder {
  private readonly textEncoder = new TextEncoder()
  private readonly view: DataView
  private readonly arr: Uint8Array
  private readonly buffer: ArrayBuffer
  private len: number = 0
  private bits_count: number = 0
  private bits: number = 0
  public ns0: ns.NodeSet = ns0

  constructor (buffer: ArrayBuffer) {
    this.buffer = buffer
    this.view = new DataView(buffer)
    this.arr = new Uint8Array(buffer)
  }

  get data (): Uint8Array {
    return this.arr.subarray(0, this.len)
  }

  bit (num: number | boolean, size: number = 1): void {
    if (typeof num === 'boolean') {
      num = num ? 1 : 0
    } else if (typeof num !== 'number') {
      throw new OpcuaError(BadEncodingError)
    }

    if (size === null || size === 1) {
      size = 1
      num = num !== 0 ? 1 : 0
    }

    if (size < 1) {
      throw new OpcuaError(BadEncodingError)
    }

    for (let i = 0; i < size; i++) {
      if (this.bits_count < 0 || this.bits_count > 8) {
        throw new Error(`Internal error: invalid number of bits: ${this.bits_count}`)
      }

      this.bits |= (num & 1) << this.bits_count
      this.bits_count++

      if (this.bits_count === 8) {
        this.view.setUint8(this.len, this.bits)
        this.len++
        this.bits_count = 0
        this.bits = 0
      }

      num >>= 1
    }
  }

  int8 (val: number): void {
    if (this.bits_count !== 0) {
      throw new OpcuaError(BadEncodingError)
    }

    if (val < -128 || val > 127) {
      throw new OpcuaError(BadEncodingError)
    }

    this.view.setInt8(this.len, val)
    this.len++
  }

  sbyte = this.int8

  uint8 (val: number): void {
    if (this.bits_count !== 0) {
      throw new OpcuaError(BadEncodingError)
    }

    if (val < 0 || val > 255) {
      throw new OpcuaError(BadEncodingError)
    }

    this.view.setUint8(this.len, val)
    this.len++
  }

  byte = this.uint8

  char (val: string): void {
    if (this.bits_count !== 0) {
      throw new OpcuaError(BadEncodingError)
    }

    if (typeof val !== 'string' || val.length !== 1) {
      throw new OpcuaError(BadEncodingError)
    }

    this.uint8(val.charCodeAt(0))
  }

  int16 (val: number): void {
    if (val < -32768 || val > 32767) {
      throw new OpcuaError(BadEncodingError)
    }

    this.view.setInt16(this.len, val, true)
    this.len += 2
  }

  uint16 (val: number): void {
    if (val < 0 || val > 65535) {
      throw new OpcuaError(BadEncodingError)
    }

    this.view.setUint16(this.len, val, true)
    this.len += 2
  }

  int32 (val: number): void {
    if (val < -2147483648 || val > 2147483647) {
      throw new OpcuaError(BadEncodingError)
    }

    this.view.setInt32(this.len, val, true)
    this.len += 4
  }

  uint32 (val: number): void {
    if (val < 0 || val > 4294967295) {
      throw new OpcuaError(BadEncodingError)
    }

    this.view.setUint32(this.len, val, true)
    this.len += 4
  }

  statusCode(statusCode: OpcuaError | number | null): void {
    if (statusCode === null) {
      this.uint32(0)
    } else if (typeof statusCode === "number") {
      this.uint32(statusCode)
    } else if (statusCode instanceof OpcuaError) {
      this.uint32(statusCode.Code)
    } else {
      throw new OpcuaError(BadEncodingError, "Invalid status code type")
    }
  }

  int64 (val: number | bigint): void {
    if (val < Number.MIN_SAFE_INTEGER || val > Number.MAX_SAFE_INTEGER) {
      throw new OpcuaError(BadEncodingError)
    }
    this.view.setBigInt64(this.len, BigInt(val), true)
    this.len += 8
  }

  uint64 (val: number | bigint): void {
    this.view.setBigUint64(this.len, BigInt(val), true)
    this.len += 8
  }

  float (val: number): void {
    this.view.setFloat32(this.len, val, true)
    this.len += 4
  }

  double (val: number): void {
    this.view.setFloat64(this.len, val, true)
    this.len += 8
  }

  boolean (v: boolean | number): void {
    if (typeof v === 'number') {
      this.uint8(v !== 0 ? 1 : 0)
    } else if (typeof v === 'boolean') {
      this.uint8(v ? 1 : 0)
    } else {
      throw new Error('invalid boolean type')
    }
  }

  dateTime(ms: number | Date): void {
    if (ms instanceof Date) {
      ms = ms.getTime()
    }
    this.view.setBigUint64(this.len, timetToFiletime(ms), true)
    this.len += 8
  }

  array (val: string | Uint8Array): void {
    if (typeof val === 'string') {
      const result = this.textEncoder.encodeInto(val, this.arr.subarray(this.len))
      this.len += result.written ?? 0
    } else {
      this.arr.set(val, this.len)
      this.len += val.byteLength
    }
  }

  str (val: string): void {
    const utf8 = this.textEncoder.encode(val)
    if (this.len + utf8.length > this.buffer.byteLength) {
      throw new OpcuaError(BadEncodingError)
    }

    this.arr.set(utf8, this.len)
    this.len += utf8.length
  }

  byteString (val: string | number[] | Uint8Array | undefined | null): void {
    if (val === null || val === undefined) {
      this.uint32(0xFFFFFFFF)
      return
    }
    if (val.length === 0) {
      this.uint32(0)
      return
    }

    let utf8
    if (typeof val === 'string') {
      utf8 = this.textEncoder.encode(val)
    } else if (val instanceof ArrayBuffer) {
      utf8 = new Uint8Array(val)
    } else if (val instanceof Array) {
      utf8 = Uint8Array.from(val)
    } else if (val instanceof Uint8Array) {
      utf8 = val
    } else {
      throw new Error('invalid type')
    }

    this.uint32(utf8.length)
    this.array(utf8)
  }

  charArray (val: string | undefined | null = undefined): void {
    if (typeof val !== 'string' && val !== null && val !== undefined) {
      throw new OpcuaError(BadEncodingError)
    }

    this.byteString(val)
  }

  string = this.charArray

  guid (v: Guid): void {
    // const guidString = `${data1.toString(16).padStart(8, '0')}-${data2.toString(16).padStart(4, '0')}-${data3.toString(16).padStart(4, '0')}-${data4.toString(16).padStart(2, '0')}${data5.toString(16).padStart(2, '0')}-${data6.toString(16).padStart(2, '0')}${data7.toString(16).padStart(2, '0')}${data8.toString(16).padStart(2, '0')}${data9.toString(16).padStart(2, '0')}${data10.toString(16).padStart(2, '0')}${data11.toString(16).padStart(2, '0')}`
    const guidString = v.toString()
    //
    // '00000001 0,1,2,3,4,5,6,7
    // - 8
    // 0002 9,10,11,12
    // - 13
    // 0003 14,15,16,17
    // - 18
    // 0405 19,20
    // - 21
    // 060708090a0b 22,23,24,25,26,27
    const data1 = parseInt(guidString.slice(0,8), 16)
    const data2 = parseInt(guidString.slice(9,13), 16)
    const data3 = parseInt(guidString.slice(14,18), 16)
    const data4 = parseInt(guidString.slice(19,21), 16)
    const data5 = parseInt(guidString.slice(22, 24), 16)
    const data6 = parseInt(guidString.slice(24, 26), 16)
    const data7 = parseInt(guidString.slice(26, 28), 16)
    const data8 = parseInt(guidString.slice(28, 30), 16)
    const data9 = parseInt(guidString.slice(30, 32), 16)
    const data10 = parseInt(guidString.slice(32, 34), 16)
    const data11 = parseInt(guidString.slice(34, 36), 16)

    this.uint32(data1)
    this.uint16(data2)
    this.uint16(data3)
    this.byte(data4)
    this.byte(data5)
    this.byte(data6)
    this.byte(data7)
    this.byte(data8)
    this.byte(data9)
    this.byte(data10)
    this.byte(data11)
  }

  qualifiedName (v: QualifiedName): void {
    this.uint16(v.Ns)
    this.charArray(v.Name)
  }

  localizedText (v: LocalizedText): void {
    this.bit(v.Locale != null ? 1 : 0, 1)
    this.bit(v.Text != null ? 1 : 0, 1)
    this.bit(0, 6)
    if (v.Locale != null) {
      this.charArray(v.Locale)
    }
    if (v.Text != null) {
      this.charArray(v.Text)
    }
  }

  xmlElement (v: XmlElement): void {
    if (v.Value == null) {
      this.int32(-1)
      return
    }

    this.int32(v.Value.length)
    this.str(v.Value)
  }

  dataValue (v: DataValue): void {
    this.bit(v.Value != null ? 1 : 0, 1)
    this.bit(v.StatusCode != null ? 1 : 0, 1)
    this.bit(v.SourceTimestamp != null ? 1 : 0, 1)
    this.bit(v.ServerTimestamp != null ? 1 : 0, 1)
    this.bit(v.SourcePicoseconds != null ? 1 : 0, 1)
    this.bit(v.ServerPicoseconds != null ? 1 : 0, 1)
    this.bit(0, 2)
    if (v.Value != null) {
      this.variant(v)
    }
    if (v.StatusCode != null) {
      this.statusCode(v.StatusCode)
    }
    if (v.SourceTimestamp != null) {
      this.dateTime(v.SourceTimestamp)
    }
    if (v.ServerTimestamp != null) {
      this.dateTime(v.ServerTimestamp)
    }
    if (v.SourcePicoseconds != null) {
      this.uint16(v.SourcePicoseconds)
    }
    if (v.ServerPicoseconds != null) {
      this.uint16(v.ServerPicoseconds)
    }
  }

  diagnosticInfo (v: DiagnosticInfo): void {
    this.bit(v.SymbolicId != null ? 1 : 0, 1)
    this.bit(v.NamespaceUri != null ? 1 : 0, 1)
    this.bit(v.LocalizedText != null ? 1 : 0, 1)
    this.bit(v.Locale != null ? 1 : 0, 1)
    this.bit(v.AdditionalInfo != null ? 1 : 0, 1)
    this.bit(v.InnerStatusCode != null ? 1 : 0, 1)
    this.bit(v.InnerDiagnosticInfo != null ? 1 : 0, 1)
    this.bit(0, 1)
    if (v.SymbolicId != null) {
      this.int32(v.SymbolicId)
    }
    if (v.NamespaceUri != null) {
      this.int32(v.NamespaceUri)
    }
    if (v.Locale != null) {
      this.int32(v.Locale)
    }
    if (v.LocalizedText != null) {
      this.int32(v.LocalizedText)
    }
    if (v.AdditionalInfo != null) {
      this.charArray(v.AdditionalInfo)
    }
    if (v.InnerStatusCode != null) {
      this.statusCode(v.InnerStatusCode)
    }
    if (v.InnerDiagnosticInfo != null) {
      this.diagnosticInfo(v.InnerDiagnosticInfo)
    }
  }

  nodeId (v: NodeId | string): void {
    let ns = 0 // namespace index
    let nsUri // namespace uri
    let si // server index

    let idType // mask of NodeId Type with NodeIdType | HasServiceIndex | HasNamespaceUri

    if (typeof v === 'string') {
      v = new NodeId(v)
    } else if (!(v instanceof NodeId)) {
      throw new OpcuaError(BadEncodingError)
    }

    const id = v.Id
    if (typeof (v.Ns) === 'number') {
      ns = v.Ns
    } else if (typeof (v.Ns) === 'string') {
      nsUri = v.Ns
    }

    if (typeof (v.Srv) === 'number') {
      si = v.Srv
    }

    if (typeof (id) === 'number') {
      if (id <= 0xFF && ns === 0 && nsUri === undefined) {
        idType = NodeIdType.TwoByte
      } else if (id <= 0xFFFF) {
        idType = NodeIdType.FourByte
      } else if (id <= 0xFFFFFFFF) {
        idType = NodeIdType.Numeric
      } else {
        throw new OpcuaError(BadEncodingError)
      }
    } else if (typeof (id) === 'string') {
      idType = NodeIdType.String
    } else if (id instanceof Guid) {
      idType = NodeIdType.Guid
    } else if (id instanceof Uint8Array) {
      idType = NodeIdType.ByteString
    } else {
      throw new OpcuaError(BadEncodingError)
    }

    // Node ID fields mask
    let fieldMask = idType
    if (typeof (si) === 'number')
      fieldMask = fieldMask | ServerIndexFlag
    if (nsUri !== undefined)
      fieldMask = fieldMask | NamespaceUriFlag
    this.uint8(fieldMask)

    // Namespace index and Node ID value
    switch (idType) {
      case NodeIdType.TwoByte:
        this.uint8(id as number)
        break
      case NodeIdType.FourByte:
        this.uint8(ns)
        this.uint16(id as number)
        break
      case NodeIdType.Numeric:
        this.uint16(ns)
        this.uint32(id as number)
        break
      case NodeIdType.String:
        this.uint16(ns)
        this.string(id as string)
        break
      case NodeIdType.Guid:
        this.uint16(ns)
        this.guid(id as Guid)
        break
      case NodeIdType.ByteString:
        this.uint16(ns)
        this.byteString(id as string | Uint8Array)
        break
      default:
        throw new OpcuaError(BadEncodingError)
    }

    // namespace Uri
    if (nsUri !== undefined) {
      this.string(nsUri)
    }

    // Server Index
    if (typeof (si) === 'number') {
      this.uint32(si)
    }
  }

  expandedNodeId = this.nodeId

  private encodeVariantValue(v: VariantScalarTypes, type: VariantType): void {
    switch (type) {
      case VariantType.Null:
        break
      case VariantType.Boolean:
        this.boolean(v as boolean)
        break
      case VariantType.SByte:
        this.uint8(v as number)
        break
      case VariantType.Byte:
        this.int8(v as number)
        break
      case VariantType.Int16:
        this.int16(v as number)
        break
      case VariantType.UInt16:
        this.uint16(v as number)
        break

      case VariantType.Int32:
        this.int32(v as number)
        break

      case VariantType.UInt32:
      case VariantType.StatusCode:
        this.statusCode(v as number)
        break

      case VariantType.Int64:
        this.int64(v as number)
        break

      case VariantType.UInt64:
        this.uint64(v as number)
        break

      case VariantType.Float:
        this.float(v as number)
        break

      case VariantType.Double:
        this.double(v as number)
        break

      case VariantType.String:
        this.charArray(v as string)
        break

      case VariantType.DateTime:
        this.dateTime(v as number | Date)
        break

      case VariantType.Guid:
        this.guid(v as Guid)
        break

      case VariantType.ByteString:
        this.byteString(v as string | Uint8Array)
        break

      case VariantType.NodeId:
      case VariantType.ExpandedNodeId:
        this.nodeId(v as NodeId | string)
        break

      case VariantType.QualifiedName:
        this.qualifiedName(v as QualifiedName)
        break

      case VariantType.LocalizedText:
        this.localizedText(v as LocalizedText)
        break

      case VariantType.Variant:
        this.variant(v as Variant)
        break

      case VariantType.DataValue:
        this.dataValue(v as DataValue)
        break

      case VariantType.XmlElement:
        this.xmlElement(v as XmlElement)
        break

      case VariantType.DiagnosticInfo:
        this.diagnosticInfo(v as DiagnosticInfo)
        break
      default:
        throw new OpcuaError(BadEncodingError)
    }
  }

  variant (v: Variant): void {
    const val = !(v instanceof Variant) ? new Variant(v) : v

    this.bit(val.Type, 7)
    this.bit(val.IsArray)
    if (val.IsArray) {
      if (!(val.Value instanceof Array)) {
        throw new OpcuaError(BadEncodingError, "Array value is not an array")
      }
      const arr = val.Value
      const len = arr.length
      this.uint32(len)
      if (len !== 0xFFFFFFFF) {
        for (let i = 0; i < len; i++) {
          this.encodeVariantValue(arr[i] as VariantScalarTypes, val.Type)
        }
      }
    } else {
      this.encodeVariantValue(val.Value as VariantScalarTypes, val.Type)
    }
  }

  extensionObject (val: ExtensionObject): void {
    if (val.TypeId.toString() === "i=0") {
      this.nodeId(val.TypeId)
      this.uint8(0)
      return
    }

    let nodeId = val.TypeId.toString()
    const node = this.ns0[nodeId]
    if (node) {
      if (node.BinaryId === undefined) {
        throw new OpcuaError(StatusCode.BadNodeIdUnknown)
      }
      nodeId = node.BinaryId
    }

    this.nodeId(nodeId)
    const body = val.Body
    const hasBody = body !== null && body !== undefined
    this.uint8(hasBody ? 1 : 0)
    if (hasBody) {
      if (body instanceof Uint8Array) {
        this.byteString(body)
      } else {
        const sizeOffset = this.len
        this.uint32(0)
        this.encodeStructure(body as Record<string, unknown>, nodeId)
        this.view.setUint32(sizeOffset, this.len - sizeOffset - 4, true)
      }
    }
  }

  getEnumValue(val: string | number, fields: ns.EnumField[]): number {
    if (typeof val  === "string") {
      for (const f of fields) {
        if (f.Name == val) {
          return f.Value
        }
      }
      throw new OpcuaError(StatusCode.BadEncodingError, `Invalid enum value {val}`)
    }
    else if (typeof val === "number") {
      return val
    }

    throw new OpcuaError(StatusCode.BadEncodingError, `Invalid enum value {val}`)
  }

  encodeStructure(obj: Record<string, unknown>, nodeId: string | NodeId): void {
    const node = this.ns0[nodeId.toString()]
    if (node === undefined) {
      throw new OpcuaError(StatusCode.BadNodeIdUnknown)
    }

    if (node.Definition === undefined) {
      throw new OpcuaError(StatusCode.BadNodeIdUnknown)}

    for (const field of node.Definition) {
      const f = field as ns.Field
      if (f.Name in obj === false) {
        throw new OpcuaError(StatusCode.BadEncodingError, `Field ${f.Name} not found in object`)
      }

      const structField = field as ns.StructField
      if (structField.ValueRank === 1) {
        const arr = obj[f.Name] as unknown[]
        const len = arr ? arr.length : 0xFFFFFFFF
        this.uint32(len)
        if (len !== 0xFFFFFFFF)
        {
          for (let v of arr) {
            if (structField.BaseTypeId === "i=29") {
              v = this.getEnumValue(v as string | number, node.Definition as ns.EnumField[])
            }
            if (structField.DataTypeId === "i=22") {
              this.extensionObject(v as ExtensionObject)
            } else {
              this.encodeValue(structField.BaseTypeId, v as VariantTypes, structField.DataTypeId)
            }
          }
        }
      } else {
        let v = obj[f.Name]
        if (field.BaseTypeId === "i=29") {
          v = this.getEnumValue(v as string | number, node.Definition as ns.EnumField[])
        }

        if (structField.DataTypeId === "i=22") {
          this.extensionObject(v as ExtensionObject)
        } else {
          this.encodeValue(structField.BaseTypeId, v as VariantTypes, structField.DataTypeId)
        }
      }
    }
  }

  encodeRequest(requestTypeId: NodeId | string, request: ExtensionObject): void {
    const node = this.ns0[requestTypeId.toString()]
    if (node === undefined) {
      throw new OpcuaError(StatusCode.BadNodeIdUnknown, `No node found for request type ${requestTypeId}`)
    }
    if (node.BinaryId == undefined) {
      throw new OpcuaError(StatusCode.BadNodeIdUnknown, "No binary id found for request type")
    }
    this.nodeId(node.BinaryId)
    if (request.Body === null) {
      throw new OpcuaError(StatusCode.BadEncodingError, "Request body is null")
    } else if (typeof request.Body === 'string') {
      this.byteString(request.Body)
    } else if (request.Body instanceof Uint8Array) {
      this.byteString(request.Body)
    } else {
      this.encodeStructure(request.Body as Record<string, unknown>, requestTypeId.toString())
    }
  }



  encodeValue(nodeId: string | NodeId, v: VariantTypes, valueId: string | NodeId): void {
    switch (nodeId) {
      case "i=1": return this.boolean(v as boolean)
      case "i=2": return this.int8(v as number)
      case "i=3": return this.uint8(v as number)
      case "i=4": return this.uint16(v as number)
      case "i=5": return this.uint16(v as number)
      case "i=6": return this.int32(v as number)
      case "i=7": return this.uint32(v as number)
      case "i=8": return this.int64(v as number | bigint)
      case "i=9": return this.uint64(v as number | bigint)
      case "i=10": return this.float(v as number)
      case "i=11": return this.double(v as number)
      case "i=13": return this.dateTime(v as number | Date)
      case "i=294": return this.dateTime(v as number | Date)
      case "i=12": return this.string(v as string)
      case "i=14": return this.guid(v as Guid)
      case "i=15": return this.byteString(v as string | number[] | Uint8Array | undefined | null)
      case "i=16": return this.xmlElement(v as XmlElement)
      case "i=17": return this.nodeId(v as NodeId | string)
      case "i=18": return this.expandedNodeId(v as NodeId | string)
      case "i=19": return this.statusCode(v as StatusCode)
      case "i=20": return this.qualifiedName(v as QualifiedName)
      case "i=21": return this.localizedText(v as LocalizedText)
      case "i=22": return this.encodeStructure(v as Record<string, unknown>, valueId)
      case "i=23": return this.dataValue(v as DataValue)
      case "i=25": return this.diagnosticInfo(v as DiagnosticInfo)
      case "i=29": return this.uint32(v as number)
      default:
        throw new OpcuaError(StatusCode.BadEncodingError, `Unknown node id ${nodeId}`)
    }
  }
}

export { BinaryEncoder }
