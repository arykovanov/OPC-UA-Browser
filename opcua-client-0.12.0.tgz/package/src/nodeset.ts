import * as t from './types'

export class Attribute {
  public Id: number
  public Value: t.VariantTypes

  constructor(id: number, Value: t.Variant) {
    this.Id = id
    this.Value = Value
  }
}
export class Reference {
  public NodeId: string
  public ReferenceTypeId: string
  public IsForward: boolean

  constructor(nodeId: string, referenceTypeId: string, isForward: boolean) {
    this.NodeId = nodeId
    this.ReferenceTypeId = referenceTypeId
    this.IsForward = isForward
  }
}

export class Field {
  public Name: string
  public BaseTypeId: string

  constructor(name: string, baseTypeId: string) {
    this.Name = name
    this.BaseTypeId = baseTypeId
  }
}

export class StructField extends Field{
  public DataTypeId: string
  public ValueRank: number
  public ArrayDimensions: string | null

  constructor(name: string, dataTypeId: string, baseTypeId: string, valueRank: number, arrayDimensions: string | null) {
    super(name, baseTypeId)
    this.DataTypeId = dataTypeId
    this.ValueRank = valueRank
    this.ArrayDimensions = arrayDimensions
  }
}
export class EnumField extends Field{
  public Value: number

  constructor(name: string, value: number) {
    super(name, "i=29")
    this.Value = value
  }
}

export type Node = {
  Attributes: Attribute[]
  References: Reference[]
  Definition?: StructField[] | EnumField[] | undefined
  BinaryId?: string | undefined
  JsonId?: string | undefined
}

export type NodeSet = {
  [s: string]: Node
}
