import { DataValue, Guid, LocalizedText, OpcuaError, QualifiedName, NodeId, Variant, VariantType, XmlElement, ExtensionObject, DiagnosticInfo, getDebugTrace, VariantTypes } from './types'
import { StatusCode } from './status_codes'

import * as ns from "./nodeset"

import ns0 from "./ns0"

const BadEncodingError = StatusCode.BadEncodingError

// function timetToFiletime (ms: number): bigint {
//   if (ms === 0) { return 0n }

//   if (ms > 0 && ms < 1) { ms = 0 }

//   const ns = (BigInt(ms) * 10000n) + 116444736000000000n // windowsEpochMs
//   return ns
// }

function uint8ArrayToBase64(byteArray: Uint8Array): string {
  // Step 1: Convert Uint8Array to binary string
  let binaryString = "";
  for (let i = 0; i < byteArray.byteLength; i++) {
    const byte = byteArray[i];
    if (typeof byte !== 'number') {
      throw new OpcuaError(BadEncodingError, "Invalid byte type")
    }
    binaryString += String.fromCharCode(byte);
  }

  // Step 2: Convert binary string to Base64
  return btoa(binaryString);
}


class JsonEncoder {
  private readonly textEncoder = new TextEncoder()
  private readonly arr: Uint8Array
  private readonly buffer: ArrayBuffer
  private len: number = 0
  private bits_count: number = 0
  public ns0: ns.NodeSet = ns0

  constructor (buffer: ArrayBuffer) {
    this.buffer = buffer
    this.arr = new Uint8Array(buffer)
  }

  get data (): ArrayBuffer {
    return this.buffer.slice(0, this.len)
  }

  int8 (val: number): void {
    if (this.bits_count !== 0) {
      throw new OpcuaError(BadEncodingError)
    }

    if (val < -128 || val > 127) {
      throw new OpcuaError(BadEncodingError, "Int8 out of range")
    }

    this.str(val.toString())
  }

  sbyte = this.int8

  uint8 (val: number): void {
    if (this.bits_count !== 0) {
      throw new OpcuaError(BadEncodingError, "Invalid number of bits")
    }

    if (val < 0 || val > 255) {
      throw new OpcuaError(BadEncodingError, "UInt8 out of range")
    }

    this.str(val.toString())
  }

  byte = this.uint8

  char (val: string): void {
    if (this.bits_count !== 0) {
      throw new OpcuaError(BadEncodingError)
    }

    if (typeof val !== 'string' || val.length !== 1) {
      throw new OpcuaError(BadEncodingError)
    }

    this.str('"')
    this.str(val)
    this.str('"')
  }

  int16 (val: number): void {
    if (val < -32768 || val > 32767) {
      throw new OpcuaError(BadEncodingError, "Int16 out of range")
    }

    this.str(val.toString())
  }

  uint16 (val: number): void {
    if (val < 0 || val > 65535) {
      throw new OpcuaError(BadEncodingError, "UInt16 out of range")
    }

    this.str(val.toString())
  }

  int32 (val: number): void {
    if (val < -2147483648 || val > 2147483647) {
      throw new OpcuaError(BadEncodingError, "Int32 out of range")
    }

    this.str(val.toString())
  }

  uint32 (val: number): void {
    if (val < 0 || val > 4294967295) {
      throw new OpcuaError(BadEncodingError, "UInt32 out of range")
    }

    this.str(val.toString())
  }

  int64 (val: number | bigint): void {
    if (val < Number.MIN_SAFE_INTEGER || val > Number.MAX_SAFE_INTEGER) {
      throw new OpcuaError(BadEncodingError, "Int64 out of range")
    }

    this.str(val.toString())
  }

  uint64 (val: number | bigint): void {
    if (val < 0) {
      throw new OpcuaError(BadEncodingError, "UInt64 out of range")
    }

    this.str(val.toString())
  }

  float (val: number): void {
    this.str(val.toString())
  }

  double (val: number): void {
    this.str(val.toString())
  }

  boolean (v: boolean | number): void {
    if (typeof v === 'number') {
      v = v !== 0 ? true : false
    } else if (typeof v !== 'boolean') {
      throw new Error('invalid boolean type')
    }

    this.str(v ? 'true' : 'false')
  }

  dateTime(ms: number | Date): void {
    if (typeof ms === 'number') {
      ms = new Date(ms)
    }
    this.string(new Date(ms).toISOString())
  }

  statusCode(val: StatusCode | OpcuaError | null): void {
    if (val instanceof OpcuaError) {
      if (val.Code === StatusCode.Good) {
        this.uint32(0)
      } else {
        this.str('{"Code":')
        this.uint32(val.Code)
        if (val.message.length > 0) {
          this.str(',"Symbol":')
          this.string(val.message)
        }
        this.str('}')
      }
    } else if (val === null) {
      this.uint32(0)
    } else {
      this.uint32(val)
    }
  }

  array = this.byteString

  str (val: string): void {
    const utf8 = this.textEncoder.encode(val)
    if (this.len + utf8.length > this.buffer.byteLength) {
      throw new OpcuaError(BadEncodingError)
    }

    this.arr.set(utf8, this.len)
    this.len += utf8.length
  }

  byteString (val: string | number[] | Uint8Array | undefined | null): void {
    if (val === null || val === undefined) {
      this.str("null")
      return
    }

    let arr
    if (typeof val === 'string') {
      arr = this.textEncoder.encode(val)
    } else if (val instanceof ArrayBuffer) {
      arr = new Uint8Array(val)
    } else if (val instanceof Array) {
      arr = Uint8Array.from(val)
    } else if (val instanceof Uint8Array) {
      arr = val
    } else {
      throw new Error('invalid type')
    }

    const b64 = uint8ArrayToBase64(arr)
    this.string(b64)
  }

  charArray  = this.byteString

  string(val: string | null): void {
    if (val === null) {
      this.str("null")
      return
    }

    this.str('"')
    this.str(val)
    this.str('"')
  }

  guid(v: Guid): void {
    this.string(v.toString())
  }

  qualifiedName(v: QualifiedName): void {
    this.str('{')
    this.str('"Name":')
    this.string(v.Name)
    if (v.Ns !== 0) {
      this.str(',"NamespaceIndex":')
      this.uint16(v.Ns)
    }
    this.str('}')
  }

  localizedText (v: LocalizedText): void {
    this.str('{')
    if (v.Locale != null) {
      this.str('"Locale":')
      this.string(v.Locale)
    }
    if (v.Text != null) {
      if (v.Locale != null) {
        this.str(',')
      }
      this.str('"Text":')
      this.string(v.Text)
    }
    this.str('}')
  }

  xmlElement (v: XmlElement): void {
    if (v.Value == null) {
      this.str("null")
      return
    }

    this.string(v.Value)
  }

  dataValue(v: DataValue): void {
    this.str('{')
    let hasFields = false
    this.str('"Value":')
    this.variant(v)
    hasFields = true

    if (v.StatusCode != null) {
      if (hasFields) {
        this.str(',')
      }

      this.str('"StatusCode":')
      this.statusCode(v.StatusCode)
      hasFields = true
    }
    if (v.SourceTimestamp != null) {
      if (hasFields) {
        this.str(',')
      }

      this.str('"SourceTimestamp":')
      this.dateTime(v.SourceTimestamp)
      hasFields = true
    }
    if (v.ServerTimestamp != null) {
      if (hasFields) {
        this.str(',')
      }

      this.str('"ServerTimestamp":')
      this.dateTime(v.ServerTimestamp)
      hasFields = true
    }
    if (v.SourcePicoseconds != null) {
      if (hasFields) {
        this.str(',')
      }

      this.str('"SourcePicoseconds":')
      this.uint16(v.SourcePicoseconds)
      hasFields = true
    }
    if (v.ServerPicoseconds != null) {
      if (hasFields) {
        this.str(',')
      }

      this.str('"ServerPicoseconds":')
      this.uint16(v.ServerPicoseconds)
    }
    this.str('}')
  }

  diagnosticInfo(v: DiagnosticInfo): void {
    this.str('{')

    let hasFields = false
    if (v.SymbolicId != null) {
      this.str('"SymbolicId":')
      this.int32(v.SymbolicId)
      hasFields = true
    }
    if (v.NamespaceUri != null) {
      if (hasFields) {
        this.str(',')
      }
      this.str('"NamespaceUri":')
      this.int32(v.NamespaceUri)
      hasFields = true
    }
    if (v.Locale != null) {
      if (hasFields) {
        this.str(',')
      }
      this.str('"Locale":')
      this.int32(v.Locale)
      hasFields = true
    }
    if (v.LocalizedText != null) {
      if (hasFields) {
        this.str(',')
      }
      this.str('"LocalizedText":')
      this.int32(v.LocalizedText)
      hasFields = true
    }
    if (v.AdditionalInfo != null) {
      if (hasFields) {
        this.str(',')
      }
      this.str('"AdditionalInfo":')
      this.string(v.AdditionalInfo)
      hasFields = true
    }
    if (v.InnerStatusCode != null) {
      if (hasFields) {
        this.str(',')
      }
      this.str('"InnerStatusCode":')
      this.statusCode(v.InnerStatusCode)
      hasFields = true
    }
    if (v.InnerDiagnosticInfo != null) {
      if (hasFields) {
        this.str(',')
      }
      this.str('"InnerDiagnosticInfo":')
      this.diagnosticInfo(v.InnerDiagnosticInfo)
      hasFields = true
    }

    this.str('}')
  }

  encodeVariantValue(v: VariantTypes, type: VariantType): void {

    switch (type) {
      case VariantType.Null:
        return
      case VariantType.Boolean:
        this.boolean(v as boolean)
        break
      case VariantType.SByte:
        this.int8(v as number)
        break
      case VariantType.Byte:
        this.uint8(v as number)
        break
      case VariantType.Int16:
        this.int16(v as number)
        break
      case VariantType.UInt16:
        this.uint16(v as number)
        break

      case VariantType.Int32:
        this.int32(v as number)
        break

      case VariantType.UInt32:
      case VariantType.StatusCode:
        this.statusCode(v as StatusCode)
        break

      case VariantType.Int64:
        this.int64(v as number | bigint)
        break

      case VariantType.UInt64:
        this.uint64(v as number | bigint)
        break

      case VariantType.Float:
        this.float(v as number)
        break

      case VariantType.Double:
        this.double(v as number)
        break

      case VariantType.String:
        this.string(v as string)
        break

      case VariantType.DateTime:
        this.dateTime(v as number | Date)
        break

      case VariantType.Guid:
        this.guid(v as Guid)
        break

      case VariantType.ByteString:
        this.byteString(v as string | number[] | Uint8Array | undefined | null)
        break

      case VariantType.NodeId:
      case VariantType.ExpandedNodeId:
        this.nodeId(v as NodeId | string)
        break

      case VariantType.QualifiedName:
        this.qualifiedName(v as QualifiedName)
        break
      case VariantType.LocalizedText:
        this.localizedText(v as LocalizedText)
        break
      case VariantType.Variant:
        this.variant(v as Variant)
        break

      case VariantType.DataValue:
        this.dataValue(v as DataValue)
        break

      case VariantType.XmlElement:
        this.xmlElement(v as XmlElement)
        break

      case VariantType.DiagnosticInfo:
        this.diagnosticInfo(v as DiagnosticInfo)
        break
      default:
        throw new OpcuaError(BadEncodingError)
    }
  }

  nodeId (v: NodeId | string): void {
    let ns = 0 // namespace index
    let nsUri // namespace uri
    let si // server index

    let idType = 0 // mask of NodeId Type with NodeIdType | HasServiceIndex | HasNamespaceUri
    const nsiEnc = this.uint16 // namespace Index endcoding func

    if (typeof v === 'string') {
      v = new NodeId(v)
    } else if (!(v instanceof NodeId)) {
      throw new OpcuaError(BadEncodingError)
    }

    const id = v.Id
    if (typeof (v.Ns) === 'number') {
      ns = v.Ns
    } else if (typeof (v.Ns) === 'string') {
      nsUri = v.Ns
    }

    if (typeof (v.Srv) === 'number') {
      si = v.Srv
    }

    if (typeof (id) === 'number') {
      idType = 0
    } else if (typeof (id) === 'string') {
      idType = 1
    } else if (id instanceof Guid) {
      idType = 2
    } else if (id instanceof Uint8Array) {
      idType = 3
    } else {
      throw new OpcuaError(BadEncodingError)
    }

    this.str('{')


    // Node ID fields mask
    if (idType != 0) {
      this.str('"IdType":')
      this.uint8(idType)
      this.str(',')
    }

    // namespace index
    if (nsiEnc !== undefined && ns !== 0) {
      this.str('"NamespaceIndex":')
      nsiEnc.call(this, ns)
      this.str(',')
    }

    // Node ID value
    this.str('"Id":')

    if (typeof (id) === 'number') {
      this.uint32(id)
    } else if (typeof (id) === 'string') {
      this.string(id)
    } else if (id instanceof Guid) {
      this.guid(id)
    } else if (id instanceof Uint8Array) {
      this.byteString(id)
    } else {
      throw new OpcuaError(BadEncodingError)
    }

    // namespace Uri
    if (nsUri !== undefined) {
      this.str(',"NamespaceUri":')
      this.string(nsUri)
    }

    // Server Index
    if (typeof (si) === 'number') {
      this.str(',"ServerIndex":')
      this.uint32(si)
    }

    this.str('}')
  }

  expandedNodeId = this.nodeId

  variant (v: Variant): void {
    this.str('{"Type":')
    this.uint8(v.Type)

    if (v.Type !== VariantType.Null) {
      this.str(',"Body":')
      if (v.IsArray) {
        const arr = v.Value as unknown[]
        const len = arr.length
        this.uint32(len)
        for (let i = 0; i < len; i++) {
          this.encodeVariantValue(arr[i] as VariantTypes, v.Type)
        }
      } else {
        this.encodeVariantValue(v.Value, v.Type)
      }
    }

    this.str('}')
  }

  encodeRequest(_: NodeId | string, request: ExtensionObject): void {
    this.extensionObject(request);
  }

  extensionObject(val: ExtensionObject): void {
    let typeId = val.TypeId instanceof NodeId ? val.TypeId.toString() : val.TypeId
    if (typeId === "i=0") {
      this.str('{"TypeId":')
      this.nodeId(val.TypeId)
      this.str("}")
      return
    }
    const node = this.ns0[typeId]
    if (node) {
      if (node.JsonId === undefined) {
        throw new OpcuaError(StatusCode.BadNodeIdUnknown)
      }
      typeId = node.JsonId
    }

    this.str('{"TypeId":')
    this.nodeId(typeId)
    this.str(",")

    const body = val.Body
    const hasBody = body !== null && body !== undefined
    if (hasBody) {
      if (body instanceof Uint8Array) {
        this.str('"Encoding":')
        this.uint32(1)
        this.str(',"Body":')
        this.byteString(body)
      } else {
        this.str('"Encoding":')
        this.uint32(0)
        this.str(',"Body":')
        this.encodeStructure(body as Record<string, unknown>, typeId)
      }
    } else {
      this.str("null")
    }
    this.str("}")
  }

  getEnumValue(val: string | number, fields: ns.EnumField[]): number {
    if (typeof val  === "string") {
      for (const f of fields) {
        if (f.Name == val) {
          return f.Value
        }
      }
      throw new OpcuaError(StatusCode.BadEncodingError, `Invalid enum value {val}`)
    }
    else if (typeof val === "number") {
      return val
    }

    throw new OpcuaError(StatusCode.BadEncodingError, `Invalid enum value {val}`)
  }

  encodeStructure(obj: Record<string, unknown>, nodeId: string | NodeId): void {
    const node = typeof nodeId === "string" ? this.ns0[nodeId] : this.ns0[nodeId.toString()]
    if (node === undefined) {
      throw new OpcuaError(StatusCode.BadNodeIdUnknown)
    }

    if (node.Definition === undefined) {
      throw new OpcuaError(StatusCode.BadNodeIdUnknown)}

    this.str("{")

    for (let i = 0; i < node.Definition.length; ++i) {
      const field = node.Definition[i]
      const f = field as ns.Field
      if (f.Name in obj === false) {
        throw new OpcuaError(StatusCode.BadEncodingError, `Field ${f.Name} not found in object`)
      }

      this.string(f.Name)
      this.str(":")

      const structField = field as ns.StructField
      if (getDebugTrace()) {
        console.log(`Encoding field '${structField.Name}'`)
      }

      if (structField.ValueRank === 1) {
        const arr = obj[f.Name] as unknown[]
        const len = arr ? arr.length : 0xFFFFFFFF
        if (len !== 0xFFFFFFFF)
        {
          this.str("[")
          for (let i = 0; i < len; i++) {
            if (i > 0) {
              this.str(",")
            }

            let v = arr[i]
            if (structField.BaseTypeId === "i=29") {
              v = this.getEnumValue(v as string | number, node.Definition as ns.EnumField[])
            }
            if (structField.DataTypeId === "i=22") {
              this.extensionObject(v as ExtensionObject)
            } else {
              this.encodeValue(structField.BaseTypeId, v as VariantTypes, structField.DataTypeId)
            }
          }
          this.str("]")
        } else {
          this.str("null")
        }
      } else {
        let v = obj[f.Name] as unknown
        if (structField.BaseTypeId === "i=29") {
          v = this.getEnumValue(v as string | number, node.Definition as ns.EnumField[])
        }

        if (structField.DataTypeId === "i=22") {
          this.extensionObject(v as ExtensionObject)
        } else {
          this.encodeValue(structField.BaseTypeId, v as VariantTypes, structField.DataTypeId)
        }
      }

      if (i < node.Definition.length - 1) {
        this.str(",")
      }
    }

    this.str("}")
  }

  encodeValue(nodeId: string | NodeId, v: VariantTypes, valueId: string | NodeId): void {
    switch (nodeId) {
      case "i=1": return this.boolean(v as boolean)
      case "i=2": return this.int8(v as number)
      case "i=3": return this.uint8(v as number)
      case "i=4": return this.uint16(v as number)
      case "i=5": return this.uint16(v as number)
      case "i=6": return this.int32(v as number)
      case "i=7": return this.uint32(v as number)
      case "i=8": return this.int64(v as number | bigint)
      case "i=9": return this.uint64(v as number | bigint)
      case "i=10": return this.float(v as number)
      case "i=11": return this.double(v as number)
      case "i=13": return this.dateTime(v as number | Date)
      case "i=294": return this.dateTime(v as number | Date)
      case "i=12": return this.string(v as string)
      case "i=14": return this.guid(v as Guid)
      case "i=15": return this.byteString(v as string | number[] | Uint8Array | undefined | null)
      case "i=16": return this.xmlElement(v as XmlElement)
      case "i=17": return this.nodeId(v as NodeId | string)
      case "i=18": return this.expandedNodeId(v as NodeId | string)
      case "i=19": return this.statusCode(v as StatusCode)
      case "i=20": return this.qualifiedName(v as QualifiedName)
      case "i=21": return this.localizedText(v as LocalizedText)
      case "i=22": return this.encodeStructure(v as Record<string, unknown>, valueId)
      case "i=23": return this.dataValue(v as DataValue)
      case "i=25": return this.diagnosticInfo(v as DiagnosticInfo)
      case "i=29": return this.uint32(v as number)
      default:
        throw new OpcuaError(StatusCode.BadEncodingError, `Unknown node id ${nodeId}`)
    }
  }
}

export { JsonEncoder }
