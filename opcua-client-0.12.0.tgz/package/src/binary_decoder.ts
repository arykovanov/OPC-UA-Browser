import { NodeId, OpcuaError, Guid, VariantType, Variant, QualifiedName, LocalizedText, DataValue, XmlElement, ExtensionObject, DiagnosticInfo, VariantScalarTypes} from './types'
import { NodeIdType } from './enums'
import { StatusCode } from './status_codes'
import * as ns from "./nodeset"
import ns0 from "./ns0"


function filetimeToTimeT (fileTime: bigint): number {
  const windowsEpochMs = 11644473600000n // 1970-01-01T00:00:00.000Z
  const ms = fileTime / 10000n - windowsEpochMs
  let result = Number(ms)
  if (ms === 0n) { result += 0.1 }
  return result
}

// type DecodeFunc = ((this: BinaryDecoder) => VariantTypes) | ((this: BinaryDecoder, opt: string) => VariantTypes)

class BinaryDecoder {
  readonly data: DataView
  readonly buffer: ArrayBuffer
  bitNum: number = 0
  offset: number = 0
  b: number | undefined = undefined

  constructor (buffer: ArrayBuffer) {
    this.data = new DataView(buffer)
    this.buffer = buffer
  }

  bit (count = 1): number {
    if (this.bitNum < 0 || this.bitNum > 7) {
      throw new OpcuaError(StatusCode.BadInternalError)
    }

    if (this.bitNum + count > 8) {
      throw new OpcuaError(StatusCode.BadInternalError)
    }

    let val = this.b
    if (val === undefined) {
      val = this.uint8()
      this.b = val
    }

    const mask = (0xFF >> (8 - count))
    let value = val & (mask << this.bitNum)
    value >>= this.bitNum

    this.bitNum += count
    if (this.bitNum === 8) {
      this.bitNum = 0
      this.b = undefined
    }

    return value
  }

  boolean (): boolean {
    const value = this.data.getUint8(this.offset++)
    return value !== 0
  }

  int8 (): number {
    return this.data.getInt8(this.offset++)
  }

  sbyte = this.int8

  uint8 (): number {
    return this.data.getUint8(this.offset++)
  }

  byte = this.uint8

  int16 (): number {
    const value = this.data.getInt16(this.offset, true)
    this.offset += 2
    return value
  }

  uint16 (): number {
    const value = this.data.getUint16(this.offset, true)
    this.offset += 2
    return value
  }

  int32 (): number {
    const value = this.data.getInt32(this.offset, true)
    this.offset += 4
    return value
  }

  uint32 (): number {
    const value = this.data.getUint32(this.offset, true)
    this.offset += 4
    return value
  }

  statusCode(): OpcuaError {
    const code = this.uint32()
    return new OpcuaError(code)
  }

  int64 (): bigint {
    const val = this.data.getBigInt64(this.offset, true)
    this.offset += 8
    return val
  }

  uint64 (): bigint {
    const val = this.data.getBigUint64(this.offset, true)
    this.offset += 8
    return val
  }

  float (): number {
    const value = this.data.getFloat32(this.offset, true)
    this.offset += 4
    return value
  }

  double (): number {
    const value = this.data.getFloat64(this.offset, true)
    this.offset += 8
    return value
  }

  dateTime (): number {
    const val = this.data.getBigUint64(this.offset, true)
    this.offset += 8
    if (val === 0n) {
      return 0
    }

    return filetimeToTimeT(val)
  }

  str (size: number): string {
    if (size === 0) {
      return ''
    }

    const data = new Uint8Array(this.buffer, this.offset, size)
    this.offset += size
    return String.fromCharCode(...data)
  }

  charArray (): string | null {
    const size = this.uint32()
    if (size === 0xFFFFFFFF) {
      return null
    }
    return this.str(size)
  }

  string = this.charArray

  byteString (): Uint8Array | null {
    const size = this.uint32()
    if (size === 0xFFFFFFFF) {
      return null
    }
    const bytes = this.buffer.slice(this.offset, this.offset + size)
    this.offset += size
    return new Uint8Array(bytes)
  }

  guid (): Guid {
    const data1 = this.uint32()
    const data2 = this.uint16()
    const data3 = this.uint16()
    const data4 = this.byte()
    const data5 = this.byte()
    const data6 = this.byte()
    const data7 = this.byte()
    const data8 = this.byte()
    const data9 = this.byte()
    const data10 = this.byte()
    const data11 = this.byte()
    const guidString = `${data1.toString(16).padStart(8, '0')}-${data2.toString(16).padStart(4, '0')}-${data3.toString(16).padStart(4, '0')}-${data4.toString(16).padStart(2, '0')}${data5.toString(16).padStart(2, '0')}-${data6.toString(16).padStart(2, '0')}${data7.toString(16).padStart(2, '0')}${data8.toString(16).padStart(2, '0')}${data9.toString(16).padStart(2, '0')}${data10.toString(16).padStart(2, '0')}${data11.toString(16).padStart(2, '0')}`
    return new Guid(guidString)
  }

  nodeId (): NodeId {
    const nodeIdType = this.bit(6)
    if (nodeIdType > 5 || nodeIdType < 0) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    let ns: number | string = 0
    let id: number | string | Uint8Array | Guid | XmlElement | ExtensionObject | LocalizedText | DataValue | Variant | QualifiedName | undefined = undefined
    let srv: number | null = null

    const hasSi = this.bit(1)
    const hasNs = this.bit(1)

    if (nodeIdType === NodeIdType.TwoByte) {
      if (hasNs === 1) { throw new OpcuaError(StatusCode.BadDecodingError) }
      id = `i=${this.uint8()}`
    } else if (nodeIdType === NodeIdType.FourByte) {
      ns = this.uint8()
      id = `i=${this.uint16()}`
    } else if (nodeIdType === NodeIdType.Numeric) {
      ns = this.uint16()
      id = `i=${this.uint32()}`
    } else if (nodeIdType === NodeIdType.String) {
      ns = this.uint16()
      id = `s=${this.string()}`
    } else if (nodeIdType === NodeIdType.Guid) {
      ns = this.uint16()
      id = `g=${this.guid()}`
    } else if (nodeIdType === NodeIdType.ByteString) {
      ns = this.uint16()
      const bytes = this.byteString()
      if (bytes === null) {
        throw new OpcuaError(StatusCode.BadDecodingError, 'NodeID with null ByteString')
      }
      const base64 = btoa(String.fromCharCode(...bytes))
      id = `b=${base64}`
    }

    let idStr = id
    if (ns != 0) {
      idStr = `ns=${ns};${id}`
    }

    if (hasNs === 1) {
      const nsu = this.string()
      if (typeof nsu !== 'string') { throw new OpcuaError(StatusCode.BadDecodingError) }
      idStr = `nsu=${nsu};${idStr}`
    }

    if (hasSi === 1) {
      srv = this.uint32()
      idStr = `svr=${srv};${idStr}`
    }

    return new NodeId(idStr)
  }

  expandedNodeId = this.nodeId

  qualifiedName (): QualifiedName {
    const ns = this.uint16()
    const name = this.charArray()
    if (name === null) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'QualifiedName with null name')
    }
    return new QualifiedName(ns, name)
  }

  xmlElement (): XmlElement {
    const length = this.int32()
    let value = null
    if (length !== -1) {
      value = this.str(length)
    }
    return new XmlElement(value)
  }

  localizedText (): LocalizedText {
    const localeSpecified = this.bit()
    const textSpecified = this.bit()
    this.bit(6)
    let locale
    if (localeSpecified !== 0) {
      locale = this.charArray()
    }
    let text = null
    if (textSpecified !== 0) {
      text = this.charArray()
    }
    return new LocalizedText(text, locale)
  }

  dataValue (): DataValue {
    const valueSpecified = this.bit()
    const statusCodeSpecified = this.bit()
    const sourceTimestampSpecified = this.bit()
    const serverTimestampSpecified = this.bit()
    const sourcePicosecondsSpecified = this.bit()
    const serverPicosecondsSpecified = this.bit()
    this.bit(2)
    let value
    if (valueSpecified !== 0) {
      value = this.variant()
    }
    let statusCode
    if (statusCodeSpecified !== 0) {
      statusCode = this.statusCode()
    }
    let sourceTimestamp
    if (sourceTimestampSpecified !== 0) {
      sourceTimestamp = this.dateTime()
    }
    let serverTimestamp
    if (serverTimestampSpecified !== 0) {
      serverTimestamp = this.dateTime()
    }
    let sourcePicoseconds
    if (sourcePicosecondsSpecified !== 0) {
      sourcePicoseconds = this.uint16()
    }
    let serverPicoseconds
    if (serverPicosecondsSpecified !== 0) {
      serverPicoseconds = this.uint16()
    }
    return new DataValue(
      value, statusCode,
      sourceTimestamp, serverTimestamp,
      sourcePicoseconds, serverPicoseconds)
  }

  diagnosticInfo (): DiagnosticInfo {
    const symbolicIdSpecified = this.bit()
    const namespaceURISpecified = this.bit()
    const localizedTextSpecified = this.bit()
    const localeSpecified = this.bit()
    const additionalInfoSpecified = this.bit()
    const innerStatusCodeSpecified = this.bit()
    const innerDiagnosticInfoSpecified = this.bit()
    this.bit(1)
    let symbolicId
    if (symbolicIdSpecified !== 0) {
      symbolicId = this.int32()
    }
    let namespaceURI
    if (namespaceURISpecified !== 0) {
      namespaceURI = this.int32()
    }
    let locale
    if (localeSpecified !== 0) {
      locale = this.int32()
    }
    let localizedText
    if (localizedTextSpecified !== 0) {
      localizedText = this.int32()
    }
    let additionalInfo
    if (additionalInfoSpecified !== 0) {
      additionalInfo = this.charArray()
    }
    let innerStatusCode
    if (innerStatusCodeSpecified !== 0) {
      innerStatusCode = this.statusCode()
    }
    let innerDiagnosticInfo
    if (innerDiagnosticInfoSpecified !== 0) {
      innerDiagnosticInfo = this.diagnosticInfo()
    }
    return new DiagnosticInfo(
      symbolicId,
      namespaceURI,
      localizedText,
      locale,
      additionalInfo,
      innerStatusCode,
      innerDiagnosticInfo
    )
  }

  private decodeVariantValue(type: number): VariantScalarTypes {
    // let objectType
    switch (type) {
      case VariantType.Null:
        return new Variant()
      case VariantType.Boolean:
        return this.boolean()
      case VariantType.SByte:
        return this.int8()
      case VariantType.Byte:
        return this.uint8()
      case VariantType.Int16:
        return this.int16()
      case VariantType.UInt16:
        return this.uint16()
      case VariantType.Int32:
        return this.int32()
      case VariantType.UInt32:
        return this.uint32()
      case VariantType.Int64:
        return this.int64()
      case VariantType.UInt64:
        return this.uint64()
      case VariantType.Float:
        return this.float()
      case VariantType.Double:
        return this.double()
      case VariantType.String:
        return this.string()
      case VariantType.DateTime:
        return this.dateTime()
      case VariantType.Guid:
        return this.guid()
      case VariantType.ByteString:
        return this.byteString()
      case VariantType.XmlElement:
        return this.xmlElement()
      case VariantType.NodeId:
        return this.nodeId()
      case VariantType.ExpandedNodeId:
        return this.expandedNodeId()
      case VariantType.StatusCode:
        return this.statusCode()
      case VariantType.QualifiedName:
        return this.qualifiedName()
      case VariantType.LocalizedText:
        return this.localizedText()
      case VariantType.ExtensionObject:
        return this.extensionObject()
      case VariantType.DataValue:
        return this.dataValue()
      case VariantType.Variant:
        return this.variant()
      case VariantType.DiagnosticInfo:
        return this.diagnosticInfo()
      default:
        throw new OpcuaError(StatusCode.BadDecodingError)
    }
  }

  variant (): Variant {
    const type = this.bit(7)
    const isArray = this.bit(1)
    let value
    if (isArray === 1) {
      const arrLen = this.int32()
      if (arrLen !== 0xFFFFFFFF) {
        value = new Array(arrLen)
        for (let i = 0; i < arrLen; i++)
          value[i] = this.decodeVariantValue(type)
      }
    } else {
      value = this.decodeVariantValue(type)
    }

    return new Variant(value, type)
  }

  extensionObject (): ExtensionObject {
    const typeId = this.nodeId()
    const isBinary = this.bit(1)
    this.bit(7) // reserved bits
    let body: Uint8Array | Record<string, unknown> | null = null
    if (isBinary !== 0) {
      const node = ns0[typeId.toString()]
      if (node !== undefined) {
        // Position where size of body stored
        this.uint32()
        body = this.decodeStructure(typeId.toString())
      } else {
        body = this.byteString()
      }
    }
    return new ExtensionObject(typeId, body)
  }

  decodeStructure (nodeId: string): Record<string, unknown> {
    const node = ns0[nodeId]
    if (node === undefined || node.Definition === undefined) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    const obj: Record<string, unknown> = {}

    for (const d of node.Definition) {

      const field = d as ns.StructField
      if (field.ValueRank === 1) {
        const len = this.uint32()
        let arr: unknown[] | null = null
        if (len !== 0xFFFFFFFF) {
          arr = new Array(len)
          for (let i = 0; i < len; i++) {
            if (field.DataTypeId == "i=22") {
              arr[i] = this.extensionObject()
            } else {
              arr[i] = this.decodeValue(field.BaseTypeId, field.DataTypeId)
            }
          }
        }
        obj[field.Name] = arr
      } else {
        if (field.DataTypeId == "i=22") {
          obj[field.Name] = this.extensionObject()
        } else {
          obj[field.Name] = this.decodeValue(field.BaseTypeId, field.DataTypeId)
        }
      }
    }

    return obj
  }

  decodeResponse(): ExtensionObject {
    const typeId = this.nodeId()
    const node = ns0[typeId.toString()]
    if (node === undefined) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }
    if (node.BinaryId === undefined) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }
    const obj = this.decodeStructure(typeId.toString())
    return new ExtensionObject(node.Attributes[0]?.Value as NodeId, obj)
  }

  decodeValue(dataTypeId: string, typeId: string) {
    switch (dataTypeId) {
    case "i=1": return this.boolean();
    case "i=2": return this.int8();
    case "i=3": return this.uint8();
    case "i=4": return this.uint16();
    case "i=5": return this.uint16();
    case "i=6": return this.int32();
    case "i=7": return this.uint32();
    case "i=8": return this.int64();
    case "i=9": return this.uint64();
    case "i=10": return this.float();
    case "i=11": return this.double();
    case "i=13": return this.dateTime();
    case "i=294": return this.dateTime();
    case "i=12": return this.string();
    case "i=14": return this.guid();
    case "i=15": return this.byteString();
    case "i=16": return this.xmlElement();
    case "i=17": return this.nodeId();
    case "i=18": return this.expandedNodeId();
    case "i=19": return this.statusCode();
    case "i=20": return this.qualifiedName();
    case "i=21": return this.localizedText();
    case "i=22": return this.decodeStructure(typeId);
    case "i=23": return this.dataValue();
    case "i=25": return this.diagnosticInfo();
    case "i=29": return this.uint32();
    default:
      throw new OpcuaError(StatusCode.BadDecodingError)
    }
  }
}

export { BinaryDecoder }
