import { OpcuaError, ExtensionObject, NodeId, Guid, QualifiedName, Variant, VariantType, LocalizedText, DataValue, DiagnosticInfo, getDebugTrace, VariantArrayTypes, VariantScalarTypes } from './types'
import { StatusCode } from './status_codes'
import * as ns from "./nodeset"
import ns0 from "./ns0"


// function filetimeToTimeT (fileTime: bigint): number {
//   const windowsEpochMs = 11644473600000n // 1970-01-01T00:00:00.000Z
//   const ms = fileTime / 10000n - windowsEpochMs
//   let result = Number(ms)
//   if (ms === 0n) { result += 0.1 }
//   return result
// }

class JsonDecoder {
  private stack: unknown[] = []
  public data: string

  constructor (buffer: string | ArrayBuffer) {
    this.data = buffer instanceof ArrayBuffer ? new TextDecoder().decode(buffer) : buffer
    this.init()
  }

  boolean (): boolean {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'boolean') {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    return value
  }

  int8(): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int8 expected')
    }
    if (value < -128 || value > 127) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int8 out of range')
    }

    return value
  }

  sbyte = this.int8

  uint8 (): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt8 expected')
    }
    if (value < 0 || value > 255) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt8 out of range')
    }

    return value
  }

  byte = this.uint8

  int16(): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int16 expected')
    }
    if (value < -32768 || value > 32767) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int16 out of range')
    }

    return value
  }

  uint16(): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt16 expected')
    }
    if (value < 0 || value > 65535) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt16 out of range')
    }

    return value
  }

  int32(): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int32 expected')
    }
    if (value < -2147483648 || value > 2147483647) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int32 out of range')
    }

    return value
  }

  uint32(): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt32 expected')
    }
    if (value < 0 || value > 4294967295) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt32 out of range')
    }

    return value
  }

  statusCode(): OpcuaError {
    const value = this.stack[this.stack.length - 1]
    let code: number = 0
    let symbol: string | null = null

    if (typeof value === 'number') {
      if (value < 0 || value > 4294967295) {
        throw new OpcuaError(StatusCode.BadDecodingError, 'UInt32 out of range')
      }
      code = value
    } else if (typeof value === 'object') {
      const obj = value as { Code: number, Symbol: string }
      this.stack.push(obj.Code)
      code = this.uint32()
      this.stack.pop()
      this.stack.push(obj.Symbol)
      symbol = this.string()
      this.stack.pop()
    } else {
      throw new OpcuaError(StatusCode.BadDecodingError, 'StatusCode invalid')
    }

    return new OpcuaError(code, symbol == null ? undefined : symbol);
  }

  int64(): bigint {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'bigint' && typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int64 expected')
    }
    if (value < -Number.MAX_SAFE_INTEGER || value > Number.MAX_SAFE_INTEGER) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'Int64 out of range')
    }

    return BigInt(value)
  }

  uint64(): bigint {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'bigint' && typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt64 expected')
    }
    if (value < 0 || value > Number.MAX_SAFE_INTEGER) {
      throw new OpcuaError(StatusCode.BadDecodingError, 'UInt64 out of range')
    }

    return BigInt(value)
  }

  float(): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'number') {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    return value
  }

  double = this.float

  dateTime(): number {
    const value = this.stack[this.stack.length - 1]
    if (typeof value !== 'string') {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    return Date.parse(value)
  }

  charArray(): string | null {
    const val = this.stack[this.stack.length - 1]
    if (val === null) {
      return null
    }
    if (typeof val !== 'string') {
      throw new OpcuaError(StatusCode.BadDecodingError, `String expected instead '${typeof val}'`)
    }

    return val
  }

  string = this.charArray

  byteString (): Uint8Array | null {
    const str = this.string()
    if (str === null) {
      return null
    }

    //Decode base64 string to UInt8Array
    const binary = atob(str)
    const len = binary.length
    const bytes = new Uint8Array(len)
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i)
    }
    return bytes
  }

  guid(): Guid {
    const val = this.string()
    if (val === null) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    return new Guid(val)
  }

  nodeId(): NodeId {
    const nodeObj = this.stack[this.stack.length - 1] as { IdType: number, Id: string, NamespaceIndex: number, NamespaceUri: string, ServerIndex: number }

    let IdType = 0
    if ("IdType" in nodeObj) {
      IdType = nodeObj.IdType
    }

    if (!("Id" in nodeObj)) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    this.stack.push(nodeObj.Id)

    let id: string
    if (IdType === 0) { // NodeIdType.Numeric
      const i = this.uint32()
      id = "i=" + i.toString()
    } else if (IdType === 1) { // NodeIdType.String
      const str = this.string()
      id = "s=" + str
    } else if (IdType === 2) { // NodeIdType.Guid
      const guid = this.guid()
      id = "g=" + guid.toString()
    } else if (IdType === 3) { // NodeIdType.Opaque
      const bytes = this.string()
      id = "b=" + bytes
    } else {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    this.stack.pop()

    if ("NamespaceIndex" in nodeObj) {
      this.stack.push(nodeObj.NamespaceIndex)
      id = "ns=" + this.uint16() + ";" + id
      this.stack.pop()
    }

    if ("NamespaceUri" in nodeObj) {
      this.stack.push(nodeObj.NamespaceUri)
      const nsUri = this.string()
      id = "nsu=" + nsUri + ";" + id
      this.stack.pop()
    }

    if ("ServerIndex" in nodeObj) {
      this.stack.push(nodeObj.ServerIndex)
      id = "si=" + this.uint32() + ";" + id
      this.stack.pop()
    }

    return new NodeId(id)
  }

  expandedNodeId = this.nodeId

  qualifiedName(): QualifiedName {
    const obj = this.stack[this.stack.length - 1] as { Name: string, NamespaceIndex: number }
    if (!("Name" in obj)) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    let ns = 0
    if ("NamespaceIndex" in obj) {
      this.stack.push(obj.NamespaceIndex)
      ns = this.uint16()
      this.stack.pop()
    }

    this.stack.push(obj.Name)
    const name = this.string()
    this.stack.pop()

    return new QualifiedName(ns, name)
  }

  // xmlElement (): XmlElement {
  //   const length = this.int32()
  //   let value = null
  //   if (length !== -1) {
  //     value = this.str(length)
  //   }
  //   return new XmlElement({
  //     value
  //   })
  // }

  localizedText (): LocalizedText {
    const obj = this.stack[this.stack.length - 1] as { Text: string, Locale: string }
    if (!("Text" in obj)) {
      throw new OpcuaError(StatusCode.BadDecodingError, "Text field not found")
    }

    this.stack.push(obj.Text)
    const text = this.string()
    this.stack.pop()

    let locale: string | null = null
    if ("Locale" in obj) {
      this.stack.push(obj.Locale)
      locale = this.string()
      this.stack.pop()
    }

    return new LocalizedText(text, locale)
  }

  dataValue (): DataValue {
    const obj = this.stack[this.stack.length - 1] as { Value: unknown, StatusCode: number, SourceTimestamp: number, ServerTimestamp: number, SourcePicoseconds: number, ServerPicoseconds: number }
    let value
    if ("Value" in obj) {
      this.stack.push(obj.Value)
      value = this.variant()
      this.stack.pop()
    }
    let statusCode
    if ("StatusCode" in obj) {
      this.stack.push(obj.StatusCode)
      statusCode = this.statusCode()
      this.stack.pop()
    }
    let sourceTimestamp
    if ("SourceTimestamp" in obj) {
      this.stack.push(obj.SourceTimestamp)
      sourceTimestamp = this.dateTime()
      this.stack.pop()
    }
    let serverTimestamp
    if ("ServerTimestamp" in obj) {
      this.stack.push(obj.ServerTimestamp)
      serverTimestamp = this.dateTime()
      this.stack.pop()
    }
    let sourcePicoseconds
    if ("SourcePicoseconds" in obj) {
      this.stack.push(obj.SourcePicoseconds)
      sourcePicoseconds = this.uint16()
      this.stack.pop()
    }
    let serverPicoseconds
    if ("ServerPicoseconds" in obj) {
      this.stack.push(obj.ServerPicoseconds)
      serverPicoseconds = this.uint16()
      this.stack.pop()
    }

    return new DataValue(
      value, statusCode,
      sourceTimestamp, serverTimestamp,
      sourcePicoseconds, serverPicoseconds)
  }

  diagnosticInfo(): DiagnosticInfo {
    const obj = this.stack[this.stack.length - 1] as { SymbolicId: number, NamespaceUri: number, Locale: number, LocalizedText: number, AdditionalInfo: string, InnerStatusCode: number, InnerDiagnosticInfo: DiagnosticInfo }
    let symbolicId
    if ("SymbolicId" in obj) {
      this.stack.push(obj.SymbolicId)
      symbolicId = this.int32()
      this.stack.pop()
    }
    let namespaceURI
    if ("NamespaceUri" in obj) {
      this.stack.push(obj.NamespaceUri)
      namespaceURI = this.int32()
      this.stack.pop()
    }
    let locale
    if ("Locale" in obj) {
      this.stack.push(obj.Locale)
      locale = this.int32()
      this.stack.pop()
    }
    let localizedText
    if ("LocalizedText" in obj) {
      this.stack.push(obj.LocalizedText)
      localizedText = this.int32()
      this.stack.pop()
    }
    let additionalInfo: string | undefined = undefined
    if ("AdditionalInfo" in obj) {
      this.stack.push(obj.AdditionalInfo)
      const str = this.string()
      if (str !== null) {
        additionalInfo = str
      }
      this.stack.pop()
    }
    let innerStatusCode
    if ("InnerStatusCode" in obj) {
      this.stack.push(obj.InnerStatusCode)
      innerStatusCode = this.statusCode()
      this.stack.pop()
    }
    let innerDiagnosticInfo
    if ("InnerDiagnosticInfo" in obj) {
      this.stack.push(obj.InnerDiagnosticInfo)
      innerDiagnosticInfo = this.diagnosticInfo()
      this.stack.pop()
    }
    return new DiagnosticInfo(
      symbolicId,
      namespaceURI,
      localizedText,
      locale,
      additionalInfo,
      innerStatusCode,
      innerDiagnosticInfo
    )
  }

  decodeVariantValue(type: number): VariantScalarTypes {
    switch (type) {
      case VariantType.Null:
        return new Variant()
      case VariantType.Boolean:
        return this.boolean()
      case VariantType.SByte:
        return this.int8()
      case VariantType.Byte:
        return this.uint8()
      case VariantType.Int16:
        return this.int16()
      case VariantType.UInt16:
        return this.uint16()
      case VariantType.Int32:
        return this.int32()
      case VariantType.UInt32:
        return this.uint32()
      case VariantType.Int64:
        return this.int64()
      case VariantType.UInt64:
        return this.uint64()
      case VariantType.Float:
        return this.float()
      case VariantType.Double:
        return this.double()
      case VariantType.String:
        return this.string()
      case VariantType.DateTime:
        return this.dateTime()
      case VariantType.Guid:
        return this.guid()
      case VariantType.ByteString:
        return this.byteString()
      case VariantType.NodeId:
        return this.nodeId()
      case VariantType.ExpandedNodeId:
        return this.expandedNodeId()
      case VariantType.StatusCode:
        return this.statusCode()
      case VariantType.QualifiedName:
        return this.qualifiedName()
      case VariantType.LocalizedText:
        return this.localizedText()
      case VariantType.ExtensionObject:
        return this.extensionObject()
      case VariantType.DataValue:
        return this.dataValue()
      case VariantType.Variant:
        return this.variant()
      // case VariantType.DiagnosticInfo:
      //   decF = this.diagnosticInfo
      //   typeName = "DiagnosticInfo"
      //   break
      default:
        throw new OpcuaError(StatusCode.BadDecodingError)
    }
  }

  variant(): Variant {
    const obj = this.stack[this.stack.length - 1] as { Type: number, Body: unknown }
    if (!("Type" in obj)) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    if (!("Body" in obj)) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    const body = obj.Body
    if (body instanceof Array) {
      const arrLen = body.length
      const value: VariantArrayTypes = []
      for (let i = 0; i < arrLen; i++) {
        this.stack.push(body[i])
        const v = this.decodeVariantValue(obj.Type)
        this.stack.pop()
        value.push(v)
      }
      return new Variant(value, obj.Type)
    } else {
      this.stack.push(body)
      const value: VariantScalarTypes = this.decodeVariantValue(obj.Type)
      this.stack.pop()
      return new Variant(value, obj.Type)
    }
  }

  init(): void {
    if (this.stack.length === 0) {
      if (typeof this.data === 'string') {
        if (getDebugTrace())
          console.log(`Parsing JSON: ${this.data}`)
        this.stack.push(JSON.parse(this.data))
      } else {
        let str: string = ""
        try {
          str = new TextDecoder().decode(this.data)
          if (getDebugTrace())
            console.log(`Parsing JSON: ${str}`)

          const obj = JSON.parse(str)
          this.stack.push(obj)
        } catch (e) {
          const str = new TextDecoder().decode(this.data)
          console.log(str)
          throw new OpcuaError(StatusCode.BadDecodingError, "Failed to parse JSON" + (e instanceof Error ? e.message : String(e)) + " at " + str)
        }
      }
    }
  }

  extensionObject(): ExtensionObject {
    this.init()

    const object = this.stack[this.stack.length - 1] as { TypeId: NodeId | string, Encoding: number, Body: unknown }

    this.stack.push(object.TypeId)
    const jsonTypeId = this.nodeId()
    let typeId = jsonTypeId.toString()
    this.stack.pop()
    if (typeId === "i=0") {
      return new ExtensionObject(typeId, null)
    }

    const node = ns0[typeId]
    if (node !== undefined && node.Attributes.length) {
      const attr = node.Attributes[0]
      if (attr !== undefined && attr.Id === 1 && attr.Value !== null) {
        typeId = attr.Value.toString()
      } else {
        throw new OpcuaError(StatusCode.BadDecodingError, `ExtensionObject typeId is not a NodeId: ${typeId}`)
      }
    }

    let body
    if (object.Encoding === 0) {
      this.stack.push(object.Body)
      if (node !== undefined) {
        body = this.decodeStructure(typeId)
      } else {
        body = this.byteString()
      }
      this.stack.pop()
    }
    return new ExtensionObject(typeId, body)
  }

  decodeStructure (nodeId: string): Record<string, unknown> {
    const node = ns0[nodeId]
    if (node === undefined || node.Definition === undefined) {
      throw new OpcuaError(StatusCode.BadDecodingError)
    }

    const obj = this.stack[this.stack.length - 1] as Record<string, unknown>

    for (const d of node.Definition) {

      const field = d as ns.StructField
      if (getDebugTrace())
        console.log(`Decoding field '${field.Name}'`)

      const val = obj[field.Name]
      this.stack.push(val)

      if (field.ValueRank === 1) {
        const arr: (Record<string, unknown> | ExtensionObject | VariantScalarTypes)[] = []
        if (val !== null) {
          if (!(val instanceof Array)) {
            throw new OpcuaError(StatusCode.BadDecodingError)
          }

          for (let i = 0; i < val.length; i++) {
            if (getDebugTrace())
              console.log(`Decoding array element ${i}`)

            this.stack.push(val[i])

            let v: Record<string, unknown> | ExtensionObject | VariantScalarTypes
            if (field.DataTypeId == "i=22") {
              v = this.extensionObject()
            } else {
              v = this.decodeValue(field.BaseTypeId, field.DataTypeId)
            }

            arr.push(v)
            this.stack.pop()
          }
        }
        obj[field.Name] = arr
      } else {
        if (field.DataTypeId == "i=22") {
          obj[field.Name] = this.extensionObject()
        } else {
          obj[field.Name] = this.decodeValue(field.BaseTypeId, field.DataTypeId)
        }
      }

      this.stack.pop()
    }

    return obj
  }

  decodeResponse = this.extensionObject

  decodeValue(baseTypeId: string, dataTypeId: string) {
    switch (baseTypeId) {
    case "i=1": return this.boolean();
    case "i=2": return this.int8();
    case "i=3": return this.uint8();
    case "i=4": return this.uint16();
    case "i=5": return this.uint16();
    case "i=6": return this.int32();
    case "i=7": return this.uint32();
    case "i=8": return this.int64();
    case "i=9": return this.uint64();
    case "i=10": return this.float();
    case "i=11": return this.double();
    case "i=13": return this.dateTime();
    case "i=294": return this.dateTime();
    case "i=12": return this.string();
    case "i=14": return this.guid();
    case "i=15": return this.byteString();
    // case "i=16": return this.xmlElement();
    case "i=17": return this.nodeId();
    case "i=18": return this.expandedNodeId();
    case "i=19": return this.statusCode();
    case "i=20": return this.qualifiedName();
    case "i=21": return this.localizedText();
    case "i=22": return this.decodeStructure(dataTypeId);
    case "i=23": return this.dataValue();
    case "i=25": return this.diagnosticInfo();
    case "i=29": return this.uint32();
    default:
      throw new OpcuaError(StatusCode.BadDecodingError)
    }
  }
}

export { JsonDecoder }
