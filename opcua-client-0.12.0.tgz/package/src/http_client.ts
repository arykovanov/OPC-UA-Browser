import {
  ApplicationType,
  BrowseDirection,
  BrowseResultMask,
  NodeClass,
  MessageSecurityMode,
  UserTokenType

} from './enums'
import * as types from './types'
import { NodeIDs } from './node_ids'
import { StatusCode } from './status_codes'
import { ActivateSessionData, ApplicationDescription, BrowseData, CreateSessionData, CreateSessionRequest, CreateSessionResponse, EndpointDescription, FindServersData, FindServersResponse, GetEndpointsData, ReadData, RequestHeader, ResponseHeader} from './types'
import { ExtensionObject, UserTokenPolicy } from './types'

import { UaClient } from './opcua_client'

import { BinaryEncoder } from './binary_encoder'
import { BinaryDecoder } from './binary_decoder'

import { JsonEncoder } from './json_encoder'
import { JsonDecoder } from './json_decoder'

function createAnonymousToken (policyId: string): ExtensionObject {
  return {
    TypeId: 'i=321',
    Body: {
      PolicyId: policyId
    }
  }
}

function createUsernameToken(policyId: string, username: string, password: string) {
  return {
    TypeId: "i=324",
    Body: {
      PolicyId: policyId,
      UserName: username,
      Password: password,
      EncryptionAlgorithm: null
    }
  }
}

function createX509Token(policyId: string, cert: Uint8Array|string) {
  return {
    TypeId: "i=327",
    Body: {
      PolicyId: policyId,
      CertificateData: cert
    }
  }
}

function createIdentityToken(tokenPolicy: UserTokenPolicy, identity?: string, secret?: Uint8Array|string): ExtensionObject {
  switch (tokenPolicy.TokenType) {
    case UserTokenType.Anonymous: {
      return createAnonymousToken(tokenPolicy.PolicyId);
    }
    case UserTokenType.UserName: {
      if (identity == undefined)
        throw new types.OpcuaError(StatusCode.BadIdentityTokenInvalid, "Username empty");
      if (typeof secret != 'string')
        throw new types.OpcuaError(StatusCode.BadIdentityTokenInvalid, "User password empty");

      return createUsernameToken(tokenPolicy.PolicyId, identity, secret);
    }
    case UserTokenType.Certificate: {
      if (secret == undefined)
        throw new types.OpcuaError(StatusCode.BadIdentityTokenInvalid, "Invalid user certificate");

      return createX509Token(tokenPolicy.PolicyId, secret);
    }
    default:
      throw new types.OpcuaError(StatusCode.BadIdentityTokenInvalid, `Invalid token type ${tokenPolicy.TokenType}`);
  }
}

type BrowseParams = {
  NodeId: string
  BrowseDirection: BrowseDirection
  ReferenceTypeId: string
  NodeClassMask: NodeClass
  ResultMask: BrowseResultMask
  IncludeSubtypes: boolean
}

function browseParams (nodeId: string): BrowseParams {
  return {
    NodeId: nodeId, // nodeId we want to browse
    BrowseDirection: BrowseDirection.Forward,
    ReferenceTypeId: 'i=33', // HierarchicalReferences,
    NodeClassMask: NodeClass.Unspecified,
    ResultMask: BrowseResultMask.All,
    IncludeSubtypes: true
  }
}

type Session = {
  authToken: types.NodeId
  sessionId: types.NodeId
  userIdentityTokens: UserTokenPolicy[]
  serverCertificate: Uint8Array | null
  nonce: Uint8Array | null
}

type ReadParams = {
  NodeId: string
  AttributeId: number
  IndexRange: string
  DataEncoding: types.QualifiedName
}

export class UaHttpClient implements UaClient {
  private readonly LogID: string = 'opcua-' + Math.floor(Math.random() * 1000000).toString()
  private requestHandle: number = 0
  private readonly timoutHint: number = 10000
  private endpointUrl: string = ''
  private siteUrl: string = ''
  private transportProfileUri: string = ''
  private encoderType: JsonEncoder | BinaryEncoder | undefined
  private mime: string = ''
  private readonly buffer: ArrayBuffer = new ArrayBuffer(65536)
  private securityPolicyUri: string = types.SecurePolicyUri.None
  private securityMode: number = MessageSecurityMode.None
  private session: Session = {
    authToken: new types.NodeId(),
    sessionId: new types.NodeId(),
    userIdentityTokens: [],
    serverCertificate: null,
    nonce: null
  }

  private createRequestHeader (): RequestHeader {
    return {
      AuthenticationToken: this.session.authToken,
      Timestamp: new Date().getTime(),
      RequestHandle: this.requestHandle++,
      ReturnDiagnostics: 0,
      AuditEntryId: '',
      TimeoutHint: this.timoutHint,
      AdditionalHeader: {
        TypeId: new types.NodeId('i=0')
      }
    }
  }


  private createApplicationDescription (): ApplicationDescription {
    return {
      ApplicationUri: 'urn:realtimelogic:opcua:client:http',
      ProductUri: 'http://realtimelogic.com',
      ApplicationName: new types.LocalizedText('Real Time Logic OPC UA HTTP Client', 'en'),
      ApplicationType: ApplicationType.Client,
      GatewayServerUri: null,
      DiscoveryProfileUri: null,
      DiscoveryUrls: []
    }
  }

  private async execRequest (
    request: Record<string, unknown>,
    requestTypeId: types.NodeId | string,
    responseTypeId: types.NodeId | string
  ): Promise<ExtensionObject> {

    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Processing requestID:'${requestTypeId}' responseID:'${responseTypeId}'`)
    }

    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Encoding request:'${request}'`)
    }


    if (this.transportProfileUri === types.TransportProfile.HttpsBinary) {
      this.encoderType = new BinaryEncoder(this.buffer)
      this.mime = 'application/octet-stream'
    } else if (this.transportProfileUri === types.TransportProfile.HttpsJson) {
      this.encoderType = new JsonEncoder(this.buffer)
      this.mime = 'application/opcua+uajson'
    } else {
      throw new Error(`Transport profile '${this.transportProfileUri}'not supported`)
    }

    const encoder = this.encoderType
    if (!encoder) {
      throw new Error('Encoder not initialized')
    }

    encoder.encodeRequest(requestTypeId, new ExtensionObject(requestTypeId, request))

    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Sending request '${requestTypeId}'`)
    }

    const response = await fetch(this.siteUrl, {
      method: "POST",
      mode: 'cors',
      headers: {
        'Content-Type': this.mime,
        'OPCUA-SecurityPolicy': types.SecurePolicyUri.None
      },
      // Cannot convert ArrayBuffer to string
      body: encoder.data as BodyInit
    })

    if (!response.ok) {
      if (types.getDebugTrace()) {
        console.log(`${this.LogID} | Error: '${response.statusText}'`)
      }

      throw new types.OpcuaError(StatusCode.BadUnknownResponse, response.statusText)
    }

    const body = await response.arrayBuffer()
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Decoding response`)
    }

    let decoder

    if (this.transportProfileUri === types.TransportProfile.HttpsBinary) {
      decoder = new BinaryDecoder(body)
    } else if (this.transportProfileUri === types.TransportProfile.HttpsJson) {
      decoder = new JsonDecoder(body)
    } else {
      throw new Error(`Transport profile '${this.transportProfileUri}'not supported`)
    }

    const resp: types.ExtensionObject = decoder.decodeResponse()

    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Response Data'${resp}'`)
    }

    const responseBody = resp.Body as Record<string, unknown>
    if (responseBody === null) {
      throw new types.OpcuaError(StatusCode.BadUnknownResponse, 'Response body is null')
    }

    const responseHeader = responseBody.ResponseHeader as ResponseHeader
    if (resp.TypeId.toString() !== responseTypeId.toString()) {
      if (resp.TypeId.toString() === 'i=395') {
        if (types.getDebugTrace()) {
          console.log(`${this.LogID} | SERVICE FAULT: '${responseHeader.toString()}`)
        }
        throw responseHeader?.ServiceResult
      }

      const msg = `Response type id '${resp.TypeId.toString()}' instead of '${responseTypeId.toString()}'`
      if (types.getDebugTrace()) {
        console.log(`${this.LogID} | ${msg}`)
      }

      throw new types.OpcuaError(StatusCode.BadRequestTypeInvalid, msg)
    }

    if (responseHeader.ServiceResult.Code !== StatusCode.Good) {
      if (types.getDebugTrace()) {
        console.log(`${this.LogID} | Response result '${responseHeader.toString()}`)
      }
      throw responseHeader.ServiceResult
    }

    if (resp.Body === null) {
      throw new types.OpcuaError(StatusCode.BadUnknownResponse, 'Response body is null')
    }

    return resp
  }

  async hello (endpointUrl: string, transportProfileUri: string | null = null): Promise<void> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Hello endpointUrl='${endpointUrl}'`)
      }

    if (transportProfileUri === null) {
      transportProfileUri = types.TransportProfile.HttpsBinary
    }

    if (transportProfileUri === types.TransportProfile.HttpsBinary) {
      this.encoderType = new BinaryEncoder(this.buffer)
      this.mime = 'application/octet-stream'
    } else if (transportProfileUri === types.TransportProfile.HttpsJson) {
      this.encoderType = new JsonEncoder(this.buffer)
      this.mime = 'application/opcua+uajson'
    } else {
      throw new Error(`Transport profile '${transportProfileUri}'not supported`)
    }

    this.endpointUrl = endpointUrl
    this.siteUrl = endpointUrl.replace('opc.http', 'http')
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | UaHttpClient: Site URL='${this.endpointUrl}', Transport profile='${this.transportProfileUri}'`)
    }

    this.transportProfileUri = transportProfileUri
  }

  async openSecureChannel (_: number, securityPolicyUri: string, securityMode: number): Promise<void>{
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | OpenSecureChannel securityPolicyUri='${securityPolicyUri}' securityMode='${securityMode}'`)
    }

    this.securityPolicyUri = securityPolicyUri
    this.securityMode = securityMode
  }

  async closeSecureChannel (): Promise<void> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | CloseSecureChannel`)
    }
  }

  async createSession (sessionName: string, timeoutMs: number): Promise<CreateSessionData> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | CreateSession sessionName='${sessionName}' timeoutMs='${timeoutMs}'`)
    }

    const request: CreateSessionRequest = {
      RequestHeader: this.createRequestHeader(),
      ClientDescription: this.createApplicationDescription(),
      ServerUri: '',
      EndpointUrl: this.endpointUrl,
      SessionName: sessionName,
      ClientNonce: null,
      ClientCertificate: null,
      RequestedSessionTimeout: timeoutMs,
      MaxResponseMessageSize: 0
    }

    const response = await this.execRequest(request, NodeIDs.CreateSessionRequest, NodeIDs.CreateSessionResponse)

    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Searching for endpoint ='${this.endpointUrl}', securityPolicyUri='${this.securityPolicyUri}' securityMode='${this.securityMode}'`)
    }

    if (response.Body === null) {
      throw new types.OpcuaError(StatusCode.BadUnknownResponse, 'Response body is null')
    }

    const createSessionResponse = response.Body as CreateSessionResponse
    const serverEndpoints = createSessionResponse.ServerEndpoints

    let endpoint: EndpointDescription | undefined = undefined
    // search current policy
    for (let i = 0; i < serverEndpoints.length; ++i) {
      const e = serverEndpoints[i]

      if (types.getDebugTrace()) {
        console.log(`${this.LogID} |   Server endpoint ='${e?.EndpointUrl}', securityPolicyUri='${e?.SecurityPolicyUri}' securityMode='${e?.SecurityMode}'`)
      }

      if (e?.EndpointUrl === this.endpointUrl && e?.SecurityPolicyUri === this.securityPolicyUri && e?.SecurityMode === this.securityMode) {
        endpoint = e
        break
      }
    }

    if (endpoint === undefined) {
      throw new Error(`Endpoint not found for '${this.endpointUrl}'`)
    }

    this.session.authToken = createSessionResponse.AuthenticationToken as types.NodeId
    this.session.sessionId = createSessionResponse.SessionId
    this.session.nonce = createSessionResponse.ServerNonce as Uint8Array | null
    this.session.userIdentityTokens = endpoint.UserIdentityTokens as UserTokenPolicy[]
    this.session.serverCertificate = endpoint.ServerCertificate as Uint8Array | null

    return createSessionResponse as CreateSessionData
  }

  async activateSession (tokenPolicy: UserTokenPolicy, identity?: string, secret?: Uint8Array|string): Promise<ActivateSessionData> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | ActivateSession tokenPolicy='${tokenPolicy}' identity='${identity}'`)
    }

    const activateParams = {
      RequestHeader: this.createRequestHeader(),
      ClientSignature: {
        Algorithm: '',
        Signature: null
      },
      ClientSoftwareCertificates: null,
      LocaleIds: null,
      UserIdentityToken: createIdentityToken(tokenPolicy, identity, secret),
      UserTokenSignature: {
        Algorithm: '',
        Signature: null
      }
    }

    const response = await this.execRequest(activateParams, NodeIDs.ActivateSessionRequest, NodeIDs.ActivateSessionResponse)
    return response.Body as ActivateSessionData
  }

  async closeSession (): Promise<void> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | CloseSession`)
    }

    const request = {
      RequestHeader: this.createRequestHeader(),
      DeleteSubscriptions: true
    }

    await this.execRequest(request, NodeIDs.CloseSessionRequest, NodeIDs.CloseSessionResponse)

    this.session.authToken = new types.NodeId('i=0')
  }

  async getEndpoints (endpointUrl: string | null = null): Promise<GetEndpointsData> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | GetEndpoints encpointUrl='${endpointUrl}'`)
    }

    const request = {
      RequestHeader: this.createRequestHeader(),
      EndpointUrl: endpointUrl,
      LocaleIds: null,
      ProfileUris: null
    }

    const response = await this.execRequest(request, NodeIDs.GetEndpointsRequest, NodeIDs.GetEndpointsResponse)
    return response.Body as GetEndpointsData
  }

  async findServers (endpointUrl: string | undefined = undefined, serverUris?: string[]): Promise<FindServersData> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | FindServers encpointUrl='${endpointUrl}' serverUris='${serverUris}'`)
    }

    const request = {
      RequestHeader: this.createRequestHeader(),
      EndpointUrl: endpointUrl,
      LocaleIds: null,
      ServerUris: serverUris
    }

    const response = await this.execRequest(request, NodeIDs.FindServersRequest, NodeIDs.FindServersResponse)
    return response.Body as FindServersResponse
  }

  async browse (nodeId: string | string[] | types.NodeId | types.NodeId[]): Promise<BrowseData> {
    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Browse '${nodeId}'`)
    }

    const request = {
      RequestHeader: this.createRequestHeader(),
      NodesToBrowse: [],
      RequestedMaxReferencesPerNode: 1000,
      View: {
        ViewId: 'i=0',
        Timestamp: 0, // not specified ~1600 year
        ViewVersion: 0
      }
    }

    // single node ID
    if (typeof nodeId === 'string' || nodeId instanceof types.NodeId) {
      // @ts-expect-error ssdsdsd sdsd
      request.NodesToBrowse.push(browseParams(nodeId))
    } else if (nodeId instanceof Array) {
      // array of nodeIDs
      for (let i = 0; i < nodeId.length; ++i) {
      // @ts-expect-error sdfsdfdfsf
        request.NodesToBrowse.push(browseParams(nodeId[i]))
      }
    } else {
      throw new Error('Invalid node id')
    }

    const response = await this.execRequest(request, NodeIDs.BrowseRequest, NodeIDs.BrowseResponse)
    return response.Body as BrowseData
  }

  private allAttributes (nodeId: string): ReadParams[] {
    const attrs = []
    for (let i = 1; i <= 27; ++i) {
      attrs.push({
        NodeId: nodeId,
        AttributeId: i,
        IndexRange: '',
        DataEncoding: new types.QualifiedName()
      })
    }
    return attrs
  }

  async read(nodeId: string | string[] | types.NodeId | types.NodeId[]): Promise<ReadData> {

    if (types.getDebugTrace()) {
      console.log(`${this.LogID} | Read '${nodeId}'`)
    }

    const request = {
      RequestHeader: this.createRequestHeader(),
      TimestampsToReturn: 0,
      MaxAge: 0,
      NodesToRead: []
    }

    if (typeof nodeId === 'string' || nodeId instanceof types.NodeId) {
      // @ts-expect-error sdfsdfs sdf sdf
      request.NodesToRead.push(...this.allAttributes(nodeId))
    } else if (nodeId instanceof Array) {
      for (let i = 0; i < nodeId.length; ++i) {
        // @ts-expect-error sdada asd asd asd
        request.NodesToRead.push(...this.allAttributes(nodeId[i]))
      }
    } else {
      throw new Error('Invalid node id')
    }

    const response = await this.execRequest(request, NodeIDs.ReadRequest, NodeIDs.ReadResponse)
    return response.Body as ReadData
  }
}
