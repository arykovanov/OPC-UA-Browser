import { StatusCode } from './status_codes'
import { ApplicationType, NodeClass, TimestampsToReturn, UserTokenType } from './enums'

export class OpcuaError extends Error {
  readonly Code: number = StatusCode.Good

  constructor(code: StatusCode, message: string | undefined = undefined) {
    super(message)
    this.Code = code
  }

  override toString(): string {
    if (this.message === undefined || this.message === null) {
      return `0x${this.Code.toString(16)}`
    }

    return `0x${this.Code.toString(16)} (${this.message})`
  }
}

export class Guid {
  private value: string

  constructor (str: string | undefined = undefined) {
    if (str === undefined) {
      this.value = '00000000-0000-0000-0000-000000000000'
    } else if (typeof str === 'string') {
      // UUID format regex: 8-4-4-4-12 hexadecimal digits
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
      if (!uuidRegex.test(str)) {
        throw new OpcuaError(StatusCode.BadEncodingError, 'Invalid UUID format')
      }
      this.value = str.toLowerCase()
    } else {
      throw new OpcuaError(StatusCode.BadEncodingError, 'Guid constructor only accepts string or undefined')
    }
  }

  toString(): string {
    return this.value
  }
}

function base64ToBytes (base64: string): Uint8Array {
  const binString = atob(base64)
  /// @ts-expect-error it works but typescript doesn't like it
  return Uint8Array.from(binString, m => m.codePointAt(0))
}

// function bytesToBase64 (bytes: Uint8Array): string {
//   const binString = Array.from(bytes, (x) => String.fromCodePoint(x)).join('')
//   return btoa(binString)
// }

export class NodeId {
  private value: string

  constructor(val: string | undefined = undefined) {
    if (val === undefined)
      val = 'i=0'

    if (typeof val !== 'string') {
      throw new OpcuaError(StatusCode.BadEncodingError, 'NodeId constructor only accepts string')
    }

    // Validate OPC UA NodeId string format
    const parts = val.split(';')
    let hasValidPart = false

    for (const part of parts) {
      if (part.startsWith('ns=')) {
        const ns = parseInt(part.substring(3))
        if (isNaN(ns) || ns < 0 || ns > 0xFF) {
          throw new OpcuaError(StatusCode.BadEncodingError, 'Invalid namespace index')
        }
        hasValidPart = true
      } else if (part.startsWith('nsu=')) {
        hasValidPart = true
      } else if (part.startsWith('svr=')) {
        const srv = parseInt(part.substring(4))
        if (isNaN(srv)) {
          throw new OpcuaError(StatusCode.BadEncodingError, 'Invalid server index')
        }
        hasValidPart = true
      } else if (part.startsWith('i=')) {
        const id = parseInt(part.substring(2))
        if (isNaN(id) || id > 0xFFFFFFFF + 1) {
          throw new OpcuaError(StatusCode.BadEncodingError, 'Invalid numeric identifier')
        }
        hasValidPart = true
      } else if (part.startsWith('s=')) {
        hasValidPart = true
      } else if (part.startsWith('g=')) {
        try {
          new Guid(part.substring(2))
          hasValidPart = true
        } catch {
          throw new OpcuaError(StatusCode.BadEncodingError, 'Invalid GUID format')
        }
      } else if (part.startsWith('b=')) {
        try {
          base64ToBytes(part.substring(2))
          hasValidPart = true
        } catch {
          throw new OpcuaError(StatusCode.BadEncodingError, 'Invalid byte string format')
        }
      } else {
        throw new OpcuaError(StatusCode.BadEncodingError, 'Invalid NodeId part format')
      }
    }

    if (!hasValidPart) {
      throw new OpcuaError(StatusCode.BadEncodingError, 'NodeId must contain at least one valid identifier part')
    }

    this.value = val
  }

  get Ns(): number | string {
    let match = this.value.match(/ns=(\d+);/)
    if (match?.[1]) {
      return parseInt(match[1])
    }

    match = this.value.match(/nsu=(\w+);/)
    if (match?.[1]) {
      return match[1]
    }

    return 0
  }

  get Srv(): number | null {
    const match = this.value.match(/svr=(\d+);/)
    if (match?.[1]) {
      return parseInt(match[1])
    }
    return null
  }

  get Id(): number | string | Uint8Array | Guid {
    let match = this.value.match(/i=(\d+)/)
    if (match?.[1]) {
      return parseInt(match[1])
    }

    match = this.value.match(/(?:^|;)s=([^;]+)/)
    if (match?.[1]) {
      return match[1]
    }

    match = this.value.match(/(?:^|;)b=([^;]+)/)
    if (match?.[1]) {
      return base64ToBytes(match[1])
    }

    match = this.value.match(/(?:^|;)g=([^;]+)/)
    if (match?.[1]) {
      return new Guid(match[1])
    }

    throw new OpcuaError(StatusCode.BadDecodingError, 'Invalid NodeId format')
  }

  toString(): string {
    return this.value
  }
}

export class LocalizedText {
  Text: string | null = null
  Locale: string | null = null

  constructor (text: string | null, locale: string | null = null) {
    this.Text = text
    this.Locale = locale
  }

  toString (): string {
    if (this.Locale === undefined) {
      return this.Text ?? ''
    }

    return `${this.Text} (${this.Locale})`
  }
}

export class QualifiedName {
  Ns: number = 0
  Name: string | null = null

  constructor (ns: number = 0, name: string | null = null) {
    this.Ns = ns
    if (name) {
      this.Name = name
    }
  }

  toString (): string {
    if (this.Name === null) {
      return `${this.Ns}`
    }
    return `${this.Ns}:${this.Name}`
  }
}

export class ExtensionObject {
  readonly TypeId: NodeId | string
  readonly Body: string | Uint8Array | Record<string, unknown> | null

  constructor (typeId: NodeId | string, body: string | Uint8Array | Record<string, unknown> | null = null) {
    this.TypeId = typeId
    this.Body = body
  }

  toString (): string {
    return `(${this.TypeId.toString()})${JSON.stringify(this.Body)}`
  }
}

export const enum VariantType {
  Null = 0,
  Boolean = 1,
  SByte = 2,
  Byte = 3,
  Int16 = 4,
  UInt16 = 5,
  Int32 = 6,
  UInt32 = 7,
  Int64 = 8,
  UInt64 = 9,
  Float = 10,
  Double = 11,
  String = 12,
  DateTime = 13,
  Guid = 14,
  ByteString = 15,
  XmlElement = 16,
  NodeId = 17,
  ExpandedNodeId = 18,
  StatusCode = 19,
  QualifiedName = 20,
  LocalizedText = 21,
  ExtensionObject = 22,
  DataValue = 23,
  Variant = 24,
  DiagnosticInfo = 25,
}

const VariantTypeToString: Record<VariantType, string> = {
  [VariantType.Null]: 'Null',
  [VariantType.Boolean]: 'Boolean',
  [VariantType.SByte]: 'SByte',
  [VariantType.Byte]: 'Byte',
  [VariantType.Int16]: 'Int16',
  [VariantType.UInt16]: 'UInt16',
  [VariantType.Int32]: 'Int32',
  [VariantType.UInt32]: 'UInt32',
  [VariantType.Int64]: 'Int64',
  [VariantType.UInt64]: 'UInt64',
  [VariantType.Float]: 'Float',
  [VariantType.Double]: 'Double',
  [VariantType.String]: 'String',
  [VariantType.DateTime]: 'DateTime',
  [VariantType.Guid]: 'Guid',
  [VariantType.ByteString]: 'ByteString',
  [VariantType.XmlElement]: 'XmlElement',
  [VariantType.NodeId]: 'NodeId',
  [VariantType.ExpandedNodeId]: 'ExpandedNodeId',
  [VariantType.StatusCode]: 'StatusCode',
  [VariantType.QualifiedName]: 'QualifiedName',
  [VariantType.LocalizedText]: 'LocalizedText',
  [VariantType.ExtensionObject]: 'ExtensionObject',
  [VariantType.DataValue]: 'DataValue',
  [VariantType.Variant]: 'Variant',
  [VariantType.DiagnosticInfo]: 'DiagnosticInfo'
}

export function variantTypeToString(type: VariantType): string {
  const str = VariantTypeToString[type]
  if (str === undefined) {
    throw new OpcuaError(StatusCode.BadInvalidArgument, `Invalid variant type: ${type}`)
  }
  return str
}

export type VariantScalarTypes =
boolean |
number | bigint |
string |
NodeId |
QualifiedName |
Guid |
LocalizedText |
DataValue |
Variant |
ExtensionObject |
XmlElement |
Uint8Array |
Date |
OpcuaError |
DiagnosticInfo |
Record<string, unknown> |
null

export type VariantArrayTypes = VariantScalarTypes[]

export type VariantTypes =
  VariantScalarTypes |
  VariantScalarTypes[]

export class Variant {
  Type = VariantType.Null
  Value: VariantTypes = null
  IsArray = false
  ArrayDimensions: number[] | null = null

  constructor (value: VariantTypes = null, type: VariantType | null = null, arrayDimensions: number[] | null = null) {
    const typeValue = value instanceof Array ? value[0] ?? null : value

    if (type === null && value !== null) {
      if (typeValue === null)
        throw new OpcuaError(StatusCode.BadInvalidArgument, 'Variant constructor requires at least one argument')

      if (typeof typeValue === 'boolean') {
        // new Variant(true), new Variant([false, true])
        type = VariantType.Boolean
      } else if (typeof typeValue === 'string') {
        // new Variant('abc'), new Variant(['abc', 'def'])
        type = VariantType.String
      } else if ((typeof typeValue == 'number' || typeof typeValue == 'bigint') && type === null) {
        // new Variant(123), new Variant([123, 456])
        throw new OpcuaError(StatusCode.BadInvalidArgument, 'Variant constructor requires type for number or bigint')
      } else if (typeValue instanceof Date) {
        // new Variant(new Date()), new Variant([0, 1])
        type = VariantType.DateTime
      } else if (typeValue instanceof Guid) {
        // new Variant(new Guid()), new Variant([new Guid(), new Guid()])
        type = VariantType.Guid
      } else if (typeValue instanceof Uint8Array) {
        // new Variant(new Uint8Array([1, 2, 3])), new Variant([new Uint8Array([1, 2, 3]), new Uint8Array([4, 5, 6])])
        type = VariantType.ByteString
      } else if (typeValue instanceof NodeId) {
        // new Variant(new NodeId()), new Variant([new NodeId(), new NodeId()])
        type = VariantType.NodeId
      } else if (typeValue instanceof QualifiedName) {
        // new Variant(new QualifiedName()), new Variant([new QualifiedName(), new QualifiedName()])
        type = VariantType.QualifiedName
      } else if (typeValue instanceof LocalizedText) {
        // new Variant(new LocalizedText()), new Variant([new LocalizedText(), new LocalizedText()])
        type = VariantType.LocalizedText
      } else if (typeValue instanceof DataValue) {
        // new Variant(new DataValue()), new Variant([new DataValue(), new DataValue()])
        type = VariantType.DataValue
      } else if (typeValue instanceof Variant) {
        // new Variant(new Variant()), new Variant([new Variant(), new Variant()])
        type = VariantType.Variant
      } else if (typeValue instanceof XmlElement) {
        // new Variant(new XmlElement()), new Variant([new XmlElement(), new XmlElement()])
        type = VariantType.XmlElement
      }
    }

    if (type == VariantType.DateTime) {
      // new Variant(new Date()), new Variant([0, 1])
      if (value instanceof Array) {
        value = value.map(v =>
          v instanceof Date ? v :
          (typeof v === 'number' || typeof v === 'string') ? new Date(v) :
          (() => { throw new OpcuaError(StatusCode.BadInvalidArgument, 'Invalid date array element type') })()
        )
      } else if (typeof value === 'number') {
        // new Variant(0)
        value = new Date(value)
      }
    } else if (type == VariantType.StatusCode) {
      // new Variant(StatusCode.BadDecodingError), new Variant([StatusCode.BadDecodingError, StatusCode.BadDecodingError])
      if (value instanceof Array) {
        value = value.map(v =>
          v instanceof OpcuaError ? v :
          (typeof v === 'number' ? new OpcuaError(v) :
            (() => { throw new OpcuaError(StatusCode.BadInvalidArgument, 'Invalid StatusCode array element type') })()
          )
        )
      } else if (typeof value === 'number') {
        // new Variant(StatusCode.BadDecodingError)
        value = new OpcuaError(value)
      } else if (!(value instanceof OpcuaError)) {
        throw new OpcuaError(StatusCode.BadInvalidArgument, 'Invalid StatusCode argument type')
      }
    }

    this.IsArray = value instanceof Array
    this.Type = type ?? VariantType.Null
    this.Value = value
    this.ArrayDimensions = arrayDimensions
  }

  toString (): string {
    if (this.Type == VariantType.ExtensionObject)
      return JSON.stringify(this.Value, null, 2)

    if (this.Value === null || this.Value === undefined) {
      return ''
    }
    if (this.Type === VariantType.DateTime) {
      return JSON.stringify(this.Value)
    }

    return this.Value.toString()
  }
}

export class XmlElement {
  Value: string | null

  constructor (value: string | null) {
    this.Value = value
  }

  toString (): string {
    if (this.Value === null) {
      return ''
    }
    return this.Value
  }
}

export class DataValue extends Variant {
  StatusCode: OpcuaError | undefined = undefined
  SourceTimestamp: number | Date | undefined = undefined
  ServerTimestamp: number | Date | undefined = undefined
  SourcePicoseconds: number | undefined = undefined
  ServerPicoseconds: number | undefined = undefined

  constructor(
    value: Variant | undefined,
    statusCode: OpcuaError | undefined = undefined,
    sourceTimestamp: number | Date | undefined = undefined,
    serverTimestamp: number | Date | undefined = undefined,
    sourcePicoseconds: number | undefined = undefined,
    serverPicoseconds: number | undefined = undefined)
  {
    super(value?.Value, value?.Type, value?.ArrayDimensions)
    this.StatusCode = statusCode
    this.SourceTimestamp = sourceTimestamp
    this.ServerTimestamp = serverTimestamp
    this.SourcePicoseconds = sourcePicoseconds
    this.ServerPicoseconds = serverPicoseconds
  }

  override toString (): string {
    if (this.Value === undefined) {
      return ""
    }

    let str = super.toString()
    if (this.StatusCode !== undefined) {
      str += `, StatusCode: ${this.StatusCode}`
    }
    if (this.SourceTimestamp !== undefined) {

      let d: Date
      if (typeof this.SourceTimestamp === 'number') {
        d = new Date(this.SourceTimestamp)
      } else {
        d = this.SourceTimestamp
      }
      str += `, SourceTimestamp: ${d.toISOString()}`
    }
    if (this.ServerTimestamp !== undefined) {
      let d: Date
      if (typeof this.ServerTimestamp === 'number') {
        d = new Date(this.ServerTimestamp)
      } else {
        d = this.ServerTimestamp
      }
      str += `, ServerTimestamp: ${d.toISOString()}`
    }
    if (this.SourcePicoseconds !== undefined) {
      str += `, SourcePicoseconds: ${this.SourcePicoseconds}`
    }
    if (this.ServerPicoseconds !== undefined) {
      str += `, ServerPicoseconds: ${this.ServerPicoseconds}`
    }
    return str
  }
}

export class DiagnosticInfo {
  SymbolicId: number | undefined = undefined
  NamespaceUri: number | undefined = undefined
  LocalizedText: number | undefined = undefined
  Locale: number | undefined = undefined
  AdditionalInfo: string | undefined | null = undefined
  InnerStatusCode: StatusCode | OpcuaError | undefined | null = undefined
  InnerDiagnosticInfo: DiagnosticInfo | undefined = undefined

  constructor (
    symbolicId: number | undefined = undefined,
    namespaceUri: number | undefined = undefined,
    localizedText: number | undefined = undefined,
    locale: number | undefined = undefined,
    additionalInfo: string | undefined | null = undefined,
    innerStatusCode: StatusCode | OpcuaError | undefined | null = undefined,
    innerDiagnosticInfo: DiagnosticInfo | undefined = undefined
  ) {
    this.SymbolicId = symbolicId
    this.NamespaceUri = namespaceUri
    this.LocalizedText = localizedText
    this.Locale = locale
    if (additionalInfo !== undefined) {
      this.AdditionalInfo = additionalInfo
    }
    this.InnerStatusCode = innerStatusCode
    this.InnerDiagnosticInfo = innerDiagnosticInfo
  }

  toString(): string {
    let str = ''
    if (this.SymbolicId !== undefined) {
      str += `SymbolicId: ${this.SymbolicId},`
    }
    if (this.NamespaceUri !== undefined) {
      str += `NamespaceUri: ${this.NamespaceUri},`
    }
    if (this.LocalizedText !== undefined) {
      str += `LocalizedText: ${this.LocalizedText},`
    }
    if (this.Locale !== undefined) {
      str += `Locale: ${this.Locale},`
    }
    if (this.AdditionalInfo !== undefined) {
      str += `AdditionalInfo: ${this.AdditionalInfo},`
    }
    if (this.InnerStatusCode !== undefined) {
      str += `InnerStatusCode: ${this.InnerStatusCode},`
    }
    if (this.InnerDiagnosticInfo !== undefined) {
      str += `InnerDiagnosticInfo: ${this.InnerDiagnosticInfo}`
    }
    return str
  }
}

export const attributeNames = [
  'NodeId',
  'NodeClass',
  'BrowseName',
  'DisplayName',
  'Description',
  'WriteMask',
  'UserWriteMask',
  'IsAbstract',
  'Symmetric',
  'InverseName',
  'ContainsNoLoops',
  'EventNotifier',
  'Value',
  'DataType',
  'ValueRank',
  'ArrayDimensions',
  'AccessLevel',
  'UserAccessLevel',
  'MinimumSamplingInterval',
  'Historizing',
  'Executable',
  'UserExecutable',
  'DataTypeDefinition',
  'RolePermissions',
  'UserRolePermissions',
  'AccessRestrictions',
  'AccessLevelEx'
]

export const enum AttributeIds {
  NodeId = 1,
  NodeClass = 2,
  BrowseName = 3,
  DisplayName = 4,
  Description = 5,
  WriteMask = 6,
  UserWriteMask = 7,
  IsAbstract = 8,
  Symmetric = 9,
  InverseName = 10,
  ContainsNoLoops = 11,
  EventNotifier = 12,
  Value = 13,
  DataType = 14,
  ValueRank = 15,
  ArrayDimensions = 16,
  AccessLevel = 17,
  UserAccessLevel = 18,
  MinimumSamplingInterval = 19,
  Historizing = 20,
  Executable = 21,
  UserExecutable = 22,
  DataTypeDefinition = 23,
  RolePermissions = 24,
  UserRolePermissions = 25,
  AccessRestrictions = 26,
  AccessLevelEx = 27
}

export const enum SecurePolicyUri {
  None = 'http://opcfoundation.org/UA/SecurityPolicy#None',
  Basic128Rsa15 = 'http://opcfoundation.org/UA/SecurityPolicy#Basic128Rsa15',
  Basic256 = 'http://opcfoundation.org/UA/SecurityPolicy#Basic256',
  Basic256Sha256 = 'http://opcfoundation.org/UA/SecurityPolicy#Basic256Sha256',
  Aes128Sha256RsaOaep = 'http://opcfoundation.org/UA/SecurityPolicy#Aes128_Sha256_RsaOaep',
  Aes256Sha256RsaPss = 'http://opcfoundation.org/UA/SecurityPolicy#Aes256_Sha256_RsaPss'
}

export const enum TransportProfile {
  TcpBinary = 'http://opcfoundation.org/UA-Profile/Transport/uatcp-uasc-uabinary',
  HttpsBinary = 'http://opcfoundation.org/UA-Profile/Transport/https-uabinary',
  HttpsJson ="http://opcfoundation.org/UA-Profile/Transport/https-uajson"
}

export type UserToken = {
  TokenType: UserTokenType
  IssuedTokenType: string | undefined
}

export type UserTokenPolicy = {
  PolicyId: string
  TokenType: UserTokenType
  IssuedTokenType: string | undefined
  IssuerEndpointUrl: string | undefined
  SecurityPolicyUri: string | undefined
}

export function getUserTokenTypeName (token: UserToken): string {
  switch (token.TokenType) {
    case 0:
      return 'Anonymous'
    case 1:
      return 'UserName'
    case 2:
      return 'Certificate'
    case 3: {
      switch (token.IssuedTokenType) {
        case 'http://opcfoundation.org/UA/UserToken#Azure':
          return 'Azure'
        case 'http://opcfoundation.org/UA/Authorization#JWT':
          return 'JWT'
        case 'http://opcfoundation.org/UA/Authorization#OAuth2':
          return 'OAuth2'
        default:
          return 'IssuedToken'
      }
    }
  }

  throw new Error('Invalid token type')
}

export function getMessageModeName (mode: number): string {
  switch (mode) {
    case 1:
      return 'None'
    case 2:
      return 'Sign'
    case 3:
      return 'SignAndEncrypt'
    default:
      throw new Error('Invalid message mode')
  }
}

export function getTransportName (transportUri: TransportProfile): string {
  switch (transportUri) {
    case TransportProfile.TcpBinary:
      return 'TcpBinary'
    case TransportProfile.HttpsBinary:
      return 'HttpsBinary'
    case TransportProfile.HttpsJson:
      return 'HttpsJson'
    default:
      throw new Error('Invalid transport profile')
  }
}

export function getAttributeName (attrId: number): string {
  const attrName = attributeNames[attrId]
  if (attrName === undefined) {
    throw new Error('Invalid attribute id')
  }
  return attrName
}

export function getPolicyUri (name: string): string {
  switch (name) {
    case 'Basic128Rsa15':
      return 'http://opcfoundation.org/UA/SecurityPolicy#Basic128Rsa15'

    case 'Basic256':
      return 'http://opcfoundation.org/UA/SecurityPolicy#Basic256'

    case 'Basic256Sha256':
      return 'http://opcfoundation.org/UA/SecurityPolicy#Basic256Sha256'

    case 'None':
      return 'http://opcfoundation.org/UA/SecurityPolicy#None'

    case 'Aes128_Sha256_RsaOaep':
      return 'http://opcfoundation.org/UA/SecurityPolicy#Aes128_Sha256_RsaOaep'

    case 'Aes256_Sha256_RsaPss':
      return 'http://opcfoundation.org/UA/SecurityPolicy#Aes256_Sha256_RsaPss'
  }

  throw Error("Invalid security policy name '" + name + "'")
}

export function getPolicyName (uri: string): string {
  switch (uri) {
    case 'http://opcfoundation.org/UA/SecurityPolicy#Basic128Rsa15':
      return 'Basic128Rsa15'

    case 'http://opcfoundation.org/UA/SecurityPolicy#Basic256':
      return 'Basic256'

    case 'http://opcfoundation.org/UA/SecurityPolicy#Basic256Sha256':
      return 'Basic256Sha256'

    case 'http://opcfoundation.org/UA/SecurityPolicy#None':
      return 'None'

    case 'http://opcfoundation.org/UA/SecurityPolicy#Aes128_Sha256_RsaOaep':
      return 'Aes128_Sha256_RsaOaep'

    case 'http://opcfoundation.org/UA/SecurityPolicy#Aes256_Sha256_RsaPss':
      return 'Aes256_Sha256_RsaPss'
  }

  return uri
}

export type RequestHeader = {
  AuthenticationToken: NodeId
  Timestamp: number
  RequestHandle: number
  ReturnDiagnostics: number
  AuditEntryId: string
  TimeoutHint: number
  AdditionalHeader: {
    TypeId: NodeId
  }
}

export type Request = {
  RequestHeader: RequestHeader
}

export type ApplicationDescription = {
  ApplicationUri: string
  ProductUri: string
  ApplicationName: LocalizedText
  ApplicationType: ApplicationType
  GatewayServerUri: string | null
  DiscoveryProfileUri: string | null
  DiscoveryUrls: string[]
}

export type CreateSessionRequest = Request & {
  ClientDescription: ApplicationDescription
  ServerUri: string | null
  EndpointUrl: string
  SessionName: string
  ClientNonce: Uint8Array | null
  ClientCertificate: Uint8Array | null
  RequestedSessionTimeout: number
  MaxResponseMessageSize: number
}

export type ResponseHeader = {
  Timestamp: number
  RequestHandle: number
  ServiceResult: OpcuaError
  ServiceDiagnostics: ExtensionObject
  StringTable: string[]
}

export type Response = {
  ResponseHeader: ResponseHeader
}

export type EndpointDescription = {
  EndpointUrl: string
  Server: NodeId
  ServerCertificate: Uint8Array | null
  SecurityMode: number
  SecurityPolicyUri: string
  UserIdentityTokens: UserTokenPolicy[]
  TransportProfileUri: string
  SecurityLevel: number
}

export type SignatureData = {
  Algorithm: string
  Signature: Uint8Array
}


export type CreateSessionData = {
  SessionId: NodeId
  AuthenticationToken: NodeId
  RevisedSessionTimeout: number
  ServerNonce: Uint8Array
  ServerCertificate: Uint8Array
  ServerEndpoints: EndpointDescription[]
  ServerSoftwareCertificates: Uint8Array[]
  ServerSignature: SignatureData
  MaxRequestMessageSize: number
}

export type CreateSessionResponse = Response & CreateSessionData

export type ActivateSessionParams = {
  ClientSignature: SignatureData
  ClientSoftwareCertificates: Uint8Array[]
  LocaleIds: Uint8Array[]
  UserIdentityToken: UserToken
  UserTokenSignature: SignatureData | null
}

export type ActivateSessionRequest = Request & ActivateSessionParams

export type ActivateSessionData = {
  ServerNonce: Uint8Array,
  Results: OpcuaError[],
  DiagnosticInfos: DiagnosticInfo[],
}

export type ActivateSessionResponse = Response & ActivateSessionData


export type GetEndpointsParams = {
  EndpointUrl: string,
  LocaleIds: string[],
  ProfileUris: string[]
}


export type CloseSessionParams = {
  DeleteSubscriptions: boolean
}

export type CloseSessionRequest = Request & CloseSessionParams


export type GetEndpointsRequest = Request & GetEndpointsParams

export type GetEndpointsData = {
  Endpoints: EndpointDescription[]
}

export type GetEndpointsResponse = Response & GetEndpointsData


export type FindServersParams = {
  EndpointUrl: string,
  LocaleIds: string[],
  ServerUris: string[]
}

export type FindServersRequest = Request & FindServersParams

export type FindServersData = {
  Servers: ApplicationDescription[]
}

export type FindServersResponse = Response & FindServersData


export type BrowseDescription = {
  NodeId: NodeId,
  BrowseDirection: number,
  ReferenceTypeId: NodeId,
  IncludeSubtypes: boolean,
  NodeClassMask: number,
  ResultMask: number
}

export type BrowseParams = {
  View: NodeId,
  RequestedMaxReferencesPerNode: number,
  NodesToBrowse: BrowseDescription[]
}

export type BrowseRequest = Request & BrowseParams

export type ReferenceDescription = {
  ReferenceTypeId: NodeId,
  IsForward: boolean,
  NodeId: NodeId,
  BrowseName: QualifiedName,
  DisplayName: LocalizedText,
  NodeClass: NodeClass,
  TypeDefinition: NodeId,
}

export type BrowseResult = {
  StatusCode: OpcuaError,
  ContinuationPoint: Uint8Array | null,
  References: ReferenceDescription[],
}

export type BrowseData = {
  Results: BrowseResult[],
  DiagnosticInfos: DiagnosticInfo[]
}

export type BrowseResponse = Response & BrowseData


export type ReadValueId = {
  NodeId: NodeId,
  AttributeId: AttributeIds,
  IndexRange: string | null,
  DataEncoding: QualifiedName,
}

export type ReadParams = {
  MaxAge: number,
  TimestampsToReturn: TimestampsToReturn,
  NodesToRead: ReadValueId[],
}

export type ReadRequest = Request & ReadParams

export type ReadData = {
  Results: DataValue[],
  DiagnosticInfos: DiagnosticInfo[]
}

export type ReadResponse = Response & ReadData


let DebugTrace = false

export function setDebugTrace(enable: boolean): void {
  DebugTrace = enable
}

export function getDebugTrace (): boolean {
  return DebugTrace
}
