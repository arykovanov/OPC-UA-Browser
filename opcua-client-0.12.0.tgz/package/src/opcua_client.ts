import { ActivateSessionData, BrowseData, CreateSessionData, FindServersData, GetEndpointsData, ReadData, UserTokenPolicy } from "./types"

export interface UaClient {
  hello (endpointUrl: string, transportProfileUri?: string): Promise<void>
  openSecureChannel (timeoutMs: number, securityPolicyUri: string, securityMode: number, serverCertificate?: string | Uint8Array | File | null): Promise<void>
  closeSecureChannel (): Promise<void>

  getEndpoints (endpointUrl?: string): Promise<GetEndpointsData>
  findServers (endpointUrl?: string, serverUris?: string[]): Promise<FindServersData>
  createSession(sessionName: string, timeoutMs: number): Promise<CreateSessionData>
  activateSession (tokenPolicy: UserTokenPolicy, identity?: string | Uint8Array | File, secret?: string): Promise<ActivateSessionData>
  closeSession (): Promise<void>
  browse (nodeId: string | string[]): Promise<BrowseData>
  read (nodeId: string | string[]): Promise<ReadData>
}
